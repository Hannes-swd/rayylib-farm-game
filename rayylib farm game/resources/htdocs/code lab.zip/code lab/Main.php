<?php
session_start();

// 

// File Download Handler (MUSS GANZ OBEN sein, BEVOR ob_start())
if (isset($_GET['action']) && ($_GET['action'] === 'download_homework_file' || $_GET['action'] === 'download_answer_file')) {
    try {
        $pdo = new PDO('mysql:host=127.0.0.1;dbname=code_lab', 'root', '');
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        if ($_GET['action'] === 'download_homework_file') {
            $hw_id = intval($_GET['file_id'] ?? 0);
            if ($hw_id <= 0) { die('Invalid file ID'); }

            $stmt = $pdo->prepare("SELECT datei_pfad, datei_name FROM hausaufgaben WHERE id = ?");
            $stmt->execute([$hw_id]);
            $hw = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$hw || !$hw['datei_pfad']) { die('Datei nicht gefunden'); }

            $filePath = __DIR__ . '/' . $hw['datei_pfad'];
            if (!file_exists($filePath)) { die('Datei existiert nicht'); }

            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="' . basename($hw['datei_name']) . '"');
            header('Content-Length: ' . filesize($filePath));
            readfile($filePath);
            exit;
        }
        
        elseif ($_GET['action'] === 'download_answer_file') {
            $answer_id = intval($_GET['file_id'] ?? 0);
            if ($answer_id <= 0) { die('Invalid file ID'); }

            $stmt = $pdo->prepare("SELECT datei_pfad, datei_name FROM hausaufgaben_antworten WHERE id = ?");
            $stmt->execute([$answer_id]);
            $answer = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$answer || !$answer['datei_pfad']) { die('Datei nicht gefunden'); }

            $filePath = __DIR__ . '/' . $answer['datei_pfad'];
            if (!file_exists($filePath)) { die('Datei existiert nicht'); }

            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="' . basename($answer['datei_name']) . '"');
            header('Content-Length: ' . filesize($filePath));
            readfile($filePath);
            exit;
        }
    } catch (Exception $e) {
        die('Fehler: ' . $e->getMessage());
    }
}


// --- NEU: PDO sofort erstellen damit wir Remember-Cookie prüfen können ---
try {
    $pdo = new PDO('mysql:host=127.0.0.1;dbname=code_lab', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    // Falls DB nicht erreichbar, bei normaler GET/HEAD-Anfrage direkt auf Login lassen
    // aber wir wollen konsistentes Verhalten - Redirect auf index.php
    header("Location: index.php");
    exit;
}

// Stelle sicher, dass users.remember_token vorhanden ist
try {
    $stmtCol = $pdo->prepare(
        "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
         WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME = 'remember_token'"
    );
    $stmtCol->execute();
    $hasRememberCol = (int)$stmtCol->fetchColumn() > 0;
    if (!$hasRememberCol) {
        $pdo->exec("ALTER TABLE users ADD COLUMN remember_token VARCHAR(255) DEFAULT NULL");
    }
} catch (PDOException $e) {
    error_log("Could not ensure users.remember_token column: " . $e->getMessage());
}

// Wenn keine Session, aber Remember-Cookie vorhanden -> Versuch Autologin
if (empty($_SESSION['user_id']) && !empty($_COOKIE['remember_me'])) {
    try {
        $token = $_COOKIE['remember_me'];
        if (is_string($token) && strlen($token) >= 16) {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE remember_token = ? LIMIT 1");
            $stmt->execute([$token]);
            $u = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($u) {
                // Wiederherstellen
                $_SESSION['user_id'] = intval($u['id']);
                $_SESSION['username'] = $u['username'] ?? null;
                $_SESSION['roles'] = $u['roles'] ?? null;
                // Token rotieren für bessere Sicherheit
                $newToken = bin2hex(random_bytes(32));
                $stmt = $pdo->prepare("UPDATE users SET remember_token = ? WHERE id = ?");
                $stmt->execute([$newToken, $u['id']]);
                $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
                setcookie('remember_me', $newToken, time() + 60*60*24*30, '/', '', $secure, true);
            } else {
                // ungültiger Token -> löschen
                setcookie('remember_me', '', time() - 3600, '/', '', (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'), true);
            }
        }
    } catch (Exception $e) {
        error_log("Remember-me autologin error: " . $e->getMessage());
    }
}

// Wenn es kein POST/AJAX-Request ist (also normale Seitenaufrufe per GET/HEAD), dann sofort prüfen
// und auf Login weiterleiten, falls kein eingeloggter Nutzer vorhanden ist.
if (in_array($_SERVER['REQUEST_METHOD'], ['GET','HEAD'])) {
    if (empty($_SESSION['user_id'])) {
        header("Location: index.php");
        exit;
    }
}
// --- ENDE NEU ---

try {
    $pdo = new PDO('mysql:host=127.0.0.1;dbname=code_lab', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    http_response_code(500);
    // Wenn AJAX-Aufruf, JSON zurückgeben
    if ((isset($_POST['action']) && in_array($_POST['action'], ['add_course_user','get_termine','create_termin','delete_termin']))) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['error' => 'Datenbankverbindung fehlgeschlagen']);
        exit;
    }
    die("Datenbankverbindung fehlgeschlagen: " . $e->getMessage());
}

// --- Datenbank-Tabellen erstellen ---
try {
    $stmtCol = $pdo->prepare(
        "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
         WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME = 'courses'"
    );
    $stmtCol->execute();
    $hasCoursesCol = (int)$stmtCol->fetchColumn() > 0;
    if (!$hasCoursesCol) {
        $pdo->exec("ALTER TABLE users ADD COLUMN courses VARCHAR(255) DEFAULT ''");
    }
} catch (PDOException $e) {
    error_log("Could not ensure users.courses column: " . $e->getMessage());
}

try {
    $stmtTable = $pdo->prepare(
        "SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES 
         WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'visual_roles'"
    );
    $stmtTable->execute();
    $hasVisualTable = (int)$stmtTable->fetchColumn() > 0;
    if (!$hasVisualTable) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS visual_roles (
            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL UNIQUE,
            emoji VARCHAR(10) DEFAULT ''
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }
} catch (PDOException $e) {
    error_log("Could not ensure visual_roles table: " . $e->getMessage());
}

// Stelle sicher, dass hausaufgaben-Tabelle frist-Spalte hat
try {
    $stmtCol = $pdo->prepare(
        "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
         WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'hausaufgaben' AND COLUMN_NAME = 'frist'"
    );
    $stmtCol->execute();
    $hasFristCol = (int)$stmtCol->fetchColumn() > 0;
    if (!$hasFristCol) {
        $pdo->exec("ALTER TABLE `hausaufgaben` ADD COLUMN `frist` DATE DEFAULT NULL");
    }
} catch (PDOException $e) {
    error_log("Could not ensure hausaufgaben frist column: " . $e->getMessage());
}

// Neue Tabelle: hausaufgaben_antworten (für Schüler-Responses)
try {
    $stmtTable = $pdo->prepare("SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'hausaufgaben_antworten'");
    $stmtTable->execute();
    $hasTable = (int)$stmtTable->fetchColumn() > 0;
    if (!$hasTable) {
        $pdo->exec("CREATE TABLE `hausaufgaben_antworten` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `hausaufgabe_id` INT NOT NULL,
            `benutzer_id` INT NOT NULL,
            `text` TEXT DEFAULT NULL,
            `datei_pfad` VARCHAR(500) DEFAULT NULL,
            `datei_name` VARCHAR(255) DEFAULT NULL,
            `datei_groesse` INT DEFAULT 0,
            `erstellt_am` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (`hausaufgabe_id`) REFERENCES `hausaufgaben`(`id`) ON DELETE CASCADE,
            FOREIGN KEY (`benutzer_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
        )");
    }
} catch (PDOException $e) {
    error_log("Could not ensure hausaufgaben_antworten table: " . $e->getMessage());
}

$user = null;
if (isset($_SESSION['user_id'])) {
    try {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch();
    } catch (PDOException $e) {

    }
}

function hasRole($role) {
    global $user;
    return $user && (str_contains($user['roles'] ?? '', $role));
}

// Hilfsfunktion zum Expandieren wiederkehrender Termine
function expandRecurringEvent($termin, $start_date, $end_date) {
    $events = [];
    $start = new DateTime($termin['datum']);
    $end = $termin['wiederholung_bis'] ? new DateTime($termin['wiederholung_bis']) : new DateTime($end_date);
    $range_start = new DateTime($start_date);
    $range_end = new DateTime($end_date);
    
    if ($termin['wiederholung_typ'] === 'woechentlich' && !empty($termin['wiederholung_tage'])) {
        $days = array_map('intval', explode(',', $termin['wiederholung_tage']));
        $current = clone $start;
        
        while ($current <= $end && $current <= $range_end) {
            $dayOfWeek = (int)$current->format('N'); // 1=Mo, 7=So
            
            if (in_array($dayOfWeek, $days) && $current >= $range_start) {
                $event = $termin;
                $event['datum'] = $current->format('Y-m-d');
                $event['instance_date'] = $current->format('Y-m-d');
                $events[] = $event;
            }
            
            $current->modify('+1 day');
        }
    } elseif ($termin['wiederholung_typ'] === 'taeglich') {
        $current = clone $start;
        while ($current <= $end && $current <= $range_end) {
            if ($current >= $range_start) {
                $event = $termin;
                $event['datum'] = $current->format('Y-m-d');
                $event['instance_date'] = $current->format('Y-m-d');
                $events[] = $event;
            }
            $current->modify('+1 day');
        }
    } elseif ($termin['wiederholung_typ'] === 'monatlich') {
        $current = clone $start;
        while ($current <= $end && $current <= $range_end) {
            if ($current >= $range_start) {
                $event = $termin;
                $event['datum'] = $current->format('Y-m-d');
                $event['instance_date'] = $current->format('Y-m-d');
                $events[] = $event;
            }
            $current->modify('+1 month');
        }
    }
    
    return $events;
}

// AJAX HANDLER
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    // --- Neuer Schutz: alle Responses als JSON, Fehler/Exceptions in JSON zurückgeben ---
    // Output buffering, damit bei Fehlern keine Partial-HTML ausgegeben wird
    if (!ob_get_level()) ob_start();

    // Utility: JSON ausgeben und Script beenden
    if (!function_exists('jsonRespond')) {
        function jsonRespond($data, $httpCode = 200) {
            // Alle bisherigen Ausgaben verwerfen, damit nur reines JSON gesendet wird
            while (ob_get_level()) {
                @ob_end_clean();
            }
            if (!headers_sent()) header('Content-Type: application/json; charset=utf-8');
            http_response_code($httpCode);
            echo json_encode($data);
            exit;
        }
    }

    // Fehler -> Exception umwandeln
    set_error_handler(function($severity, $message, $file, $line) {
        // Respect @ operator
        if (!(error_reporting() & $severity)) {
            return false;
        }
        throw new ErrorException($message, 0, $severity, $file, $line);
    });

    // Ungefangene Exceptions als JSON zurückgeben
    set_exception_handler(function($ex) {
        jsonRespond(['success' => false, 'error' => 'exception', 'message' => $ex->getMessage()], 500);
    });

    // Shutdown-Funktion fängt fatale Errors ab und gibt JSON zurück
    register_shutdown_function(function() {
        $err = error_get_last();
        if ($err !== null && in_array($err['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR])) {
            // komplette Ausgabe verwerfen
            while (ob_get_level()) {
                @ob_end_clean();
            }
            if (!headers_sent()) header('Content-Type: application/json; charset=utf-8');
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'error' => 'shutdown',
                'message' => $err['message'] ?? 'Fatal error',
                'file' => $err['file'] ?? null,
                'line' => $err['line'] ?? null
            ]);
            exit;
        }
    });

    header('Content-Type: application/json; charset=utf-8');

    // Session prüfen
    if (empty($_SESSION['user_id'])) {
        http_response_code(401);
        echo json_encode(['error' => 'Nicht eingeloggt']);
        exit;
    }

    if (empty($user)) {
        try {
            $stmtU = $pdo->prepare("SELECT * FROM users WHERE id = ?");
            $stmtU->execute([$_SESSION['user_id']]);
            $user = $stmtU->fetch();
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['error' => 'Interner Serverfehler']);
            exit;
        }
    }

    $getCourseByName = function($name) use ($pdo) {
        $stmt = $pdo->prepare("SELECT id, name, farb_code FROM kurse WHERE name = ? LIMIT 1");
        $stmt->execute([$name]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    };

    $getCourseById = function($id) use ($pdo) {
        $stmt = $pdo->prepare("SELECT id, name, farb_code FROM kurse WHERE id = ? LIMIT 1");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    };

    $getVisualRoleByName = function($name) use ($pdo) {
        $stmt = $pdo->prepare("SELECT id, name, emoji FROM visual_roles WHERE name = ? LIMIT 1");
        $stmt->execute([$name]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    };

    $getVisualRoleById = function($id) use ($pdo) {
        $stmt = $pdo->prepare("SELECT id, name, emoji FROM visual_roles WHERE id = ? LIMIT 1");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    };

    $defaultRoleEmoji = function($r){
        $m = [
            'admin' => '🛡️',
            'lehrer' => '📚',
            'schueler' => '👨‍🎓'
        ];
        return $m[$r] ?? '🎭';
    };

    $buildRoleObj = function($roleName) use ($getVisualRoleByName, $defaultRoleEmoji) {
        $roleName = trim($roleName);
        if ($roleName === '') return null;
        $vr = $getVisualRoleByName($roleName);
        if ($vr) return ['name'=>$vr['name'],'emoji'=>($vr['emoji'] ?: $defaultRoleEmoji($vr['name'])),'id'=>intval($vr['id'])];
        return ['name'=>$roleName,'emoji'=>$defaultRoleEmoji($roleName),'id'=>null];
    };

    try {
        $action = $_POST['action'];

        // ---- NEU: logout per AJAX ----
        if ($action === 'logout') {
            // Wenn eingeloggt, remember_token in DB löschen
            if (!empty($_SESSION['user_id'])) {
                try {
                    $stmt = $pdo->prepare("UPDATE users SET remember_token = NULL WHERE id = ?");
                    $stmt->execute([intval($_SESSION['user_id'])]);
                } catch (PDOException $e) {
                    error_log("Failed clearing remember_token on logout: " . $e->getMessage());
                }
            }
            // Session beenden und Cookie löschen
            $_SESSION = [];
            if (ini_get("session.use_cookies")) {
                $params = session_get_cookie_params();
                setcookie(session_name(), '', time() - 42000,
                    $params["path"], $params["domain"],
                    $params["secure"], $params["httponly"]
                );
            }
            @session_destroy();
            // Cookie entfernen
            $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
            setcookie('remember_me', '', time() - 3600, '/', '', $secure, true);

            echo json_encode(['success' => true]);
            exit;
        }
        // ---- ENDE NEU ----
        // === NEUE AJAX-HANDLER für Hausaufgaben ===
        // Füge dies in Main.php in den AJAX-Handler-Block (nach den anderen Actions) ein

        if ($action === 'get_homework_details') {
            $hw_id = intval($_POST['homework_id'] ?? 0);
            if ($hw_id <= 0) {
                jsonRespond(['success' => false, 'error' => 'invalid_id'], 400);
            }

            try {
                // Hausaufgabe laden
                $stmt = $pdo->prepare("
                    SELECT h.*, k.name AS kurs_name, k.farb_code
                    FROM hausaufgaben h
                    LEFT JOIN kurse k ON h.kurs_id = k.id
                    WHERE h.id = ?
                ");
                $stmt->execute([$hw_id]);
                $hw = $stmt->fetch(PDO::FETCH_ASSOC);

                if (!$hw) {
                    jsonRespond(['success' => false, 'error' => 'not_found'], 404);
                }

                // Schüler-Antworten laden (falls Lehrer/Admin)
                $answers = [];
                if (hasRole('admin') || hasRole('lehrer')) {
                    $stmt = $pdo->prepare("
                        SELECT id, benutzer_id, text, datei_pfad, datei_name, datei_groesse, erstellt_am
                        FROM hausaufgaben_antworten
                        WHERE hausaufgabe_id = ?
                        ORDER BY erstellt_am DESC
                    ");
                    $stmt->execute([$hw_id]);
                    $answers = $stmt->fetchAll(PDO::FETCH_ASSOC);
                } else {
                    // Schüler sieht nur seine eigene Antwort
                    $stmt = $pdo->prepare("
                        SELECT id, benutzer_id, text, datei_pfad, datei_name, datei_groesse, erstellt_am
                        FROM hausaufgaben_antworten
                        WHERE hausaufgabe_id = ? AND benutzer_id = ?
                        ORDER BY erstellt_am DESC
                    ");
                    $stmt->execute([$hw_id, intval($user['id'])]);
                    $answers = $stmt->fetchAll(PDO::FETCH_ASSOC);
                }

                jsonRespond([
                    'success' => true,
                    'homework' => $hw,
                    'answers' => $answers
                ]);
            } catch (PDOException $e) {
                error_log("get_homework_details error: " . $e->getMessage());
                jsonRespond(['success' => false, 'error' => 'db_error'], 500);
            }
        }
        // Füge dies in Main.php im AJAX-Handler-Block ein (nach 'get_homework_details')
        if ($action === 'delete_hausaufgabe') {
            if (!hasRole('admin') && !hasRole('lehrer')) {
                jsonRespond(['success' => false, 'error' => 'Zugriff verweigert'], 403);
            }

            $hw_id = intval($_POST['homework_id'] ?? 0);
            if ($hw_id <= 0) {
                jsonRespond(['success' => false, 'error' => 'Ungültige Hausaufgaben-ID'], 400);
            }

            try {
                // Optional: Prüfen, ob der Lehrer Zugriff auf diese Hausaufgabe hat
                if (!hasRole('admin')) {
                    // Prüfen, ob die Hausaufgabe zu einem Kurs gehört, in dem der Lehrer unterrichtet
                    $stmt = $pdo->prepare("
                        SELECT h.id 
                        FROM hausaufgaben h
                        INNER JOIN kurse k ON h.kurs_id = k.id
                        INNER JOIN users u ON FIND_IN_SET(k.name, REPLACE(u.courses, ' ', '')) > 0
                        WHERE h.id = ? AND u.id = ? AND (u.roles LIKE '%lehrer%' OR u.roles LIKE '%admin%')
                    ");
                    $stmt->execute([$hw_id, intval($user['id'])]);
                    $hasAccess = $stmt->fetch();
                    
                    if (!$hasAccess) {
                        jsonRespond(['success' => false, 'error' => 'Kein Zugriff auf diese Hausaufgabe'], 403);
                    }
                }

                // Lösche die Hausaufgabe (CASCADE löscht automatisch die Antworten)
                $stmt = $pdo->prepare("DELETE FROM hausaufgaben WHERE id = ?");
                $stmt->execute([$hw_id]);

                jsonRespond([
                    'success' => true,
                    'message' => 'Hausaufgabe erfolgreich gelöscht'
                ]);
            } catch (PDOException $e) {
                error_log("delete_hausaufgabe error: " . $e->getMessage());
                jsonRespond(['success' => false, 'error' => 'Datenbankfehler'], 500);
            }
        }

        // === Handler zum Hochladen von Schüler-Antworten ===
        if ($action === 'submit_homework_answer') {
            $hw_id = intval($_POST['homework_id'] ?? 0);
            $text = trim($_POST['text'] ?? '');
            
            if ($hw_id <= 0) {
                jsonRespond(['success' => false, 'error' => 'invalid_homework_id'], 400);
            }

            try {
                // Prüfe: existiert die Hausaufgabe?
                $stmt = $pdo->prepare("SELECT id FROM hausaufgaben WHERE id = ?");
                $stmt->execute([$hw_id]);
                if (!$stmt->fetch()) {
                    jsonRespond(['success' => false, 'error' => 'homework_not_found'], 404);
                }

                // Datei verarbeiten (optional)
                $datei_pfad = null;
                $datei_name = null;
                $datei_groesse = 0;

                if (!empty($_FILES['datei']) && $_FILES['datei']['error'] === UPLOAD_ERR_OK) {
                    $file = $_FILES['datei'];
                    $size = intval($file['size']);

                    // Größenlimit: 50 MB
                    if ($size > 50 * 1024 * 1024) {
                        jsonRespond(['success' => false, 'error' => 'file_too_large'], 400);
                    }

                    $uploads_dir = rtrim(__DIR__, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'hausaufgaben_antworten' . DIRECTORY_SEPARATOR;
                    if (!is_dir($uploads_dir)) {
                        if (!@mkdir($uploads_dir, 0777, true)) {
                            jsonRespond(['success' => false, 'error' => 'upload_dir_failed'], 500);
                        }
                    }

                    $origName = basename($file['name']);
                    $safeOrig = preg_replace('/[^\w\.\- ]+/', '_', $origName);
                    $safeOrig = mb_substr($safeOrig, 0, 200);

                    $ext = pathinfo($origName, PATHINFO_EXTENSION);
                    $ext = $ext ? '.' . preg_replace('/[^a-zA-Z0-9]/', '', $ext) : '';
                    $new_filename = 'answer_' . $hw_id . '_' . intval($user['id']) . '_' . time() . '_' . bin2hex(random_bytes(4)) . $ext;
                    $target = $uploads_dir . $new_filename;

                    $written = false;
                    if (is_uploaded_file($file['tmp_name'])) {
                        $written = @move_uploaded_file($file['tmp_name'], $target);
                    }
                    if (!$written) {
                        $data = @file_get_contents($file['tmp_name']);
                        if ($data !== false) {
                            $written = @file_put_contents($target, $data) !== false;
                        }
                    }

                    if ($written) {
                        @chmod($target, 0666);
                        $datei_pfad = 'uploads/hausaufgaben_antworten/' . $new_filename;
                        $datei_name = $safeOrig;
                        $datei_groesse = $size;
                    }
                }

                // Speichere Antwort in Datenbank
                $stmt = $pdo->prepare("
                    INSERT INTO hausaufgaben_antworten (hausaufgabe_id, benutzer_id, text, datei_pfad, datei_name, datei_groesse, erstellt_am)
                    VALUES (?, ?, ?, ?, ?, ?, NOW())
                ");
                $stmt->execute([
                    $hw_id,
                    intval($user['id']),
                    (!empty($text) ? $text : null),
                    $datei_pfad,
                    $datei_name,
                    $datei_groesse
                ]);

                jsonRespond([
                    'success' => true,
                    'message' => 'Antwort hochgeladen',
                    'answer_id' => $pdo->lastInsertId()
                ]);
            } catch (PDOException $e) {
                error_log("submit_homework_answer error: " . $e->getMessage());
                jsonRespond(['success' => false, 'error' => 'db_error'], 500);
            }
        }
        // ========== ANWESENHEIT-HANDLER ==========

        if ($action === 'create_anwesenheit') {
            if (!hasRole('admin') && !hasRole('lehrer')) {
                http_response_code(403);
                echo json_encode(['error' => 'Keine Berechtigung']);
                exit;
            }
            
            $datum = $_POST['datum'] ?? '';
            $uhrzeit_start = $_POST['uhrzeit_start'] ?? null;
            $uhrzeit_end = $_POST['uhrzeit_end'] ?? null;
            $unterrichtsstoff = trim($_POST['unterrichtsstoff'] ?? '');
            $benutzer_id = intval($_POST['benutzer_id'] ?? 0);
            // Änderung: Wert direkt übernehmen (1 oder 0)
            $anwesend = isset($_POST['anwesend']) ? intval($_POST['anwesend']) : 1;
            $entschuldigung = trim($_POST['entschuldigung'] ?? '');
            $nachgeholt = isset($_POST['nachgeholt']) ? 1 : 0;
            
            if (empty($datum) || $benutzer_id <= 0) {
                http_response_code(400);
                echo json_encode(['error' => 'Ungültige Daten']);
                exit;
            }
            
            // Leere Strings zu NULL konvertieren
            $uhrzeit_start = $uhrzeit_start === '' ? null : $uhrzeit_start;
            $uhrzeit_end = $uhrzeit_end === '' ? null : $uhrzeit_end;
            $entschuldigung = $entschuldigung === '' ? null : $entschuldigung;
            
            $stmt = $pdo->prepare("INSERT INTO anwesenheit 
                (datum, uhrzeit_start, uhrzeit_end, unterrichtsstoff, benutzer_id, anwesend, entschuldigung, nachgeholt) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            
            $stmt->execute([
                $datum, $uhrzeit_start, $uhrzeit_end, $unterrichtsstoff,
                $benutzer_id, $anwesend, $entschuldigung, $nachgeholt
            ]);
            
            echo json_encode(['success' => true, 'anwesenheit_id' => $pdo->lastInsertId()]);
            exit;
        }

        // ---- NEU: Anwesenheit: Liste für einen Benutzer laden ----
        if ($action === 'get_user_anwesenheit') {
            $target_user = intval($_POST['user_id'] ?? ($_SESSION['user_id'] ?? 0));
            if ($target_user <= 0) jsonRespond(['success'=>false,'error'=>'invalid_user'],400);

            $stmt = $pdo->prepare("SELECT id, datum, uhrzeit_start, uhrzeit_end, unterrichtsstoff, benutzer_id, anwesend, entschuldigung, nachgeholt 
                                   FROM anwesenheit WHERE benutzer_id = ? ORDER BY datum DESC LIMIT 100");
            $stmt->execute([$target_user]);
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // zusätzliche Aggregation: counts
            $stmtC = $pdo->prepare("SELECT 
                SUM(CASE WHEN anwesend = 1 THEN 1 ELSE 0 END) AS present,
                SUM(CASE WHEN anwesend = 0 AND nachgeholt = 0 THEN 1 ELSE 0 END) AS missed,
                SUM(CASE WHEN nachgeholt = 1 THEN 1 ELSE 0 END) AS made_up
                FROM anwesenheit WHERE benutzer_id = ?");
            $stmtC->execute([$target_user]);
            $counts = $stmtC->fetch(PDO::FETCH_ASSOC);

            jsonRespond(['success'=>true,'rows'=>$rows,'counts'=>$counts]);
        }

        // ---- NEU: Anwesenheit: nachgeholt toggeln ----
        if ($action === 'toggle_anwesenheit') {
            $entry_id = intval($_POST['id'] ?? 0);
            if ($entry_id <= 0) jsonRespond(['success'=>false,'error'=>'invalid_id'],400);

            // Lade Eintrag
            $stmt = $pdo->prepare("SELECT * FROM anwesenheit WHERE id = ? LIMIT 1");
            $stmt->execute([$entry_id]);
            $entry = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$entry) jsonRespond(['success'=>false,'error'=>'not_found'],404);

            // Berechtigung: entweder Admin/Lehrer oder eigener Nutzer
            $isOwner = (!empty($_SESSION['user_id']) && intval($_SESSION['user_id']) === intval($entry['benutzer_id']));
            $isPriv = hasRole('admin') || hasRole('lehrer');

            if (!($isOwner || $isPriv)) {
                jsonRespond(['success'=>false,'error'=>'forbidden'],403);
            }

            $new = isset($_POST['nachgeholt']) && in_array($_POST['nachgeholt'], ['1','0','true','false'], true) ? (int)($_POST['nachgeholt'] ? 1 : 0) : null;
            if ($new === null) jsonRespond(['success'=>false,'error'=>'invalid_value'],400);

            $stmt = $pdo->prepare("UPDATE anwesenheit SET nachgeholt = ? WHERE id = ?");
            $stmt->execute([$new, $entry_id]);

            // Optional: falls nachgeholt=1, behalten wir anwesend=0 aber behandeln es bei Anzeige als "nachgeholt".
            $stmt = $pdo->prepare("SELECT id, datum, uhrzeit_start, uhrzeit_end, unterrichtsstoff, benutzer_id, anwesend, entschuldigung, nachgeholt FROM anwesenheit WHERE id = ?");
            $stmt->execute([$entry_id]);
            $updated = $stmt->fetch(PDO::FETCH_ASSOC);

            jsonRespond(['success'=>true,'entry'=>$updated]);
        }
        // ---- ENDE NEU ----

        // ========== TERMIN-HANDLER ==========
        if ($action === 'get_termine') {
            $start_date = $_POST['start_date'] ?? null;
            $end_date = $_POST['end_date'] ?? null;

            if (empty($start_date) || empty($end_date)) {
                $start_date = date('Y-m-d', strtotime('-1 year'));
                $end_date = date('Y-m-d', strtotime('+2 years'));
            }
            
            // Kurse des aktuellen Users ermitteln
            $user_courses = [];
            if (hasRole('admin')) {
                // Admins sehen alle Termine
                $stmt = $pdo->query("SELECT id FROM kurse");
                $user_courses = $stmt->fetchAll(PDO::FETCH_COLUMN);
            } else {
                // Lehrer/Schüler sehen nur ihre Kurse
                $courses_str = $user['courses'] ?? '';
                $course_names = array_filter(array_map('trim', explode(',', $courses_str)));
                if (!empty($course_names)) {
                    $placeholders = str_repeat('?,', count($course_names) - 1) . '?';
                    $stmt = $pdo->prepare("SELECT id FROM kurse WHERE name IN ($placeholders)");
                    $stmt->execute($course_names);
                    $user_courses = $stmt->fetchAll(PDO::FETCH_COLUMN);
                }
            }
            
            if (empty($user_courses)) {
                echo json_encode(['success' => true, 'termine' => []]);
                exit;
            }
            
            // Termine laden - NUR für Kurse des Users
            $placeholders = str_repeat('?,', count($user_courses) - 1) . '?';
            $sql = "SELECT t.*, k.name as kurs_name, k.farb_code 
                    FROM termine t 
                    JOIN kurse k ON t.kurs_id = k.id 
                    WHERE t.kurs_id IN ($placeholders)";
            
            $params = $user_courses;
            $sql .= " AND ((t.datum BETWEEN ? AND ?) OR (t.ist_wiederkehrend = 1 && (t.wiederholung_bis IS NULL || t.wiederholung_bis >= ?)))";
            $params[] = $start_date;
            $params[] = $end_date;
            $params[] = $start_date;
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $termine = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Wiederkehrende Termine expandieren
            $expanded = [];
            foreach ($termine as $termin) {
                if ($termin['ist_wiederkehrend']) {
                    $instances = expandRecurringEvent($termin, $start_date, $end_date);
                    $expanded = array_merge($expanded, $instances);
                } else {
                    $expanded[] = $termin;
                }
            }
            
            echo json_encode(['success' => true, 'termine' => $expanded]);
            exit;
        }
        
        if ($action === 'create_termin') {
            if (!hasRole('admin') && !hasRole('lehrer') && !hasRole('schueler')) {
                http_response_code(403);
                echo json_encode(['error' => 'Keine Berechtigung']);
                exit;
            }
            
            $kurs_id = intval($_POST['kurs_id'] ?? 0);
            $titel = trim($_POST['titel'] ?? '');
            $notiz = trim($_POST['notiz'] ?? '');
            $datum = $_POST['datum'] ?? '';
            $uhrzeit_start = $_POST['uhrzeit_start'] ?? null;
            $uhrzeit_end = $_POST['uhrzeit_end'] ?? null;
            $ist_wiederkehrend = isset($_POST['ist_wiederkehrend']) ? 1 : 0;
            $wiederholung_typ = $_POST['wiederholung_typ'] ?? 'einmalig';
            $wiederholung_tage = $_POST['wiederholung_tage'] ?? '';
            $wiederholung_bis = $_POST['wiederholung_bis'] ?? null;
            
            if ($kurs_id <= 0 || empty($titel) || empty($datum)) {
                http_response_code(400);
                echo json_encode(['error' => 'Ungültige Daten']);
                exit;
            }
            
            // Prüfen ob User Zugriff auf Kurs hat (außer Admin)
            if (!hasRole('admin')) {
                $courses_str = $user['courses'] ?? '';
                $course_names = array_filter(array_map('trim', explode(',', $courses_str)));
                $stmt = $pdo->prepare("SELECT name FROM kurse WHERE id = ?");
                $stmt->execute([$kurs_id]);
                $kurs_name = $stmt->fetchColumn();
                
                if (!in_array($kurs_name, $course_names)) {
                    http_response_code(403);
                    echo json_encode(['error' => 'Kein Zugriff auf diesen Kurs']);
                    exit;
                }
            }
            
            // Leere Strings zu NULL konvertieren
            $uhrzeit_start = $uhrzeit_start === '' ? null : $uhrzeit_start;
            $uhrzeit_end = $uhrzeit_end === '' ? null : $uhrzeit_end;
            $wiederholung_bis = $wiederholung_bis === '' ? null : $wiederholung_bis;
            
            $stmt = $pdo->prepare("INSERT INTO termine 
                (kurs_id, titel, notiz, datum, uhrzeit_start, uhrzeit_end, ist_wiederkehrend, 
                 wiederholung_typ, wiederholung_tage, wiederholung_bis, erstellt_von) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            
            $stmt->execute([
                $kurs_id, $titel, $notiz, $datum, $uhrzeit_start, $uhrzeit_end,
                $ist_wiederkehrend, $wiederholung_typ, $wiederholung_tage, 
                $wiederholung_bis, $user['id']
            ]);
            
            echo json_encode(['success' => true, 'termin_id' => $pdo->lastInsertId()]);
            exit;
        }
        
        if ($action === 'delete_termin') {
            if (!hasRole('admin') && !hasRole('lehrer') && !hasRole('schueler')) {
                http_response_code(403);
                echo json_encode(['error' => 'Keine Berechtigung']);
                exit;
            }
            
            $termin_id = intval($_POST['termin_id'] ?? 0);
            
            // Prüfen ob User Berechtigung hat
            $stmt = $pdo->prepare("SELECT t.kurs_id, k.name FROM termine t 
                                   JOIN kurse k ON t.kurs_id = k.id WHERE t.id = ?");
            $stmt->execute([$termin_id]);
            $termin = $stmt->fetch();
            
            if (!$termin) {
                http_response_code(404);
                echo json_encode(['error' => 'Termin nicht gefunden']);
                exit;
            }
            
            if (!hasRole('admin')) {
                $courses_str = $user['courses'] ?? '';
                $course_names = array_filter(array_map('trim', explode(',', $courses_str)));
                if (!in_array($termin['name'], $course_names)) {
                    http_response_code(403);
                    echo json_encode(['error' => 'Keine Berechtigung']);
                    exit;
                }
            }
            
            $stmt = $pdo->prepare("DELETE FROM termine WHERE id = ?");
            $stmt->execute([$termin_id]);
            
            echo json_encode(['success' => true]);
            exit;
        }

        // ========== KURS-HANDLER ==========

        if ($action === 'get_user_courses') {
            $user_id = intval($_POST['user_id'] ?? 0);
            if ($user_id <= 0) {
                http_response_code(400);
                echo json_encode(['error' => 'Ungültige Nutzerdaten']);
                exit;
            }
            $stmt = $pdo->prepare("SELECT courses FROM users WHERE id = ?");
            $stmt->execute([$user_id]);
            $current = $stmt->fetchColumn();
            $names = array_filter(array_map('trim', explode(',', $current ?: '')));
            $result = [];
            foreach ($names as $n) {
                $c = $getCourseByName($n);
                // FIX: korrekte if-Syntax
                if ($c) {
                    $result[] = $c;
                } else {
                    $result[] = ['id'=>null,'name'=>$n,'farb_code'=>null];
                }
            }
            echo json_encode(['success'=>true,'courses'=>$result]);
            exit;
        }

        if (!hasRole('admin')) {
            http_response_code(403);
            echo json_encode(['error' => 'Zugriff verweigert']);
            exit;
        }

        if ($action === 'add_course_user') {
            $user_id = intval($_POST['user_id'] ?? 0);
            $course_id = intval($_POST['course_id'] ?? 0);
            if ($user_id <= 0 || $course_id <= 0) {
                http_response_code(400);
                echo json_encode(['error' => 'Ungültige Daten']);
                exit;
            }

            $course = $getCourseById($course_id);
            if (!$course) {
                http_response_code(404);
                echo json_encode(['error' => 'Kurs nicht gefunden']);
                exit;
            }
            $course_name = $course['name'];

            $stmt = $pdo->prepare("SELECT courses FROM users WHERE id = ?");
            $stmt->execute([$user_id]);
            $current = $stmt->fetchColumn();
            $courses = array_filter(array_map('trim', explode(',', $current ?: '')));
            if (!in_array($course_name, $courses)) {
                $courses[] = $course_name;
                $new = implode(',', $courses);
                $stmt = $pdo->prepare("UPDATE users SET courses = ? WHERE id = ?");
                $stmt->execute([$new, $user_id]);
            }

            $result = [];
            foreach ($courses as $n) {
                $c = $getCourseByName($n);
                if ($c) $result[] = $c;
                else $result[] = ['id'=>null,'name'=>$n,'farb_code'=>null];
            }
            echo json_encode(['success'=>true,'courses'=>$result]);
            exit;
        }

        if ($action === 'remove_course_user') {
            $user_id = intval($_POST['user_id'] ?? 0);
            $course_id = intval($_POST['course_id'] ?? 0);
            if ($user_id <= 0 || $course_id <= 0) {
                http_response_code(400);
                echo json_encode(['error' => 'Ungültige Daten']);
                exit;
            }

            $course = $getCourseById($course_id);
            if (!$course) {
                http_response_code(404);
                echo json_encode(['error' => 'Kurs nicht gefunden']);
                exit;
            }
            $course_name = $course['name'];

            $stmt = $pdo->prepare("SELECT courses FROM users WHERE id = ?");
            $stmt->execute([$user_id]);
            $current = $stmt->fetchColumn();
            $courses = array_filter(array_map('trim', explode(',', $current ?: '')));
            $newCourses = array_values(array_filter($courses, function($x) use ($course_name){ return $x !== $course_name; }));
            $new = implode(',', $newCourses);
            $stmt = $pdo->prepare("UPDATE users SET courses = ? WHERE id = ?");
            $stmt->execute([$new, $user_id]);

            $result = [];
            foreach ($newCourses as $n) {
                $c = $getCourseByName($n);
                if ($c) $result[] = $c;
                else $result[] = ['id'=>null,'name'=>$n,'farb_code'=>null];
            }
            echo json_encode(['success'=>true,'courses'=>$result]);
            exit;
        }

        if ($action === 'get_user_roles') {
            $user_id = intval($_POST['user_id'] ?? 0);
            if ($user_id <= 0) { http_response_code(400); echo json_encode(['error'=>'Ungültige Nutzerdaten']); exit; }
            $stmt = $pdo->prepare("SELECT roles FROM users WHERE id = ?");
            $stmt->execute([$user_id]);
            $current = $stmt->fetchColumn();
            $names = array_values(array_filter(array_map('trim', explode(',', $current ?: ''))));
            $out = [];
            foreach ($names as $n) { $o = $buildRoleObj($n); if ($o) $out[] = $o; }
            echo json_encode(['success'=>true,'roles'=>$out]);
            exit;
        }

        if ($action === 'add_role_user') {
            $user_id = intval($_POST['user_id'] ?? 0);
            $role_name = trim($_POST['role_name'] ?? '');
            if ($user_id <= 0 || $role_name === '') { http_response_code(400); echo json_encode(['error'=>'Ungültige Daten']); exit; }

            $stmt = $pdo->prepare("SELECT roles FROM users WHERE id = ?");
            $stmt->execute([$user_id]);
            $current = $stmt->fetchColumn();
            $roles = array_values(array_filter(array_map('trim', explode(',', $current ?: ''))));
            if (!in_array($role_name, $roles)) {
                $roles[] = $role_name;
                $new = implode(',', $roles);
                $stmt = $pdo->prepare("UPDATE users SET roles = ? WHERE id = ?");
                $stmt->execute([$new, $user_id]);
            }
            $out = [];
            foreach ($roles as $r) { $o = $buildRoleObj($r); if ($o) $out[] = $o; }
            echo json_encode(['success'=>true,'roles'=>$out]);
            exit;
        }

        if ($action === 'remove_role_user') {
            $user_id = intval($_POST['user_id'] ?? 0);
            $role_name = trim($_POST['role_name'] ?? '');
            if ($user_id <= 0 || $role_name === '') { http_response_code(400); echo json_encode(['error'=>'Ungültige Daten']); exit; }

            $stmt = $pdo->prepare("SELECT roles FROM users WHERE id = ?");
            $stmt->execute([$user_id]);
            $current = $stmt->fetchColumn();
            $roles = array_values(array_filter(array_map('trim', explode(',', $current ?: ''))));
            $newRoles = array_values(array_filter($roles, function($x) use ($role_name){ return $x !== $role_name; }));
            $new = implode(',', $newRoles);
            $stmt = $pdo->prepare("UPDATE users SET roles = ? WHERE id = ?");
            $stmt->execute([$new, $user_id]);

            $out = [];
            foreach ($newRoles as $r) { $o = $buildRoleObj($r); if ($o) $out[] = $o; }
            echo json_encode(['success'=>true,'roles'=>$out]);
            exit;
        }

        if ($action === 'create_visual_role') {
            $name = trim($_POST['name'] ?? '');
            $emoji = trim($_POST['emoji'] ?? '');
            if ($name === '') { http_response_code(400); echo json_encode(['error'=>'Name nötig']); exit; }
            $stmt = $pdo->prepare("INSERT IGNORE INTO visual_roles (name, emoji) VALUES (?, ?)");
            $stmt->execute([$name, $emoji]);
            $stmt = $pdo->prepare("SELECT id, name, emoji FROM visual_roles ORDER BY name");
            $stmt->execute();
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode(['success'=>true,'visual_roles'=>$rows]);
            exit;
        }

        // Handle note creation
        if ($_POST['action'] === 'create_note') {
            try {
                $benutzer_id = intval($_POST['benutzer_id'] ?? 0);
                $kurs_id = intval($_POST['kurs_id'] ?? 0);
                $titel = trim($_POST['titel'] ?? '');
                $note = intval($_POST['note'] ?? 0);
                $beschreibung = trim($_POST['beschreibung'] ?? '');
                $erstellt_von = isset($user) && isset($user['id']) ? intval($user['id']) : 1;
                
                // Validierung
                if ($benutzer_id <= 0 || $kurs_id <= 0 || $titel === '' || $note < 1 || $note > 6) {
                    jsonRespond(['success' => false, 'message' => 'Validierung fehlgeschlagen'], 400);
                }

                // DB-Insert in Transaktion
                $pdo->beginTransaction();
                $sql = "INSERT INTO noten (benutzer_id, kurs_id, note, titel, beschreibung, klasse, erstellt_von, datum_erstellt) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, NOW())";
                $stmt = $pdo->prepare($sql);
                $ok = $stmt->execute([$benutzer_id, $kurs_id, $note, $titel, $beschreibung, '', $erstellt_von]);
                if (!$ok) {
                    $pdo->rollBack();
                    jsonRespond(['success' => false, 'message' => 'Fehler beim Speichern der Note'], 500);
                }
                $note_id = $pdo->lastInsertId();

                // Datei-Upload (optional)
                $savedFilePath = null;
                if (!empty($_FILES['datei']['name'])) {
                    $file = $_FILES['datei'];

                    // Upload-Fehler prüfen
                    if (!isset($file['error']) || $file['error'] !== UPLOAD_ERR_OK) {
                        // Log und weiter (Note ist bereits erstellt)
                        error_log("Upload error for note {$note_id}: " . ($file['error'] ?? 'no error code'));
                    } else {
                        $size = intval($file['size']);
                        if ($size > 10 * 1024 * 1024) {
                            // Dateigröße zu groß -> commit und Rückmeldung
                            $pdo->commit();
                            jsonRespond(['success' => true, 'message' => 'Note erstellt, aber Datei zu groß (max 10 MB)', 'note_id' => $note_id], 200);
                        }

                        $uploads_dir = rtrim(__DIR__, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'noten' . DIRECTORY_SEPARATOR;
                        if (!is_dir($uploads_dir)) {
                            if (!@mkdir($uploads_dir, 0777, true) && !is_dir($uploads_dir)) {
                                $pdo->commit();
                                jsonRespond(['success' => true, 'message' => 'Note erstellt, Upload-Verzeichnis konnte nicht angelegt werden', 'note_id' => $note_id], 200);
                            }
                        }
                        if (!is_writable($uploads_dir)) {
                            $pdo->commit();
                            jsonRespond(['success' => true, 'message' => 'Note erstellt, Upload-Verzeichnis nicht beschreibbar', 'note_id' => $note_id], 200);
                        }

                        $origName = basename($file['name']);
                        $safeOrig = preg_replace('/[^\w\.\- ]+/', '_', $origName);
                        $safeOrig = mb_substr($safeOrig, 0, 200);

                        // Dateiendung erhalten, sichere neuen Dateinamen erstellen
                        $ext = pathinfo($origName, PATHINFO_EXTENSION);
                        $ext = $ext ? '.' . preg_replace('/[^a-zA-Z0-9]/','', $ext) : '';
                        $new_filename = 'note_' . $note_id . '_' . time() . '_' . bin2hex(random_bytes(4)) . $ext;
                        $target = $uploads_dir . $new_filename;

                        $written = false;
                        if (is_uploaded_file($file['tmp_name'])) {
                            $written = @move_uploaded_file($file['tmp_name'], $target);
                        }
                        if (!$written) {
                            $data = @file_get_contents($file['tmp_name']);
                            if ($data !== false) {
                                $written = @file_put_contents($target, $data) !== false;
                            }
                        }

                        if ($written) {
                            @chmod($target, 0666);
                            try {
                                $sql2 = "INSERT INTO noten_dateien (noten_id, dateiname, dateipfad, dateityp, dateigroesse, hochgeladen_am) 
                                         VALUES (?, ?, ?, ?, ?, NOW())";
                                $stmt2 = $pdo->prepare($sql2);
                                $stmt2->execute([$note_id, $safeOrig, $new_filename, $file['type'] ?? 'application/octet-stream', $size]);
                                $savedFilePath = $new_filename;
                            } catch (PDOException $e) {
                                error_log("DB error inserting noten_datei for note {$note_id}: " . $e->getMessage());
                                // file stored but metadata fehlgeschlagen
                            }
                        } else {
                            error_log("Upload write failed for note_id={$note_id}, tmp=" . ($file['tmp_name'] ?? ''));
                        }
                    }
                }

                // Commit
                if ($pdo->inTransaction()) $pdo->commit();

                jsonRespond(['success' => true, 'message' => 'Note erstellt', 'note_id' => $note_id, 'file' => $savedFilePath], 200);
            } catch (Exception $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                error_log("create_note error: " . $e->getMessage());
                jsonRespond(['success' => false, 'message' => 'Interner Fehler'], 500);
            }
        }

        // ====== NEU: Eintragungen erstellen (für mehrere markierte Benutzer) ======
        if ($action === 'create_eintragung') {
            // Nur Lehrer/Admin dürfen Hausaufgaben/Eintragungen anlegen
            if (!hasRole('admin') && !hasRole('lehrer')) {
                echo json_encode(['success' => false, 'error' => 'Zugriff verweigert']);
                exit;
            }

            $kurs_id = intval($_POST['kurs_id'] ?? 0);
            $text = trim($_POST['text'] ?? '');
            $user_ids_raw = $_POST['user_ids'] ?? '[]';
            $user_ids = json_decode($user_ids_raw, true);
            if (!is_array($user_ids)) $user_ids = [];

            if ($kurs_id <= 0 || $text === '' || empty($user_ids)) {
                echo json_encode(['success' => false, 'error' => 'Fehlende oder ungültige Daten']);
                exit;
            }

            $stmtInsert = $pdo->prepare("INSERT INTO eintragungen (kurs_id, benutzer_id, `text`, datum, erstellt_von) VALUES (?, ?, ?, ?, ?)");
            $today = date('Y-m-d');
            $inserted = 0;

            foreach ($user_ids as $uid) {
                $uid = intval($uid);
                if ($uid <= 0) continue;
                try {
                    $stmtInsert->execute([$kurs_id, $uid, $text, $today, $user['id'] ?? null]);
                    $inserted++;
                } catch (PDOException $e) {
                    // Ein Fehler für einen einzelnen Eintrag soll die gesamte Operation nicht abbrechen;
                    // Loggen und mit den nächsten fortfahren.
                    error_log("Failed to insert eintragung for user {$uid}: " . $e->getMessage());
                }
            }

            echo json_encode(['success' => true, 'inserted' => $inserted]);
            exit;
        }
        // ====== ENDE NEU ======

    } catch (PDOException $e) {
        http_response_code(500);
        error_log("AJAX error ({$action}): " . $e->getMessage());
        echo json_encode(['error'=>'Datenbankfehler','message'=>$e->getMessage()]);
        exit;
    }
}

// --- NEU: einfacher AJAX-Handler nur für create_hausaufgabe (fügt Hausaufgabe + Empfänger ein) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create_hausaufgabe') {
    header('Content-Type: application/json; charset=utf-8');
    if (session_status() !== PHP_SESSION_ACTIVE) session_start();
    if (empty($_SESSION['user_id'])) {
        echo json_encode(['success' => false, 'error' => 'not_logged_in']);
        exit;
    }

    $kurs_id = intval($_POST['kurs_id'] ?? 0);
    $titel = trim($_POST['titel'] ?? ($_POST['name'] ?? ''));
    $beschreibung = trim($_POST['beschreibung'] ?? $_POST['text'] ?? '');
    $frist = trim($_POST['frist'] ?? ''); // NEU
    $user_ids = json_decode($_POST['user_ids'] ?? '[]', true);
    if (!is_array($user_ids)) $user_ids = [];

    try {
        $pdo->beginTransaction();

        $stmt = $pdo->prepare("INSERT INTO hausaufgaben (kurs_id, titel, beschreibung, frist, erstellt_von, erstellt_am) 
                              VALUES (?, ?, ?, ?, ?, NOW())");
        $stmt->execute([$kurs_id, $titel, $beschreibung, ($frist ?: null), $_SESSION['user_id'] ?? null]);
        $hausaufgabe_id = (int)$pdo->lastInsertId();

        $inserted = 0;
        if ($hausaufgabe_id && !empty($user_ids)) {
            $stmtIns = $pdo->prepare("INSERT INTO hausaufgaben_empfaenger (hausaufgabe_id, benutzer_id) VALUES (?, ?)");
            foreach ($user_ids as $uid) {
                $uid = intval($uid);
                if ($uid <= 0) continue;
                $stmtIns->execute([$hausaufgabe_id, $uid]);
                $inserted++;
            }
        }

        $pdo->commit();
        echo json_encode(['success' => true, 'hausaufgabe_id' => $hausaufgabe_id, 'inserted' => $inserted]);
    } catch (PDOException $e) {
        try { $pdo->rollBack(); } catch (\Exception $xx){ /* ignore */ }
        error_log("create_hausaufgabe error: " . $e->getMessage());
        echo json_encode(['success' => false, 'error' => 'db_error', 'message' => $e->getMessage()]);
    }
    exit;
}
// --- ENDE NEU ---



// ✅ ERST JETZT der Session-Check für HTML-Seiten
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <meta name="description" content="Code Lab - Schulverwaltung und Kursverwaltung">
    <meta name="theme-color" content="#667eea">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="apple-mobile-web-app-title" content="Code Lab">

    <meta name="mobile-web-app-capable" content="yes">
    
    <!-- PWA Manifest -->
    <link rel="manifest" href="manifest.json">
    
    <!-- iOS Icons -->
    <link rel="apple-touch-icon" href="images/Logo.png">
    <link rel="icon" type="image/png" sizes="192x192" href="images/Logo.png">
    <link rel="icon" type="image/png" sizes="512x512" href="images/Logo.png">
    <link rel="shortcut icon" href="images/Logo.png">
    
    <!-- Styles -->
    <link rel="stylesheet" href="style.css">
    
    <title>Code Lab</title>
    
    <script>
        // Service Worker Registration
        if ('serviceWorker' in navigator) {
            window.addEventListener('load', () => {
                navigator.serviceWorker.register('service-worker.js')
                    .then(registration => {
                        console.log('Service Worker registriert:', registration);
                    })
                    .catch(error => {
                        console.log('Service Worker Registrierung fehlgeschlagen:', error);
                    });
            });
        }

        // App-Installation erkannt
        window.addEventListener('appinstalled', () => {
            console.log('Code Lab wurde als PWA installiert');
        });
    </script>
</head>
<body>

    <?php
        $current_page = isset($_GET['page']) ? $_GET['page'] : 'dashboard';
        $allowed_pages = ['dashboard', 'KursOffen','KursErstellen', 'kalender', 'benutzer', 'anwesenheit', 'accound', 'NutzerHinzufügen', 'kurs', 'benutzerOffen'];
        
        if (!in_array($current_page, $allowed_pages)) {
            $current_page = 'dashboard';
        }

        $page_roles = [
            'benutzerOffen' => ['admin', 'lehrer'],
            'NutzerHinzufügen' => ['admin'],
            'benutzer' => ['admin'],
            'KursErstellen' => ['admin'],
            'kurs' => ['admin', 'lehrer', 'schueler'],
            'anwesenheit' => ['admin', 'lehrer'],
            'accound' => ['admin', 'lehrer', 'schueler'],
            'dashboard' => ['admin', 'lehrer', 'schueler'],
            'KursOffen' => ['admin', 'lehrer', 'schueler'],
            'kalender' => ['admin', 'lehrer', 'schueler'],
            
        ];

        $user_roles = isset($user['roles']) ? explode(",", $user['roles']) : [];
        $has_access = false;
        foreach ($user_roles as $role) {
            if (in_array(trim($role), $page_roles[$current_page])) {
                $has_access = true;
                break;
            }
        }

        if (!$has_access) {
            $current_page = 'dashboard';
        }

        $has_second_sidebar = ($current_page === 'KursOffen');

        // kleine Hilfsfunktion um Hex-Farbcode in rgba mit Alpha zu konvertieren
        function hexToRgba($hex, $alpha = 0.12) {
            $hex = ltrim($hex, '#');
            if (strlen($hex) === 3) {
                $r = hexdec(str_repeat($hex[0],2));
                $g = hexdec(str_repeat($hex[1],2));
                $b = hexdec(str_repeat($hex[2],2));
            } else {
                $r = hexdec(substr($hex,0,2));
                $g = hexdec(substr($hex,2,2));
                $b = hexdec(substr($hex,4,2));
            }
            return "rgba($r,$g,$b,$alpha)";
        }
    ?>
    
    <!-- Sidebar -->
    <div class="app-sidebar">
        <div class="app-sidebar-logo">
            <ul class="app-nav">
                <li class="app-logo">
                    <img src="images/Logo.png" class="app-img app-logo__img" alt="Logo">
                    <h2 class="app-logo__text">Code Lab</h2>
                </li>
            </ul>
        </div>
        
        <div class="app-divider"></div>
        
        <ul class="app-nav">
            <a href="?page=dashboard" class="app-nav-link ">
                <li class="app-nav__item <?php echo $current_page == 'dashboard' ? 'active' : ''; ?>">
                    <img src="images/Daschboard.png" class="app-img" alt="Dashboard">
                    <span>Dashboard</span>
                </li>
            </a>
            
            <a href="?page=kalender" class="app-nav-link">
                <li class="app-nav__item <?php echo $current_page == 'kalender' ? 'active' : ''; ?>">
                    <img src="images/kalender.png" class="app-img" alt="Kalender">
                    <span>Kalender</span>
                </li>
            </a>
            
            <?php if (hasRole('admin')): ?>
            <a href="?page=benutzer" class="app-nav-link">
                <li class="app-nav__item <?php echo $current_page == 'benutzer' ? 'active' : ''; ?>">
                    <img src="images/Profile.png" class="app-img" alt="Benutzer">
                    <span>Benutzer</span>
                </li>
            </a>
            <?php endif; ?>
            
            <?php if (hasRole('admin') || hasRole('lehrer') || hasRole('schueler')): ?>
            <a href="?page=kurs" class="app-nav-link">
                <li class="app-nav__item <?php echo $current_page == 'kurs' ? 'active' : ''; ?>">
                    <img src="images/Anwesenheit.png" class="app-img" alt="kurs">
                    <span>Kurs</span>
                </li>
            </a>
            <?php endif; ?>

            <?php if (hasRole('admin') || hasRole('lehrer')): ?>
            <a href="?page=anwesenheit" class="app-nav-link">
                <li class="app-nav__item <?php echo $current_page == 'anwesenheit' ? 'active' : ''; ?>">
                    <img src="images/liste.png" class="app-img" alt="Anwesenheit">
                    <span>Anwesenheit</span>
                </li>
            </a>
            <?php endif; ?>
        </ul>
        <div class="app-sidebar-bottom">
            <a href="?page=accound" class="app-nav-link app-nav-account-link" >
                <div class="app-divider"></div>
                    <div class="app-user">
                        <div class="app-user__avatar">
                            <?php 
                            $anfangsbuchstabe = $user['username'][0]; 
                            echo $anfangsbuchstabe;
                            ?>
                        </div>
                        <div class="app-user__info">
                            <p><strong><?php echo htmlspecialchars($user['username']); ?></strong></p>
                            <p><?php 
                                if (!empty($user['roles'])) {
                                    echo htmlspecialchars($user['roles']);
                                } else {
                                    echo "Benutzer";
                                }
                        ?></p>
                    </div>
                </div>
            </a>
        </div>
    </div>
    
    <!-- Desktop Sidebar für KursOffen (nur auf breiten Bildschirmen) -->
    <?php if ($has_second_sidebar): ?>
    <div class="app-sidecontent kurs-detail-sidebar">
        <?php
            $course_id = isset($_GET['course_id']) ? intval($_GET['course_id']) : 0;
            if ($course_id > 0) {
                try {
                    $stmt = $pdo->prepare("SELECT id, name, info, farb_code FROM kurse WHERE id = ?");
                    $stmt->execute([$course_id]);
                    $course = $stmt->fetch(PDO::FETCH_ASSOC);
                    if ($course):
                        // verwende rgba-Hintergrund statt voller Farbe
                        $panelBg = hexToRgba($course['farb_code'] ?? '#8fbced', 0.12);
        ?>
            <div class="app-course-panel" style="background-color: <?php echo $panelBg; ?>;">
                <h2 style="color: #111; margin: 0; text-align: center; font-size: 18px;">
                    <?php echo htmlspecialchars($course['name']); ?>
                </h2>
                <div style=" padding: 12px; border-radius: 8px;">
                        <?php echo nl2br(htmlspecialchars($course['info'] ?? 'Keine Beschreibung vorhanden.')); ?>
                </div>
            </div>

            <div style="padding: 20px; overflow-y: auto; flex: 1;">
                <h3 style="font-size: 14px; font-weight: 600; margin-bottom: 12px; color: #3c4043;">Menü</h3>
                <a href="" class="app-nav-link kurs-detail-sidebar__link">
                    <div>
                        <p>Benutzer</p>
                    </div>
                </a>
                <br>
                <?php
                /*
                <h3 style="font-size: 14px; font-weight: 600; margin-bottom: 12px; color: #3c4043;">Tabellen <strong>✚</strong></h3>
                
                <a href="" class="app-nav-link kurs-detail-sidebar__link">
                    <div>
                        <p>tabelle 1</p>
                    </div>
                </a>

                <a href="" class="app-nav-link kurs-detail-sidebar__link">
                    <div>
                        <p>tabelle 2</p>
                    </div>
                </a>
                */
                ?>
            </div>
            
        <?php
                    endif;
                } catch (PDOException $e) {
                    // Fehler ignorieren
                }
            }
        ?>
    </div>
    <?php endif; ?>

    <div class="app-main<?php echo $has_second_sidebar ? ' app-main--two-sidebars kurs-offen-page' : ''; ?>">
        <?php
            $page_file = "pages/" . $current_page . ".php";
            if (file_exists($page_file)) {
                include($page_file);
            } else {
                echo "<div class='error-message'>Seite nicht gefunden.</div>";
            }
        ?>
    </div>

    <!-- Account Modal -->
    <div id="accountModal" class="cal-modal-overlay" style="display:none;" onclick="if(event.target===this) closeAccountModal()">
        <div class="cal-modal" role="dialog" aria-modal="true" aria-labelledby="accountModalTitle">
            <div class="cal-modal-header">
                <h3 class="cal-modal-title" id="accountModalTitle">Benutzer</h3>
                <button class="cal-modal-close" aria-label="Schließen" onclick="closeAccountModal()">×</button>
            </div>
            <div class="cal-modal-body" style="display:flex; flex-direction:column; gap:12px;">
                <p style="margin:0 0 6px 0;">Was möchten Sie tun?</p>
                <div style="display:flex; gap:10px; justify-content:flex-end;">
                    <button id="accountModalAccountBtn" class="cal-btn cal-btn-secondary">Account anzeigen</button>
                    <button id="accountModalLogoutBtn" class="cal-btn cal-btn-danger">Abmelden</button>
                </div>
            </div>
        </div>
    </div>

    <script>
    // Account-Modal Verhalten
    (function(){
        const accountLinks = document.querySelectorAll('a.app-nav-account-link');
        function openAccountModal(e){
            e.preventDefault();
            document.getElementById('accountModal').style.display = 'flex';
        }
        accountLinks.forEach(a => a.addEventListener('click', openAccountModal));

        window.closeAccountModal = function(){
            document.getElementById('accountModal').style.display = 'none';
        };

        document.getElementById('accountModalAccountBtn').addEventListener('click', function(){
            // Zur Accound-Seite navigieren
            window.location.href = 'Main.php?page=accound';
        });

        document.getElementById('accountModalLogoutBtn').addEventListener('click', async function(){
            if (!confirm('Möchten Sie sich abmelden?')) return;
            try {
                const fd = new FormData();
                fd.append('action', 'logout');
                const resp = await fetch('Main.php', { method: 'POST', body: fd, credentials: 'same-origin' });
                const json = await resp.json();
                if (json && json.success) {
                    // Sicherstellen, dass keine weitere JS-Session-abhängige Logik läuft
                    window.location.href = 'index.php';
                } else {
                    alert('Abmeldung fehlgeschlagen');
                }
            } catch (e) {
                console.error('Logout error', e);
                alert('Fehler bei der Abmeldung');
            }
        });

        // ESC schließt das Modal
        document.addEventListener('keydown', function(e){
            if (e.key === 'Escape') closeAccountModal();
        });
    })();
    </script>
</body>
</html>