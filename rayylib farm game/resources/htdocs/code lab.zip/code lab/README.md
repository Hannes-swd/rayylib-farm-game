# 🎓 Code Lab - Schul- & Kursverwaltungssystem

## ℹ️ Über das Projekt

Code Lab ist eine umfassende PHP-Webanwendung zur Verwaltung von Kursen, Schülern, Lehrern und Administratoren. Das System ermöglicht es Schulen und Instituten, ihre Unterrichtsorganisation digital zu gestalten – mit Termin-Management, Notenenverwaltung, Anwesenheitserfassung und vielem mehr.

Die Anwendung wurde mit Fokus auf **Benutzerfreundlichkeit**, **Sicherheit** und **Skalierbarkeit** entwickelt.

## ✨ Features

### 👥 Benutzerverwaltung
- 🔐 Sichere Benutzerauthentifizierung mit Session-Management
- 🔄 "Angemeldet bleiben"-Funktion mit Token-Rotation
- 👨‍💼 Rollenbasierte Zugriffskontrolle (Admin, Lehrer, Schüler)
- 📋 Benutzerprofile mit erweiterten Informationen (Vorname, Nachname, Alter, Wohnort, Geburtstag, E-Mail)

### 📚 Kursverwaltung
- ✏️ Kurse erstellen, bearbeiten und löschen (Admin)
- 🎨 Farbcodierung für visuelle Unterscheidung
- 📝 Kursbeschreibungen und Informationen
- 👨‍🏫 Benutzer zu Kursen hinzufügen/entfernen
- 🔍 Schnellsuche nach Kursnamen

### 📅 Terminverwaltung
- 📍 Termine für Kurse erstellen und verwalten
- 🔄 Wiederkehrende Termine (täglich, wöchentlich, monatlich)
- ⏰ Start- und Endzeiten
- 📝 Notizen zu Terminen
- 🗓️ Kalenderansicht (Monat, Woche, Tag, Jahr)
- 📌 Mini-Kalender für schnelle Navigation

### 📊 Notenverwaltung
- ⭐ Noten für Schüler (Skala 1-6)
- 📎 Dateianhangs-Support für Noten
- 📈 Durchschnittsberechnung pro Kurs und gesamt
- 📋 Notenhistorie mit Zeitstempel

### ✍️ Anwesenheitserfassung
- ✔️ Anwesenheit von Schülern erfassen
- 📋 Unterrichtsstoff dokumentieren
- 🚫 Abwesenheit mit Entschuldigung
- 📍 Start- und Endzeiten
- ✅ Nachholstatus

### 🎯 Zusätzliche Features
- 📝 Hausaufgaben für Schüler erstellen
- 📌 Eintragungen (Vermerke) für Schüler
- 🎭 Benutzerdefinierte visuelle Rollen mit Emojis
- 🔎 Erweiterte Suche und Filter
- 📊 Dashboard mit Übersichten
- 🔐 CSRF-Schutz & XSS-Prevention
- 📱 Responsive Design

## 🛠️ Technologien

| Bereich | Technologie |
|---------|------------|
| **Backend** | PHP 7.4+ |
| **Frontend** | HTML5, CSS3, JavaScript (Vanilla) |
| **Datenbank** | MySQL 5.7+ |
| **Kalender** | FullCalendar / Chart.js |
| **Sicherheit** | Prepared Statements, Password Hashing (bcrypt), Session Management, Token Rotation |

## 📋 Voraussetzungen

- PHP 7.4 oder höher
- MySQL 5.7 oder höher
- Web-Server (Apache/Nginx)
- PDO PHP-Extension
- Browser mit JavaScript-Unterstützung

## 🚀 Installation

### 1. Datenbank einrichten
```sql
-- Haupttabellen
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    roles VARCHAR(255),
    courses VARCHAR(255),
    vorname VARCHAR(100),
    nachname VARCHAR(100),
    alter INT,
    wohnort VARCHAR(150),
    geburtstag DATE,
    email VARCHAR(255),
    remember_token VARCHAR(255)
);

CREATE TABLE kurse (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL UNIQUE,
    info TEXT,
    farb_code VARCHAR(7)
);

CREATE TABLE termine (
    id INT PRIMARY KEY AUTO_INCREMENT,
    kurs_id INT,
    titel VARCHAR(200),
    notiz TEXT,
    datum DATE,
    uhrzeit_start TIME,
    uhrzeit_end TIME,
    ist_wiederkehrend BOOLEAN,
    wiederholung_typ VARCHAR(20),
    wiederholung_tage VARCHAR(50),
    wiederholung_bis DATE,
    erstellt_von INT,
    FOREIGN KEY (kurs_id) REFERENCES kurse(id)
);

CREATE TABLE noten (
    id INT PRIMARY KEY AUTO_INCREMENT,
    benutzer_id INT,
    kurs_id INT,
    note INT,
    titel VARCHAR(200),
    beschreibung TEXT,
    klasse VARCHAR(50),
    erstellt_von INT,
    datum_erstellt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (benutzer_id) REFERENCES users(id),
    FOREIGN KEY (kurs_id) REFERENCES kurse(id)
);

CREATE TABLE anwesenheit (
    id INT PRIMARY KEY AUTO_INCREMENT,
    benutzer_id INT,
    datum DATE,
    uhrzeit_start TIME,
    uhrzeit_end TIME,
    unterrichtsstoff TEXT,
    anwesend BOOLEAN,
    entschuldigung TEXT,
    nachgeholt BOOLEAN,
    FOREIGN KEY (benutzer_id) REFERENCES users(id)
);

CREATE TABLE hausaufgaben (
    id INT PRIMARY KEY AUTO_INCREMENT,
    kurs_id INT,
    titel VARCHAR(200),
    beschreibung TEXT,
    erstellt_von INT,
    erstellt_am TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (kurs_id) REFERENCES kurse(id)
);

CREATE TABLE visual_roles (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) UNIQUE,
    emoji VARCHAR(10)
);
```

### 2. Projektdateien kopieren
```bash
git clone <repository-url> code-lab
cd code-lab
```

### 3. Datenbankverbindung konfigurieren

Öffne `index.php` und `Main.php` und aktualisiere die Datenbankverbindungsdaten:

```php
$pdo = new PDO('mysql:host=HOSTNAME;dbname=DATENBANKNAME', 'BENUTZER', 'PASSWORT');
```

### 4. Permissions setzen
```bash
chmod 755 .
chmod 755 uploads/
chmod 755 uploads/noten/
```

### 5. Webserver starten
```bash
# Apache mit PHP
php -S localhost:8000

# oder mit Apache direkt
systemctl start apache2
```

Öffne http://localhost:8000 im Browser.

## 👤 Erste Schritte

### Admin-Benutzer erstellen
```php
// Über Datenbankabfrage:
INSERT INTO users (username, password_hash, roles, courses) 
VALUES ('admin', '$2y$10$...', 'admin', '');

// Passwort mit PHP hashen:
password_hash('passwort123', PASSWORD_DEFAULT)
```

### Login
- Gehe zu `index.php`
- Gib Benutzername und Passwort ein
- Optional: "Angemeldet bleiben" aktivieren

### Kurse erstellen
1. Melde dich als Admin an
2. Gehe zu **Benutzer → Kurse erstellen**
3. Gib Kursname, Beschreibung und Farbe ein
4. Speichern

### Benutzer hinzufügen
1. Gehe zu **Benutzer → Nutzer hinzufügen**
2. Wähle Rollen (Admin, Lehrer, Schüler)
3. Lege ein Passwort fest
4. Speichern

### Benutzer zu Kursen hinzufügen
1. Gehe zu **Benutzer**
2. Klicke auf 👨‍🫔 neben dem Benutzernamen
3. Wähle Kurse aus und speichern

## 📁 Projektstruktur

```
code-lab/
├── index.php               # Login-Seite
├── Main.php                # Hauptanwendung & API-Handler
├── style.css               # Hauptstylesheets
├── pages/                  # Template-Dateien
│   ├──accound.php          # Benutzerkonto & Passwortänderung
│   ├──anwesenheit.php      # Anwesenheitserfassung
│   ├──benutzer.php         # Benutzerverwaltung
│   ├──benutzerOffen.php    # Benutzerdetails
│   ├──dashboard.php        # Dashboard mit Übersichten
│   ├──kalender.php         # Terminkalender
│   ├──kurs.php             # Kursverwaltung
│   ├──KursOffen.php        # Kursdetails & Verwaltung
│   ├──KursErstellen.php    # Neuen Kurs erstellen
│   └──NutzerHinzufügen.php # Neuen Benutzer erstellen
├── uploads/                # Datei-Upload Verzeichnis
│   └── noten/              # Noten-Dateien
└── images/                 # Icon & Logo-Dateien
```

## 🔐 Sicherheitsfeatures

### Authentifizierung
- ✅ Sichere Session-Verwaltung
- ✅ Token-basierte "Angemeldet bleiben"-Funktion
- ✅ Token-Rotation nach jedem Login
- ✅ Sichere Cookie-Flags (HttpOnly, Secure, SameSite)

### Datenschutz
- ✅ Prepared Statements gegen SQL-Injection
- ✅ HTML-Escaping gegen XSS
- ✅ Rollenbasierte Zugriffskontrolle
- ✅ Benutzerbasierte Datenfilterung

### Datenspeicherung
- ✅ Passwort-Hashing mit bcrypt
- ✅ Sichere Datei-Upload-Behandlung
- ✅ Dateigrößen-Validierung
- ✅ Dateiname-Sanitization

## 📊 API-Endpunkte

Alle AJAX-Requests gehen an `Main.php` mit `action`-Parameter:

| Action | Beschreibung |
|--------|-------------|
| `get_termine` | Termine für Datumsbereich laden |
| `create_termin` | Neuen Termin erstellen |
| `delete_termin` | Termin löschen |
| `create_anwesenheit` | Anwesenheit erfassen |
| `get_user_courses` | Kurse eines Benutzers |
| `add_course_user` | Benutzer zu Kurs hinzufügen |
| `remove_course_user` | Benutzer aus Kurs entfernen |
| `get_user_roles` | Rollen eines Benutzers |
| `add_role_user` | Rolle hinzufügen |
| `remove_role_user` | Rolle entfernen |
| `create_note` | Note eintragen |
| `create_hausaufgabe` | Hausaufgabe erstellen |
| `create_eintragung` | Eintragung (Vermerk) erstellen |
| `logout` | Benutzer abmelden |

## 🐛 Troubleshooting

### "Datenbankverbindung fehlgeschlagen"
- Überprüfe Datenbankdaten in `index.php` und `Main.php`
- Stelle sicher, dass MySQL läuft
- Überprüfe Benutzerrechte

### Dateien können nicht hochgeladen werden
- Überprüfe Verzeichnisrechte: `chmod 755 uploads/`
- Überprüfe PHP `upload_max_filesize` Einstellung
- Überprüfe verfügbaren Speicherplatz

### Session läuft ab
- Überprüfe PHP `session.gc_maxlifetime`
- Aktiviere "Angemeldet bleiben" für längere Sessions

## 📝 Lizenz


Dieses Projekt ist mein persönliches Portfolio und dient zur Demonstration meiner Fähigkeiten. 
Der Code ist öffentlich einsehbar als Referenz und Lernressource.

**Erlaubt ist:** 
- Code anschauen und studieren  
- Sich von Lösungen inspirieren lassen  
- Code-Teile für eigene Projekte adaptieren

**Nicht erlaubt ist:**
- Das Projekt mit minimalen Änderungen als eigenes Werk zu veröffentlichen
- Komplette Fork-Veröffentlichungen ohne signifikante Eigenentwicklung

Bei Nutzung von Code-Teilen in eigenen Projekten sind Credits geschätzt.

---
