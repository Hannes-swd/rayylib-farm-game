<?php
/**
 * PWA Security & Cache Headers
 * Füge diesen Code oben in index.php und Main.php ein (vor dem <html> Tag)
 */

// Nur wenn noch keine Headers gesendet wurden
if (!headers_sent()) {
    
    // ===== SICHERHEITS-HEADERS =====
    // HTTPS erzwingen
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains; preload', true);
    }
    
    // XSS-Schutz
    header('X-Content-Type-Options: nosniff', true);
    header('X-Frame-Options: SAMEORIGIN', true);
    header('X-XSS-Protection: 1; mode=block', true);
    header('Referrer-Policy: no-referrer-when-downgrade', true);
    
    // CORS für Service Worker
    header('Access-Control-Allow-Origin: *', true);
    
    // ===== CACHE-HEADERS =====
    $request_uri = $_SERVER['REQUEST_URI'] ?? '';
    
    // Statische Dateien (CSS, JS, Images) - 1 Stunde cachen
    if (preg_match('/\.(css|js|jpg|jpeg|png|gif|ico|svg|woff|woff2)$/i', $request_uri)) {
        header('Cache-Control: public, max-age=3600, must-revalidate', true);
        header('Expires: ' . gmdate('D, d M Y H:i:s', time() + 3600) . ' GMT', true);
    }
    // Manifest & Service Worker - 1 Stunde cachen
    elseif (preg_match('/\.(json|webmanifest)$/i', $request_uri) || 
            strpos($request_uri, 'service-worker.js') !== false ||
            strpos($request_uri, 'manifest.json') !== false) {
        header('Cache-Control: public, max-age=3600, must-revalidate', true);
        header('Content-Type: application/json; charset=utf-8', true);
        header('Expires: ' . gmdate('D, d M Y H:i:s', time() + 3600) . ' GMT', true);
    }
    // HTML-Seiten - nicht cachen (immer aktuell)
    elseif (preg_match('/\.php$|\/$/i', $request_uri)) {
        header('Cache-Control: no-cache, no-store, must-revalidate, private', true);
        header('Pragma: no-cache', true);
        header('Expires: 0', true);
    }
    
    // ===== CONTENT-TYPE HEADERS =====
    // Service Worker als JavaScript
    if (strpos($request_uri, 'service-worker.js') !== false) {
        header('Content-Type: application/javascript; charset=utf-8', true);
    }
    // Manifest als JSON
    elseif (strpos($request_uri, 'manifest.json') !== false) {
        header('Content-Type: application/manifest+json; charset=utf-8', true);
    }
    
    // ===== GZIP KOMPRESSION =====
    if (!headers_sent('Content-Encoding')) {
        if (extension_loaded('zlib') && strpos($_SERVER['HTTP_ACCEPT_ENCODING'] ?? '', 'gzip') !== false) {
            ob_start('ob_gzhandler');
        }
    }
}
?>