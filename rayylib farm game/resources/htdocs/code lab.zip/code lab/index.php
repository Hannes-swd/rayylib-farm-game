<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <meta name="description" content="Code Lab - Schulverwaltung und Kursverwaltung">
    <meta name="theme-color" content="#667eea">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="apple-mobile-web-app-title" content="Code Lab">
    
    <!-- PWA Manifest -->
    <link rel="manifest" href="manifest.json">
    
    <!-- iOS Icons -->
    <link rel="apple-touch-icon" href="images/Logo.png">
    <link rel="icon" type="image/png" sizes="192x192" href="images/Logo.png">
    <link rel="icon" type="image/png" sizes="512x512" href="images/Logo.png">
    <link rel="shortcut icon" href="images/Logo.png">
    
    <!-- Styles -->
    <link rel="stylesheet" href="style.css">
    
    <title>Code Lab - Login</title>
    
    <script>
        // Service Worker Registration
        if ('serviceWorker' in navigator) {
            window.addEventListener('load', () => {
                navigator.serviceWorker.register('service-worker.js')
                    .then(registration => {
                        console.log('Service Worker registriert:', registration);
                    })
                    .catch(error => {
                        console.log('Service Worker Registrierung fehlgeschlagen:', error);
                    });
            });
        }

        // PWA Install-Prompt Handler
        let deferredPrompt;
        window.addEventListener('beforeinstallprompt', (e) => {
            // Verhindere das automatische Mini-Infobar
            e.preventDefault();
            // Speichere das Event für später
            deferredPrompt = e;
            console.log('PWA kann installiert werden');
        });

        // Optional: Button zum Installieren (kann im HTML platziert werden)
        window.installPWA = function() {
            if (deferredPrompt) {
                deferredPrompt.prompt();
                deferredPrompt.userChoice.then((choiceResult) => {
                    if (choiceResult.outcome === 'accepted') {
                        console.log('PWA installiert');
                    }
                    deferredPrompt = null;
                });
            }
        };

        // App-Installation erkannt
        window.addEventListener('appinstalled', () => {
            console.log('Code Lab wurde als PWA installiert');
            deferredPrompt = null;
        });
    </script>
</head>
<body class="app-login-bg">
    <?php
        session_start();
        $error = "";
        
        // Datenbankverbindung mit Fehlerbehandlung
        try {
            $pdo = new PDO('mysql:host=127.0.0.1;dbname=code_lab', 'root', '');
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            // Stelle sicher, dass remember_token Spalte existiert (sicherheitsnetz)
            try {
                $stmtCol = $pdo->prepare(
                    "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
                     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME = 'remember_token'"
                );
                $stmtCol->execute();
                $hasRememberCol = (int)$stmtCol->fetchColumn() > 0;
                if (!$hasRememberCol) {
                    $pdo->exec("ALTER TABLE users ADD COLUMN remember_token VARCHAR(255) DEFAULT NULL");
                }
            } catch (PDOException $e) {
                // nur loggen
                error_log("Could not ensure users.remember_token column (index.php): " . $e->getMessage());
            }
        } catch(PDOException $e) {
            $error = "Datenbankverbindung fehlgeschlagen: " . $e->getMessage();
        }

        // Wenn remember cookie vorhanden und noch keine Session -> Autologin versuchen
        if (empty($_SESSION['user_id']) && !empty($_COOKIE['remember_me']) && isset($pdo)) {
            try {
                $token = $_COOKIE['remember_me'];
                $stmt = $pdo->prepare("SELECT * FROM users WHERE remember_token = ? LIMIT 1");
                $stmt->execute([$token]);
                $u = $stmt->fetch(PDO::FETCH_ASSOC);
                if ($u) {
                    $_SESSION['user_id'] = intval($u['id']);
                    $_SESSION['username'] = $u['username'];
                    $_SESSION['roles'] = explode(',', $u['roles'] ?? '');
                    // rotate token
                    $newToken = bin2hex(random_bytes(32));
                    $stmt2 = $pdo->prepare("UPDATE users SET remember_token = ? WHERE id = ?");
                    $stmt2->execute([$newToken, $u['id']]);
                    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
                    setcookie('remember_me', $newToken, time() + 60*60*24*30, '/', '', $secure, true);
                    header("Location: Main.php");
                    exit;
                } else {
                    setcookie('remember_me', '', time() - 3600, '/', '', (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'), true);
                }
            } catch (Exception $e) {
                error_log("Autologin (index) failed: " . $e->getMessage());
            }
        }

        // Nur wenn Formular abgeschickt WIRKLICH abgeschickt wurde
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
            
            // Prüfen ob Felder ausgefüllt sind
            if (empty($_POST['username']) || empty($_POST['password'])) {
                $error = "Bitte füllen Sie alle Felder aus!";
            } else {
                // 1. Username aus Formular holen
                $username = trim($_POST['username']);
                $password = $_POST['password'];
                
                try {
                    // 2. In Datenbank nach User suchen
                    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
                    $stmt->execute([$username]);
                    $user = $stmt->fetch();
                    
                    // 3. Passwort überprüfen - NUR WENN USER EXISTIERT
                    if ($user) {
                        if (password_verify($password, $user['password_hash'])) {
                            // 4. Login erfolgreich - Session starten
                            $_SESSION['user_id'] = $user['id'];
                            $_SESSION['username'] = $user['username'];
                            $_SESSION['roles'] = explode(",", $user['roles']);

                            // Neuer: "Angemeldet bleiben" behandeln
                            if (!empty($_POST['remember'])) {
                                try {
                                    $token = bin2hex(random_bytes(32));
                                    $stmt = $pdo->prepare("UPDATE users SET remember_token = ? WHERE id = ?");
                                    $stmt->execute([$token, $user['id']]);
                                    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
                                    setcookie('remember_me', $token, time() + 60*60*24*30, '/', '', $secure, true);
                                } catch (Exception $e) {
                                    error_log("Failed setting remember token: " . $e->getMessage());
                                }
                            } else {
                                // Wenn Checkbox nicht gesetzt: remove any existing token/cookie
                                try {
                                    $stmt = $pdo->prepare("UPDATE users SET remember_token = NULL WHERE id = ?");
                                    $stmt->execute([$user['id']]);
                                } catch (Exception $e) { /* ignore */ }
                                setcookie('remember_me', '', time() - 3600, '/', '', (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'), true);
                            }

                            // 5. Weiterleiten
                            header("Location: Main.php");
                            exit;
                        } else {
                            $error = "Falsches Passwort!";
                        }
                    } else {
                        $error = "Benutzer nicht gefunden!";
                    }
                    
                } catch(PDOException $e) {
                    $error = "Datenbankfehler: " . $e->getMessage();
                }
            }
        }
    ?>
    
    <div class="app-login">
        <div class="app-login__logo">
            <h1>Code Lab</h1>
            <p>Willkommen zurück</p>
        </div>
        
        <form method="post">
            <div class="app-input-group">
                <div class="app-input-icon">👤</div>
                <input type="text" class="app-input" name="username" placeholder="Benutzername" required 
                       autocomplete="username">
            </div>
            
            <div class="app-input-group">
                <div class="app-input-icon">🔒</div>
                <input type="password" class="app-input" name="password" placeholder="Passwort" required
                       autocomplete="current-password">
            </div>
            
            <button type="submit" class="app-btn--login" name="login">Anmelden</button>
            
            <div class="app-additional-options">
                <div class="app-remember">
                    <input type="checkbox" id="remember" name="remember" autocomplete="off"
                        <?php echo (!empty($_COOKIE['remember_me']) ? 'checked' : ''); ?>>
                    <label for="remember">Angemeldet bleiben</label>
                </div>
                <a href="#" class="app-forgot-password">Passwort vergessen?</a>
            </div>
        </form>
        
        <?php if (!empty($error)): ?>
            <div class="error-message" style="color: red; text-align: center; margin-top: 10px; padding: 10px; background: #ffe6e6; border: 1px solid red; border-radius: 5px;">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>
    </div>
    <script>
    // Service Worker registrieren
    if ('serviceWorker' in navigator) {
        window.addEventListener('load', () => {
            navigator.serviceWorker.register('service-worker.js', { scope: '/' })
                .then((registration) => {
                    console.log('✅ Service Worker erfolgreich registriert:', registration);
                })
                .catch((error) => {
                    console.error('❌ Service Worker Registrierung fehlgeschlagen:', error);
                });
        });
    } else {
        console.warn('⚠️ Service Worker nicht unterstützt');
    }
</script>
</body>
</body>
</html>