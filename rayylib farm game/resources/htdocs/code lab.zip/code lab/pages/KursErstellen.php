<?php
if (!hasRole('admin')) {
    echo "<div class='app-card'><h1>Zugriff verweigert</h1><p>Nur Administratoren können Kurse hinzufügen.</p></div>";
    return;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_course'])) {
    $name = trim($_POST['name'] ?? '');
    $info = trim($_POST['info'] ?? '');
    $farb_code = trim($_POST['farb_code'] ?? '#3498db');

    if ($name === '') {
        $error = 'Bitte alle Felder ausfüllen.';
    } elseif (strlen($name) < 2) {
        $error = 'Kursname muss mindestens 2 Zeichen lang sein.';
    } else {
        try {
            $stmt = $pdo->prepare("SELECT COUNT(*) as cnt FROM kurse WHERE name = ?");
            $stmt->execute([$name]);
            $exists = $stmt->fetchColumn();
            if ($exists) {
                $error = 'Kursname ist bereits vergeben.';
            } else {
                $stmt = $pdo->prepare("INSERT INTO kurse (name, info, farb_code) VALUES (?, ?, ?)");
                $stmt->execute([$name, $info, $farb_code]);
                $success = 'Kurs erfolgreich angelegt.';

                $name = $info = $farb_code = '';
            }
        } catch (PDOException $e) {
            $error = 'Datenbankfehler: ' . $e->getMessage();
        }
    }
}
?>

<h1 class="app-users-add-title">Neuen Kurs hinzufügen</h1>
    <?php if ($error): ?>
        <div style="color: #b00020; background:#ffe6e6; padding:10px; border-radius:6px; margin-top:10px;">
            <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div style="color: #155724; background:#e6ffe6; padding:10px; border-radius:6px; margin-top:10px;">
            <?php echo htmlspecialchars($success); ?>
        </div>
    <?php endif; ?>
<div class="app-form--create-user">
    <form method="post" style="margin-top:20px; max-width:480px;">
        <label style="display:block; margin-bottom:6px;">Kursname</label>
        <input type="text" name="name" value="<?php echo htmlspecialchars($name ?? ''); ?>" required style="width:100%; padding:10px; margin-bottom:12px;">

        <label style="display:block; margin-bottom:6px;">Kursinformation</label>
        <textarea name="info" style="width:100%; padding:10px; margin-bottom:12px; height:80px;"><?php echo htmlspecialchars($info ?? ''); ?></textarea>

        <label style="display:block; margin-bottom:6px;">Farbe</label>
        <input type="color" name="farb_code" value="<?php echo htmlspecialchars($farb_code ?? '#3498db'); ?>" style="width:100%; padding:10px; margin-bottom:12px; height:50px;">

        <button type="submit" name="add_course" style="padding:10px 16px; background:#3498db; color:white; border:none; border-radius:6px; cursor:pointer;">
            Kurs erstellen
        </button>
    </form>
</div>