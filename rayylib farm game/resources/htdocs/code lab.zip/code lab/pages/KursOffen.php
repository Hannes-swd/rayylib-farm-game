<?php
$course = null;
$course_id = isset($_GET['course_id']) ? intval($_GET['course_id']) : 0;
if ($course_id > 0) {
    try {
        $stmt = $pdo->prepare("SELECT id, name, info, farb_code FROM kurse WHERE id = ?");
        $stmt->execute([$course_id]);
        $course = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        $course = null;
    }
}

// neue Hilfsfunktion: Hex -> rgba (nur definieren, wenn noch nicht vorhanden)
if (!function_exists('hexToRgba')) {
    function hexToRgba($hex, $alpha = 0.12) {
        $hex = ltrim($hex, '#');
        if (strlen($hex) === 3) {
            $r = hexdec(str_repeat($hex[0],2));
            $g = hexdec(str_repeat($hex[1],2));
            $b = hexdec(str_repeat($hex[2],2));
        } else {
            $r = hexdec(substr($hex,0,2));
            $g = hexdec(substr($hex,2,2));
            $b = hexdec(substr($hex,4,2));
        }
        return "rgba($r,$g,$b,$alpha)";
    }
}

$mobileBg = hexToRgba($course['farb_code'] ?? '#8fbced', 0.12);

// Sicherheitscheck: Nicht-Admins dürfen nur auf ihre eigenen Kurse zugreifen
if ($course) {
    if (!function_exists('hasRole')) {
        // Fallback falls hasRole nicht verfügbar – einfache Prüfung
        $isAdmin = isset($user['roles']) && str_contains($user['roles'], 'admin');
    } else {
        $isAdmin = hasRole('admin');
    }

    if (!$isAdmin) {
        $userCourses = array_filter(array_map('trim', explode(',', $user['courses'] ?? '')));
        // Wenn Kurs-Name nicht in den zugewiesenen Kursen des Nutzers ist: Zugriff verweigern
        if (!in_array($course['name'], $userCourses, true)) {
            echo "<div class='app-card' style='padding:20px;'><h2>Zugriff verweigert</h2><p>Sie haben keine Berechtigung, diesen Kurs anzusehen.</p></div>";
            return;
        }
    }
}

// --- NEU: gruppierte Nutzer für die Kurs-Detailseite laden ---
$admins = $lehrers = $schuelers = [];
try {
    $courseName = trim($course['name'] ?? '');
    if ($courseName !== '') {
        // Normalisiere spaces in courses-Feld und prüfe per FIND_IN_SET
        $stmt = $pdo->prepare("SELECT id, username, roles FROM users WHERE roles LIKE ? AND FIND_IN_SET(?, REPLACE(COALESCE(courses,''), ' ', '')) ORDER BY username");
        // Admins
        $stmt->execute(['%admin%', $courseName]);
        $admins = $stmt->fetchAll(PDO::FETCH_ASSOC);
        // Lehrer
        $stmt->execute(['%lehrer%', $courseName]);
        $lehrers = $stmt->fetchAll(PDO::FETCH_ASSOC);
        // Schüler
        $stmt->execute(['%schueler%', $courseName]);
        $schuelers = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        // kein Kursname -> leere Listen
        $admins = $lehrers = $schuelers = [];
    }
} catch (PDOException $e) {
    // ignore - still render page
}
?>
<?php if ($course): ?>
    <!-- Mobile Header (nur auf schmalen Bildschirmen) -->
    <div class="kurs-mobile-header" style="background-color: <?php echo $mobileBg; ?>; 
                color: #111; padding: 20px; margin: 0; 
                display: flex; align-items: center; justify-content: space-between; gap: 20px;">
        
        <div style="flex: 1;">
            <h1 style="margin: 0 0 8px 0; font-size: 24px; font-weight: 600; color: #111;">
                <?php echo htmlspecialchars($course['name']); ?>
            </h1>
            <p style="margin: 0; opacity: 0.95; font-size: 13px; line-height: 1.4; color:#111;">
                <?php echo nl2br(htmlspecialchars($course['info'] ?? 'Keine Beschreibung vorhanden.')); ?>
            </p>
        </div>

        <!-- Dropdown für weitere Infos (Mobile) -->
        <div style="position: relative; flex-shrink: 0;">
            <button id="courseInfoBtn" class="app-btn--edit-courses" 
                    style="background: rgba(17,17,17,0.06); color: #111; border: 1px solid rgba(0,0,0,0.08); padding: 10px 16px; cursor: pointer; border-radius: 6px;"
                    onclick="toggleCourseInfoDropdown(event)">
                ☰
            </button>
            
            <div id="courseInfoDropdown" style="display: none; position: absolute; top: 45px; right: 0; 
                                               background: white; color: #333; border-radius: 8px; 
                                               box-shadow: 0 4px 12px rgba(0,0,0,0.15); 
                                               min-width: 250px; z-index: 1000; overflow: hidden;">
                
                <div style="padding: 16px; border-bottom: 1px solid #dadce0;">
                    <h3 style="margin: 0 0 8px 0; font-size: 13px; color: #70757a; text-transform: uppercase; letter-spacing: 0.5px;">
                        Menü
                    </h3>
                </div>
                <div style="padding: 12px 16px;">
                    <a href="" class="app-nav-link kurs-detail-sidebar__link">
                        <div>
                            <p>Benutzer</p>
                        </div>
                    </a>
                </div>
                <hr>
                <?php
                /*
                <div style="padding: 16px; border-bottom: 1px solid #dadce0;">
                    <h3 style="margin: 0 0 8px 0; font-size: 13px; color: #70757a; text-transform: uppercase; letter-spacing: 0.5px;">
                        Tabellen
                    </h3>
                </div>
                <div style="padding: 12px 16px;">
                    <a href="" class="app-nav-link kurs-detail-sidebar__link">
                        <div>
                            <p>tabelle 1</p>
                        </div>
                    </a>
                    <a href="" class="app-nav-link kurs-detail-sidebar__link">
                        <div>
                            <p>tabelle 2</p>
                        </div>
                    </a>
                </div>
                */
                ?>
            </div>
        </div>
    </div>

    <!-- Kurs Content -->
    <div class="app-card" style="margin: 0; padding: 24px;">
        <?php if (empty($has_second_sidebar)): // Auf breiten Bildschirmen zeigt das Sidepanel bereits den Namen ?>
            <h2 style="color:#111;"><?php echo htmlspecialchars($course['name']); ?></h2>
            <p style="color:#111;"><?php echo nl2br(htmlspecialchars($course['info'])); ?></p>
        <?php endif; ?>

        <!-- Gruppierte Benutzer-Liste (vereinfachte Spalten: Checkbox | Name | Rolle) -->
        <div style="margin-top:20px;">
            <div class="app-users-header" style="margin-bottom:12px; display: flex; justify-content: space-between; align-items: center; gap: 16px;">
                <!-- Desktop Actions - nur für Lehrer und Admin (LINKS) -->
                <?php if (hasRole('admin') || hasRole('lehrer')): ?>
                <div style="display: flex; gap: 8px; flex-shrink: 0;">
                    <button class="kursaktionbtn" id="createTerminBtn" title="Termin erstellen" onclick="openTerminModalForSelected()">
                        <img src="images/kalender.png" alt="Termin erstellen" title="Termin erstellen" width="20" height="20">
                    </button>

                    <!-- GEÄNDERT: Hausaufgabe Button löst Modal aus -->
                    <button class="kursaktionbtn" title="Hausaufgabe" onclick="openHausaufgabeModal()">
                        <img src="images/hausaufgabe.png" alt="Hausaufgabe" title="Hausaufgabe erstellen" width="20" height="20">
                    </button>

                    <button class="kursaktionbtn" title="Note eintragen" onclick="openNoteModal()">
                        <img src="images/note.png" alt="Note eintragen" title="Note eintragen" width="20" height="20">
                    </button>
                    <!-- GEÄNDERT: Eintragungen öffnet neues Modal -->
                    <button class="kursaktionbtn" title="Eintragungen" onclick="openEintragModal()">
                        <img src="images/warning.png" alt="Eintragungen" title="Eintragungen vornehmen" width="20" height="20">
                    </button>
                </div>
                <?php else: ?>
                <div></div>
                <?php endif; ?>
                
                <!-- Suchleiste (RECHTS) -->
                <input type="text" id="courseUserSearch" class="app-users-search" placeholder="Suchen..." style="margin-left: auto;">
            </div>

            <!-- Spalten-Header: 3 Spalten -->
            <div class="app-users-row" id="usersHeader">
                <div class="app-col--checkbox" style="display:flex; align-items:center; justify-content:center;">
                    <input type="checkbox" id="selectAllCourseUsers" class="round-checkbox" />
                </div>

                <div class="app-col--name" style="display:flex; align-items:center;">
                    <p>Name</p>
                </div>

                <div style="display:flex; align-items:center;">
                    <p>Rollen</p>
                </div>

                <div class="app-resizers" aria-hidden="true"></div>
            </div>

            <div>
                 <details>
                     <summary>Admin (<?php echo count($admins); ?>)</summary>
                     <?php foreach($admins as $u): 
                         $searchString = strtolower($u['username'] . ' ' . $u['roles']);
                     ?>
                         <div class="app-users-row" data-name="<?php echo htmlspecialchars($searchString); ?>">
                             <!-- Spalte 1: Checkbox -->
                             <div class="app-col--checkbox" style="display:flex; align-items:center; justify-content:center;">
                                 <input type="checkbox" class="kurs-user-checkbox round-checkbox" data-userid="<?php echo intval($u['id']); ?>">
                             </div>

                             <!-- Spalte 2: Name -->
                             <div class="app-col--name">
                                 <a href="?page=benutzerOffen&user_id=<?php echo intval($u['id']); ?>" style="text-decoration:none; color:inherit; display:flex; align-items:center; width:100%; height:100%;">
                                     <p><?php echo htmlspecialchars($u['username']); ?></p>
                                 </a>
                             </div>

                             <!-- Spalte 3: Rollen -->
                             <div style="display:flex; align-items:center;">
                                 <p><?php echo htmlspecialchars($u['roles']); ?></p>
                             </div>
                         </div>
                     <?php endforeach; ?>
                 </details>

                 <details>
                     <summary>Lehrer (<?php echo count($lehrers); ?>)</summary>
                     <?php foreach($lehrers as $u): 
                         $searchString = strtolower($u['username'] . ' ' . $u['roles']);
                     ?>
                         <div class="app-users-row" data-name="<?php echo htmlspecialchars($searchString); ?>">
                             <!-- Spalte 1: Checkbox -->
                             <div class="app-col--checkbox" style="display:flex; align-items:center; justify-content:center;">
                                 <input type="checkbox" class="kurs-user-checkbox round-checkbox" data-userid="<?php echo intval($u['id']); ?>">
                             </div>

                             <!-- Spalte 2: Name -->
                             <div class="app-col--name">
                                 <a href="?page=benutzerOffen&user_id=<?php echo intval($u['id']); ?>" style="text-decoration:none; color:inherit; display:flex; align-items:center; width:100%; height:100%;">
                                     <p><?php echo htmlspecialchars($u['username']); ?></p>
                                 </a>
                             </div>

                             <!-- Spalte 3: Rollen -->
                             <div style="display:flex; align-items:center;">
                                 <p><?php echo htmlspecialchars($u['roles']); ?></p>
                             </div>
                         </div>
                     <?php endforeach; ?>
                 </details>

                 <details>
                     <summary>Schüler (<?php echo count($schuelers); ?>)</summary>
                     <?php foreach($schuelers as $u): 
                         $searchString = strtolower($u['username'] . ' ' . $u['roles']);
                     ?>
                         <div class="app-users-row" data-name="<?php echo htmlspecialchars($searchString); ?>">
                             <!-- Spalte 1: Checkbox -->
                             <div class="app-col--checkbox" style="display:flex; align-items:center; justify-content:center;">
                                 <input type="checkbox" class="kurs-user-checkbox round-checkbox" data-userid="<?php echo intval($u['id']); ?>">
                             </div>

                             <!-- Spalte 2: Name -->
                             <div class="app-col--name">
                                 <a href="?page=benutzerOffen&user_id=<?php echo intval($u['id']); ?>" style="text-decoration:none; color:inherit; display:flex; align-items:center; width:100%; height:100%;">
                                     <p><?php echo htmlspecialchars($u['username']); ?></p>
                                 </a>
                             </div>

                             <!-- Spalte 3: Rollen -->
                             <div style="display:flex; align-items:center;">
                                 <p><?php echo htmlspecialchars($u['roles']); ?></p>
                             </div>
                         </div>
                     <?php endforeach; ?>
                 </details>
             </div>
         </div>
     </div>

     <!-- Termin Modal für ausgewählte Personen - NEU GESTYLT -->
     <div id="terminModalForSelected" class="cal-modal-overlay" style="display: none;" onclick="if(event.target===this) closeModal('terminModalForSelected')">
        <div class="cal-modal" role="dialog" aria-modal="true" aria-labelledby="terminModalTitle">
            <div class="cal-modal-header">
                <h3 class="cal-modal-title" id="terminModalTitle">Termin erstellen</h3>
                <button class="cal-modal-close" aria-label="Schließen" onclick="closeModal('terminModalForSelected')">×</button>
            </div>
            <div class="cal-modal-body">
                <form id="terminFormForSelected">
                    <div class="cal-form-group" style="margin-bottom:12px;">
                        <label class="cal-form-label" style="font-size:13px;">Titel *</label>
                        <input type="text" class="cal-form-input" id="terminTitle" required placeholder="z.B. Prüfung" style="padding:10px; font-size:13px;">
                    </div>
                    <div class="cal-form-group" style="margin-bottom:12px;">
                        <label class="cal-form-label" style="font-size:13px;">Datum *</label>
                        <input type="date" class="cal-form-input" id="terminDate" required style="padding:10px; font-size:13px;">
                    </div>
                    <div class="cal-form-group" style="margin-bottom:12px;">
                        <label class="cal-form-label" style="font-size:13px;">Uhrzeit (optional)</label>
                        <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px;">
                            <input type="time" class="cal-form-input" id="terminStartTime" style="padding:10px; font-size:13px;">
                            <input type="time" class="cal-form-input" id="terminEndTime" style="padding:10px; font-size:13px;">
                        </div>
                    </div>
                </form>
            </div>
            <div class="cal-modal-footer">
                <div style="margin-right:auto; font-size:13px; color:#70757a;">👥 <strong id="selectedCountDisplay">0</strong> Personen</div>
                <button class="cal-btn cal-btn-primary" onclick="saveTerminForSelected()">Termin erstellen</button>
            </div>
        </div>
    </div>

     <!-- Hausaufgabe Modal - MIT FRIST -->
    <div id="hausaufgabeModal" class="cal-modal-overlay" style="display:none;" onclick="if(event.target===this) closeModal('hausaufgabeModal')">
        <div class="cal-modal" role="dialog" aria-modal="true" aria-labelledby="hausaufgabeModalTitle">
            <div class="cal-modal-header">
                <h3 class="cal-modal-title" id="hausaufgabeModalTitle">Hausaufgabe</h3>
                <button class="cal-modal-close" aria-label="Schließen" onclick="closeModal('hausaufgabeModal')">×</button>
            </div>
            <div class="cal-modal-body">
                <form id="hausaufgabeForm">
                    <div class="cal-form-group">
                        <label class="cal-form-label" style="font-size:13px;">Titel *</label>
                        <input type="text" id="hausTitle" class="cal-form-input" style="padding:10px; font-size:13px;" required>
                    </div>
                    <div class="cal-form-group">
                        <label class="cal-form-label" style="font-size:13px;">Beschreibung</label>
                        <textarea id="hausText" class="cal-form-input" style="padding:10px; font-size:13px;"></textarea>
                    </div>
                    <div class="cal-form-group">
                        <label class="cal-form-label" style="font-size:13px;">Fällig am (optional)</label>
                        <input type="date" id="hausFrist" class="cal-form-input" style="padding:10px; font-size:13px;">
                    </div>
                </form>
            </div>
            <div class="cal-modal-footer">
                <div style="margin-right:auto; font-size:13px; color:#70757a;">👥 <strong id="hausSelectedCount">0</strong> Personen</div>
                <button class="cal-btn cal-btn-primary" onclick="saveHausaufgabe()">Speichern</button>
            </div>
        </div>
    </div>

     <!-- NOTEN Modal (fehlt -> verursacht JS-Error wenn openNoteModal() aufgerufen wird) -->
     <div id="noteModal" class="cal-modal-overlay" style="display:none;" onclick="if(event.target===this) closeModal('noteModal')">
        <div class="cal-modal" role="dialog" aria-modal="true" aria-labelledby="noteModalTitle">
            <div class="cal-modal-header">
                <h3 class="cal-modal-title" id="noteModalTitle">Note eintragen</h3>
                <button class="cal-modal-close" aria-label="Schließen" onclick="closeModal('noteModal')">×</button>
            </div>
            <div class="cal-modal-body">
                <form id="noteForm" enctype="multipart/form-data">
                    <div class="cal-form-group">
                        <label class="cal-form-label" style="font-size:13px;">Titel *</label>
                        <input type="text" id="noteTitel" class="cal-form-input" style="padding:10px; font-size:13px;" required>
                    </div>
                    <div class="cal-form-group">
                        <label class="cal-form-label" style="font-size:13px;">Note *</label>
                        <select id="noteGrade" class="cal-form-input" style="padding:10px; font-size:13px;" required>
                             <option value="">-- Bitte wählen --</option>
                             <option value="1">1 - Sehr gut</option>
                             <option value="2">2 - Gut</option>
                             <option value="3">3 - Befriedigend</option>
                             <option value="4">4 - Ausreichend</option>
                             <option value="5">5 - Mangelhaft</option>
                             <option value="6">6 - Ungenügend</option>
                         </select>
                    </div>
                    <div class="cal-form-group">
                        <label class="cal-form-label" style="font-size:13px;">Beschreibung (optional)</label>
                        <textarea id="noteBeschreibung" class="cal-form-input" rows="3" style="padding:10px; font-size:13px;"></textarea>
                    </div>
                    <div class="cal-form-group">
                        <label class="cal-form-label" style="font-size:13px;">Datei (optional)</label>
                        <input type="file" id="noteFile" class="cal-form-input" style="padding:8px;">
                    </div>
                </form>
            </div>
            <div class="cal-modal-footer">
                <div style="margin-right:auto; font-size:13px; color:#70757a;">👥 <strong id="noteSelectedCountDisplay">0</strong> Personen</div>
                <button class="cal-btn cal-btn-primary" onclick="saveNote()">Speichern</button>
            </div>
        </div>
    </div>

     <!-- NEU: Eintragungen Modal -->
     <div id="eintragModal" class="cal-modal-overlay" style="display:none;" onclick="if(event.target===this) closeModal('eintragModal')">
        <div class="cal-modal" role="dialog" aria-modal="true" aria-labelledby="eintragModalTitle" style="max-width:420px; border-radius:12px;">
            <div class="cal-modal-header">
                <h3 class="cal-modal-title" id="eintragModalTitle" style="font-size:16px; margin:0;">Neue Eintragung</h3>
                <button class="cal-modal-close" aria-label="Schließen" onclick="closeModal('eintragModal')" style="background:none; border:none; font-size:22px; cursor:pointer;">×</button>
            </div>
            <div class="cal-modal-body" style="padding:14px;">
                <!-- Hinweis: Anzahl ausgewählter Personen wurde bewusst in den Footer verschoben (konsistent mit anderen Modals) -->
                <div class="cal-form-group">
                    <label class="cal-form-label" style="font-size:13px;">Text *</label>
                    <textarea id="eintragText" class="cal-form-textarea" rows="5" placeholder="Eintragungstext..." required style="padding:10px; font-size:13px; width:100%;"></textarea>
                </div>
            </div>
            <div class="cal-modal-footer" style="padding:10px 14px; display:flex; align-items:center;">
                <div style="margin-right:auto; font-size:13px; color:#70757a;">👥 <strong id="eintragSelectedCountDisplay">0</strong> Personen • Datum: automatisch (heute)</div>
                <button class="cal-btn cal-btn-primary" onclick="saveEintrag()" style="padding:8px 12px; font-size:13px;">Speichern</button>
            </div>
        </div>
    </div>
 
     <style>
        /* global modal animation */
        @keyframes slideUp {
            from { opacity: 0; transform: translateY(12px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Overlay: sorgt für dunklen Hintergrund, zentrierung und scroll-sperre */
        .cal-modal-overlay,
        .app-modal-overlay {
            position: fixed;
            inset: 0;
            display: none; /* JS setzt display:flex beim Öffnen */
            align-items: center;
            justify-content: center;
            background: rgba(0,0,0,0.45);
            z-index: 20000;
            padding: 20px;
            -webkit-backdrop-filter: blur(4px);
            backdrop-filter: blur(4px);
        }

        /* Modal shell / panel */
        .cal-modal,
        .app-modal {
            background: #ffffff;
            border-radius: 14px;
            max-width: 640px;
            width: 92%;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 30px 80px rgba(16,24,40,0.35);
            border: 1px solid rgba(0,0,0,0.06);
            animation: slideUp 0.22s ease;
            -webkit-animation: slideUp 0.22s ease;
            padding: 0;
            box-sizing: border-box;
        }

        /* header / close */
        .cal-modal-header, .app-modal .cal-modal-header {
            padding: 16px 18px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 1px solid #eef2f6;
            background: linear-gradient(90deg, rgba(25,103,210,0.02), rgba(46,204,113,0.01));
            border-top-left-radius: 14px;
            border-top-right-radius: 14px;
        }

        .cal-modal-title { margin:0; font-size:16px; font-weight:600; color:#202124; }

        .cal-modal-close {
            width: 34px; height: 34px; border-radius:8px; border:none; background:transparent; cursor:pointer; font-size:20px; color:#5f6368;
            display:inline-flex; align-items:center; justify-content:center;
        }
        .cal-modal-close:hover { background:#f5f7fa; transform: translateY(-1px); }

        /* body & footer */
        .cal-modal-body, .app-modal .cal-modal-body {
            padding: 16px 18px;
            background: #fff;
        }

        .cal-modal-footer, .app-modal .cal-modal-footer {
            padding: 12px 16px;
            border-top: 1px solid #eef2f6;
            display:flex;
            justify-content:flex-end;
            gap:10px;
            background: linear-gradient(180deg,#fff,#fbfdff);
            border-bottom-left-radius: 14px;
            border-bottom-right-radius: 14px;
        }

        /* inputs */
        .cal-form-input, .cal-form-select, .cal-form-textarea {
            width:100%;
            padding:10px 12px;
            border-radius:10px;
            border:1px solid #e6edf3;
            background:#fbfdff;
            font-size:14px;
            box-sizing:border-box;
        }

        .cal-form-input:focus, .cal-form-textarea:focus, .cal-form-select:focus {
            outline:none;
            border-color:#1967d2;
            box-shadow:0 6px 20px rgba(26,115,232,0.06);
        }

        /* compact variants for small modals (makes them look neat) */
        .cal-modal.small { max-width: 460px; padding:0; }
        .cal-modal .cal-form-group { margin-bottom:12px; }

        /* ensure overlay visible when JS sets display:flex */
        .cal-modal-overlay[style*="display: flex"],
        .app-modal-overlay[style*="display: flex"] {
            display: flex !important;
        }

        /* keep existing focused-file rules (compat) */
        #terminModalForSelected .cal-form-input:focus { outline: none; border-color: #1967d2; box-shadow: 0 0 0 3px rgba(25,103,210,0.1); }
        #noteModal .cal-form-input:focus { outline: none; border-color: #1967d2; box-shadow: 0 0 0 3px rgba(25,103,210,0.1); }
        #hausaufgabeModal .cal-form-input:focus { outline: none; border-color: #1967d2; box-shadow: 0 0 0 3px rgba(25,103,210,0.1); }
        #eintragModal .cal-form-input:focus { outline: none; border-color: #1967d2; box-shadow: 0 0 0 3px rgba(25,103,210,0.1); }
    </style>

     <script>
         const courseId = <?php echo intval($course_id); ?>;

         // Helper: öffnet ein Modal (verschiebt ins body, setzt zwingend fixed-overlay styles, setzt Fokus)
        function openModal(id, focusSelector) {
            const el = document.getElementById(id);
            if (!el) return;

            // Immer ins body verschieben (sorgt dafür, dass es über allem liegt)
            if (el.parentElement !== document.body) {
                document.body.appendChild(el);
            }

            // Erzwinge Overlay-Stile inline (überschreibt lokale CSS-Probleme)
            el.style.position = 'fixed';
            el.style.left = '0';
            el.style.top = '0';
            el.style.right = '0';
            el.style.bottom = '0';
            el.style.inset = '0';
            el.style.display = 'flex';
            el.style.alignItems = 'center';
            el.style.justifyContent = 'center';
            el.style.zIndex = '20000';
            // Falls kein Hintergrund in CSS vorhanden ist, setze fallback
            if (!el.style.background || el.style.background === '') {
                el.style.background = 'rgba(0,0,0,0.45)';
            }
            el.style.padding = el.style.padding || '20px';
            // Entferne evtl. overflow auf body, damit modals scrollen können
            document.body.style.overflow = 'hidden';

            // Stelle sicher, dass das Modal-Shell vernünftige Breiten/Höhen hat
            const shell = el.querySelector('.cal-modal, .app-modal');
            if (shell) {
                shell.style.maxWidth = shell.style.maxWidth || '640px';
                shell.style.width = shell.style.width || '92%';
                shell.style.maxHeight = shell.style.maxHeight || '90vh';
                shell.style.overflowY = shell.style.overflowY || 'auto';
                shell.style.margin = '0 auto';
            }

            // Fokus auf erstes Eingabefeld
            if (focusSelector) {
                setTimeout(() => {
                    const f = el.querySelector(focusSelector);
                    if (f) f.focus();
                }, 50);
            }
        }

        function closeModal(id) {
            const el = document.getElementById(id);
            if (!el) return;
            el.style.display = 'none';
            // Body-Scroll nur wieder aktivieren, falls keine anderen modals offen sind
            const anyOpen = Array.from(document.querySelectorAll('.cal-modal-overlay, .app-modal-overlay'))
                .some(o => o.style && (o.style.display === 'flex' || o.style.display === 'block'));
            if (!anyOpen) {
                document.body.style.overflow = '';
            }
        }

        function closeAllModals() {
            ['terminModalForSelected','noteModal','hausaufgabeModal','eintragModal','calEventModal','calEventDetailsModal','courseModal','rolesModal']
                .forEach(id => closeModal(id));
        }

        // Escape schließt alle Modals
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                closeAllModals();
            }
        });

         // === Termine ===
         function openTerminModalForSelected() {
             const checkedBoxes = document.querySelectorAll('.kurs-user-checkbox:checked');
             if (checkedBoxes.length === 0) {
                 alert('Bitte wählen Sie mindestens eine Person aus');
                 return;
             }

             document.getElementById('selectedCountDisplay').textContent = checkedBoxes.length;

             // Setze heute als Standard-Datum
             const today = new Date().toISOString().split('T')[0];
             const dateInput = document.getElementById('terminDate');
             if (dateInput) dateInput.value = today;

             // Form reset
             const title = document.getElementById('terminTitle');
             if (title) title.value = '';

             openModal('terminModalForSelected', '#terminTitle');
         }

         function closeTerminModalForSelected() {
             closeModal('terminModalForSelected');
         }

         // === Noten ===
         async function openNoteModal() {
             const checkedBoxes = document.querySelectorAll('.kurs-user-checkbox:checked');
             if (checkedBoxes.length === 0) {
                 alert('Bitte wählen Sie mindestens eine Person aus');
                 return;
             }
             document.getElementById('noteSelectedCountDisplay').textContent = checkedBoxes.length;
             const f = document.getElementById('noteForm');
             if (f) f.reset();
             openModal('noteModal', '#noteTitel');
         }

         function closeNoteModal() {
             closeModal('noteModal');
         }

         // === Hausaufgabe ===
         function openHausaufgabeModal() {
             const checked = document.querySelectorAll('.kurs-user-checkbox:checked');
             if (checked.length === 0) {
                 alert('Bitte wählen Sie mindestens eine Person aus');
                 return;
             }
             document.getElementById('hausSelectedCount').textContent = checked.length;
             const f = document.getElementById('hausaufgabeForm');
             if (f) f.reset();
             openModal('hausaufgabeModal', '#hausTitle');
         }

         function closeHausaufgabeModal() {
             closeModal('hausaufgabeModal');
         }

         // === Eintragungen ===
         // === Eintragungen ===
        function openEintragModal() {
            const checked = document.querySelectorAll('.kurs-user-checkbox:checked');
            if (checked.length === 0) {
                alert('Bitte wählen Sie mindestens eine Person aus');
                return;
            }
            document.getElementById('eintragSelectedCountDisplay').textContent = checked.length;
            const f = document.getElementById('eintragText');
            if (f) f.value = '';  // Text clearen
            openModal('eintragModal', '#eintragText');
        }

        function closeEintragModal() {
            closeModal('eintragModal');
        }

        function closeHausaufgabeModal() {
            closeModal('hausaufgabeModal');
        }

        // Save Eintragung (AJAX)
        async function saveEintrag() {
            const text = (document.getElementById('eintragText') || {}).value || '';
            if (text.trim() === '') { alert('Bitte Text eingeben'); return; }

            const checkedBoxes = document.querySelectorAll('.kurs-user-checkbox:checked');
            const userIds = Array.from(checkedBoxes).map(cb => parseInt(cb.dataset.userid, 10)).filter(Boolean);
            if (userIds.length === 0) { alert('Keine Personen ausgewählt'); return; }

            const fd = new FormData();
            fd.append('action', 'create_eintragung');
            fd.append('kurs_id', courseId);
            fd.append('text', text.trim());
            fd.append('user_ids', JSON.stringify(userIds));

            try {
                const resp = await fetch('Main.php', {
                    method: 'POST',
                    body: fd,
                    credentials: 'same-origin'
                });
                const data = await resp.json();
                if (data && data.success) {
                    closeEintragModal();
                    alert('Eintragungen erstellt (' + (data.inserted || 0) + ')');
                    // optional: uncheck boxes / refresh UI
                    document.querySelectorAll('.kurs-user-checkbox:checked').forEach(cb => { cb.checked = false; });
                } else {
                    alert('Fehler: ' + (data.error || data.message || 'Unbekannter Fehler'));
                }
            } catch (e) {
                console.error('saveEintrag error', e);
                alert('Fehler beim Erstellen der Eintragung');
            }
        }

        // --- NEU: Funktionen für Modal-Save-Buttons (Termin, Hausaufgabe, Note) ---
        // saveTerminForSelected: erstellt einen Termin für den Kurs (serverseitig: create_termin)
        async function saveTerminForSelected() {
            const title = (document.getElementById('terminTitle') || {}).value || '';
            const date = (document.getElementById('terminDate') || {}).value || '';
            const start = (document.getElementById('terminStartTime') || {}).value || '';
            const end = (document.getElementById('terminEndTime') || {}).value || '';

            if (!title.trim() || !date) { alert('Bitte Titel und Datum angeben'); return; }

            const fd = new FormData();
            fd.append('action', 'create_termin');
            fd.append('kurs_id', courseId);
            fd.append('titel', title.trim());
            fd.append('notiz', '');
            fd.append('datum', date);
            fd.append('uhrzeit_start', start);
            fd.append('uhrzeit_end', end);

            try {
                const resp = await fetch('Main.php', { method: 'POST', body: fd, credentials: 'same-origin' });
                const data = await resp.json();
                if (data && data.success) {
                    closeModal('terminModalForSelected');
                    alert('Termin erstellt');
                    // optional: uncheck selected users
                    document.querySelectorAll('.kurs-user-checkbox:checked').forEach(cb => cb.checked = false);
                } else {
                    alert('Fehler beim Erstellen des Termins: ' + (data.error || data.message || 'Unbekannt'));
                }
            } catch (e) {
                console.error('saveTerminForSelected error', e);
                alert('Fehler beim Erstellen des Termins');
            }
        }

        // saveHausaufgabe: legt für alle ausgewählten Nutzer eine Eintragung (eintragungen) mit Text an
        async function saveHausaufgabe() {
            const title = (document.getElementById('hausTitle') || {}).value || '';
            const text = (document.getElementById('hausText') || {}).value || '';
            const frist = (document.getElementById('hausFrist') || {}).value || '';
            const checked = Array.from(document.querySelectorAll('.kurs-user-checkbox:checked'))
                                .map(cb => parseInt(cb.dataset.userid,10)).filter(Boolean);
            
            if (checked.length === 0) { alert('Bitte mindestens eine Person auswählen'); return; }
            if (!title.trim()) { alert('Bitte Titel eingeben'); return; }

            const fd = new FormData();
            fd.append('action', 'create_hausaufgabe');
            fd.append('kurs_id', courseId);
            fd.append('titel', title.trim());
            fd.append('beschreibung', text.trim());
            fd.append('frist', frist);
            fd.append('user_ids', JSON.stringify(checked));

            try {
                const resp = await fetch('Main.php', { method: 'POST', body: fd, credentials: 'same-origin' });
                const data = await resp.json();
                console.log('create_hausaufgabe response', data);
                
                if (data && data.success) {
                    closeModal('hausaufgabeModal');
                    alert('Hausaufgabe erstellt für ' + (data.inserted ?? checked.length) + ' Benutzer');
                    document.querySelectorAll('.kurs-user-checkbox:checked').forEach(cb => cb.checked = false);
                } else {
                    alert('Fehler beim Speichern: ' + (data.error || data.message || 'Unbekannt'));
                }
            } catch (e) {
                console.error('saveHausaufgabe error', e);
                alert('Fehler beim Speichern der Hausaufgabe');
            }
        }

        // saveNote: legt für jeden ausgewählten Nutzer eine Note an (serverseitig: create_note)
        async function saveNote() {
            const titel = (document.getElementById('noteTitel') || {}).value || '';
            const grade = (document.getElementById('noteGrade') || {}).value || '';
            const beschreibung = (document.getElementById('noteBeschreibung') || {}).value || '';
            const fileInput = document.getElementById('noteFile');
            const file = fileInput && fileInput.files && fileInput.files[0] ? fileInput.files[0] : null;

            const checked = Array.from(document.querySelectorAll('.kurs-user-checkbox:checked'))
                                 .map(cb => parseInt(cb.dataset.userid,10)).filter(Boolean);
            if (checked.length === 0) { alert('Bitte mindestens eine Person auswählen'); return; }
            if (!titel.trim() || !grade) { alert('Bitte Titel und Note angeben'); return; }

            try {
                // sende eine Anfrage pro Nutzer (Backend create_note ist für Einzel-Note ausgelegt)
                const promises = checked.map(uid => {
                    const fd = new FormData();
                    fd.append('action', 'create_note');
                    fd.append('benutzer_id', uid);
                    fd.append('kurs_id', courseId);
                    fd.append('titel', titel.trim());
                    fd.append('note', grade);
                    fd.append('beschreibung', beschreibung.trim());
                    if (file) fd.append('datei', file, file.name);

                    return fetch('Main.php', { method: 'POST', body: fd, credentials: 'same-origin' })
                        .then(r => r.json())
                        .catch(e => ({ success: false, error: 'Network error', _e: e }));
                });

                const results = await Promise.all(promises);
                const successCount = results.filter(r => r && r.success).length;
                const fail = results.length - successCount;

                if (successCount > 0) {
                    closeModal('noteModal');
                    alert('Noten erstellt: ' + successCount + (fail ? ('; Fehler: ' + fail) : ''));
                    document.querySelectorAll('.kurs-user-checkbox:checked').forEach(cb => cb.checked = false);
                } else {
                    alert('Fehler beim Erstellen der Noten: ' + (results[0] && (results[0].error || results[0].message) || 'Unbekannt'));
                }
            } catch (e) {
                console.error('saveNote error', e);
                alert('Fehler beim Erstellen der Noten');
            }
        }
        // --- ENDE NEU ---
        
        // Toggle dropdown; verschiebe Content nur im Desktop-Viewport (>=1025px)
        function toggleCourseInfoDropdown(ev) {
            if (ev && ev.stopPropagation) ev.stopPropagation();
            const dropdown = document.getElementById('courseInfoDropdown');
            const appMain = document.querySelector('.app-main');

            const visible = window.getComputedStyle(dropdown).display !== 'none';
            const willOpen = !visible;
            dropdown.style.display = willOpen ? 'block' : 'none';

            if (appMain && window.matchMedia('(min-width:1025px)').matches) {
                appMain.classList.toggle('sidepanel-dropdown-open', willOpen);
            }
        }

        document.addEventListener('click', function(event) {
            const dropdown = document.getElementById('courseInfoDropdown');
            const btn = document.getElementById('courseInfoBtn');
            const appMain = document.querySelector('.app-main');

            if (!dropdown.contains(event.target) && !btn.contains(event.target)) {
                if (window.getComputedStyle(dropdown).display !== 'none') {
                    dropdown.style.display = 'none';
                }
                if (appMain && window.matchMedia('(min-width:1025px)').matches) {
                    appMain.classList.remove('sidepanel-dropdown-open');
                }
            }
        });

        // Checkbox-Logik für die Kurs-Benutzerliste
        (function(){
            const selectAll = document.getElementById('selectAllCourseUsers');
            const search = document.getElementById('courseUserSearch');
            const checkboxesSelector = '.kurs-user-checkbox.round-checkbox';
            
            function updateSelectAllState() {
                const visible = Array.from(document.querySelectorAll('.app-users-row')).filter(r => r.style.display !== 'none');
                const boxes = visible.map(r => r.querySelector(checkboxesSelector)).filter(Boolean);
                
                if (boxes.length === 0) { 
                    selectAll.checked = false; 
                    selectAll.indeterminate = false; 
                    return; 
                }
                
                const allChecked = boxes.every(b => b.checked);
                const anyChecked = boxes.some(b => b.checked);
                
                selectAll.checked = allChecked;
                selectAll.indeterminate = anyChecked && !allChecked;
            }

            selectAll.addEventListener('change', function(){
                const visible = Array.from(document.querySelectorAll('.app-users-row')).filter(r => r.style.display !== 'none');
                visible.forEach(r => {
                    const cb = r.querySelector(checkboxesSelector);
                    if (cb) cb.checked = selectAll.checked;
                });
                updateSelectAllState();
            });

            document.addEventListener('change', function(e){
                if (e.target && e.target.matches(checkboxesSelector)) {
                    updateSelectAllState();
                }
            });

            function filterUsers() {
                const term = (search.value || '').trim().toLowerCase();
                document.querySelectorAll('.app-users-row').forEach(row => {
                    const hay = (row.dataset.name || '').toLowerCase();
                    row.style.display = (term === '' || hay.includes(term)) ? '' : 'none';
                });
                updateSelectAllState();
            }

            search.addEventListener('input', filterUsers);

            setTimeout(updateSelectAllState, 50);
            
            document.querySelectorAll('.kurs-user-checkbox').forEach(cb => {
                if (!cb.classList.contains('round-checkbox')) {
                    cb.classList.add('round-checkbox');
                }
            });
        })();

        // Resizable Columns Logik für KursOffen (3 Spalten statt 4)
        (function(){
            const container = document.querySelector('.app-card');
            const header = document.getElementById('usersHeader');
            if (!container || !header) return;

            const getCols = () => Array.from(header.children).filter(c => !c.classList.contains('app-resizers'));
            const resizersContainer = header.querySelector('.app-resizers');

            // Minimalbreiten für 3 Spalten: Checkbox, Name, Rollen
            const minWidths = [40, 160, 120];

            function createResizers() {
                if (!resizersContainer) return;
                resizersContainer.innerHTML = '';
                const cols = getCols();
                
                // 2 Resizer für 3 Spalten
                for (let i = 0; i < cols.length - 1; i++) {
                    const r = document.createElement('div');
                    r.className = 'app-col-resizer';
                    r.dataset.index = i;
                    resizersContainer.appendChild(r);
                    r.addEventListener('mousedown', startDrag);
                }
            }

            function setInitialCols() {
                const cols = getCols();
                const headerW = Math.max(200, header.clientWidth || header.getBoundingClientRect().width);
                
                // Initiale Breiten für 3 Spalten - besser verteilt
                const initialWidths = [50, 300, 200];
                const perc = initialWidths.map(w => (w / headerW * 100));
                
                const newCols = perc.map(p => p.toFixed(6) + '%').join(' ');
                container.style.setProperty('--user-cols', newCols);
                
                document.querySelectorAll('.app-users-row').forEach(row => {
                    row.style.gridTemplateColumns = newCols;
                });
                
                updateResizerPositions();
            }

            function updateResizerPositions() {
                const headerW = Math.max(1, header.clientWidth || header.getBoundingClientRect().width);
                const colStr = getComputedStyle(container).getPropertyValue('--user-cols') || '';
                const parts = colStr.trim().split(/\s+/).map(s => parseFloat(s) || 0);
                
                let left = 0;
                const resizers = Array.from(resizersContainer.children);
                
                for (let i = 0; i < parts.length - 1; i++) {
                    left += headerW * (parts[i] / 100);
                    const r = resizers[i];
                    if (r) r.style.left = (left - (r.offsetWidth/2)) + 'px';
                }
            }

            let dragging = null;
            
            function startDrag(e) {
                e.preventDefault();
                const startX = e.clientX;
                const idx = parseInt(this.dataset.index, 10);
                const headerW = Math.max(200, header.clientWidth || header.getBoundingClientRect().width);

                const colStr = getComputedStyle(container).getPropertyValue('--user-cols') || '';
                const parts = colStr.trim().split(/\s+/).map(s => parseFloat(s) || 0);
                
                const currentWidths = parts.map(p => Math.round(headerW * (p / 100)));
                const pairSum = currentWidths[idx] + currentWidths[idx+1];
                const minLeft = minWidths[idx] || 40;
                const minRight = minWidths[idx+1] || 40;
                
                dragging = { idx, startX, currentWidths, pairSum, minLeft, minRight, headerW };

                function onMove(ev) {
                    const dx = ev.clientX - dragging.startX;
                    const leftStart = dragging.currentWidths[dragging.idx];
                    let newLeft = Math.round(leftStart + dx);
                    
                    newLeft = Math.max(dragging.minLeft, Math.min(newLeft, dragging.pairSum - dragging.minRight));
                    const newRight = Math.max(dragging.minRight, dragging.pairSum - newLeft);

                    const w = dragging.currentWidths.slice();
                    w[dragging.idx] = newLeft;
                    w[dragging.idx+1] = newRight;

                    const headerWNow = Math.max(1, header.clientWidth || header.getBoundingClientRect().width);
                    const perc = w.map(x => x / headerWNow * 100);

                    const normalized = perc.map((p,i) => {
                        return i === perc.length - 1 ? (100 - perc.slice(0, -1).reduce((a,b)=>a+b,0)) : p;
                    });

                    const newCols = normalized.map(p => p.toFixed(6) + '%').join(' ');
                    container.style.setProperty('--user-cols', newCols);
                    
                    document.querySelectorAll('.app-users-row').forEach(row => {
                        row.style.gridTemplateColumns = newCols;
                    });
                    
                    updateResizerPositions();
                }

                function onUp() {
                    document.removeEventListener('mousemove', onMove);
                    document.removeEventListener('mouseup', onUp);
                    dragging = null;
                }

                document.addEventListener('mousemove', onMove);
                document.addEventListener('mouseup', onUp);
            }

            // Initialisiere
            createResizers();
            setTimeout(setInitialCols, 100);
            
            // Bei Fenstergrößenänderung neu zentrieren
            window.addEventListener('resize', function(){
                setTimeout(setInitialCols, 50);
            });

        })();
     </script>

<?php else: ?>
    <div class="app-card" style="margin: 0; padding: 24px;">
        <h2>Kurs nicht gefunden</h2>
        <p>Der ausgewählte Kurs konnte nicht geladen werden.</p>
        <a href="?page=kurs" style="color: #1967d2; text-decoration: none; margin-top: 16px; display: inline-block;">
            ← Zurück zu Kurse
        </a>
    </div>
<?php endif; ?>