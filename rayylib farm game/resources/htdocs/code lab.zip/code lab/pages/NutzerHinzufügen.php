<?php


if (!hasRole('admin')) {
    echo "<div class='app-card'><h1>Zugriff verweigert</h1><p>Nur Administratoren können Benutzer hinzufügen.</p></div>";
    return;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_user'])) {
    $username = trim($_POST['username'] ?? '');

    $roles_selected = $_POST['roles'] ?? [];
    $password = $_POST['password'] ?? '';


    if ($username === '' || empty($roles_selected) || $password === '') {
        $error = 'Bitte alle Felder ausfüllen und mindestens eine Rolle wählen.';
    } else {

        $roles = array_values(array_unique(array_map('trim',$roles_selected)));
        try {

            $stmt = $pdo->prepare("SELECT COUNT(*) as cnt FROM users WHERE username = ?");
            $stmt->execute([$username]);
            $exists = $stmt->fetchColumn();
            if ($exists) {
                $error = 'Benutzername ist bereits vergeben.';
            } else {
                $password_hash = password_hash($password, PASSWORD_DEFAULT);
                $roles_csv = implode(',', $roles);
                $courses = ''; 
                $stmt = $pdo->prepare("INSERT INTO users (username, password_hash, roles, courses) VALUES (?, ?, ?, ?)");
                $stmt->execute([$username, $password_hash, $roles_csv, $courses]);
                $success = 'Benutzer erfolgreich angelegt.';

                $username = '';
                $roles_selected = [];
                $password = '';
            }
        } catch (PDOException $e) {
            $error = 'Datenbankfehler: ' . $e->getMessage();
        }
    }
}
?>
<h1 class="app-users-add-title">Neuer Nutzer hinzufügen</h1>
<div class="app-form--create-user">
    

    <?php if ($error): ?>
        <div style="color: #b00020; background:#ffe6e6; padding:10px; border-radius:6px; margin-top:10px;">
            <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div style="color: #155724; background:#e6ffe6; padding:10px; border-radius:6px; margin-top:10px;">
            <?php echo htmlspecialchars($success); ?>
        </div>
    <?php endif; ?>

    <form method="post" style="margin-top:20px; max-width:480px;">
        <label style="display:block; margin-bottom:6px;">Benutzername</label>
        <input type="text" name="username" value="<?php echo htmlspecialchars($username ?? ''); ?>" required style="width:100%; padding:10px; margin-bottom:12px;">

        <label style="display:block; margin-bottom:6px;">Rollen (mehrfach auswählbar)</label>
        <div style="display:flex; gap:12px; margin-bottom:12px; flex-wrap:wrap;">
            <label><input type="checkbox" name="roles[]" value="admin" <?php echo (isset($roles_selected) && in_array('admin',$roles_selected))?'checked':''; ?>> 🛡️ Administrator</label>
            <label><input type="checkbox" name="roles[]" value="lehrer" <?php echo (isset($roles_selected) && in_array('lehrer',$roles_selected))?'checked':''; ?>> 📚 Lehrer</label>
            <label><input type="checkbox" name="roles[]" value="schueler" <?php echo (isset($roles_selected) && in_array('schueler',$roles_selected))?'checked':''; ?>> 👨‍🎓 Schüler</label>
        </div>

        <label style="display:block; margin-bottom:6px;">Passwort</label>
        <input type="password" name="password" required style="width:100%; padding:10px; margin-bottom:12px;">

        <button type="submit" name="add_user" style="padding:10px 16px; background:#3498db; color:white; border:none; border-radius:6px; cursor:pointer;">
            Benutzer erstellen
        </button>
    </form>
</div>