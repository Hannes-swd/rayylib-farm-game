<?php
// Account page: Passwort ändern (wird innerhalb von Main.php gerendert, $user und $pdo sind verfügbar)
$accound_error = '';
$accound_success = '';

if (!isset($user) || empty($user['id'])) {
    echo "<div class='app-card'><h1>Zugriff verweigert</h1><p>Kein Benutzer gefunden.</p></div>";
    return;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    try {
        $current = $_POST['current_password'] ?? '';
        $new = $_POST['new_password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';

        if ($current === '' || $new === '' || $confirm === '') {
            throw new Exception('Bitte alle Felder ausfüllen.');
        }
        if ($new !== $confirm) {
            throw new Exception('Die neuen Passwörter stimmen nicht überein.');
        }
        if (strlen($new) < 6) {
            throw new Exception('Das neue Passwort muss mindestens 6 Zeichen lang sein.');
        }

        // Aktuellen Hash aus DB frisch laden
        $stmt = $pdo->prepare("SELECT password_hash FROM users WHERE id = ?");
        $stmt->execute([$user['id']]);
        $hash = $stmt->fetchColumn();

        if (!$hash || !password_verify($current, $hash)) {
            throw new Exception('Das aktuelle Passwort ist falsch.');
        }

        $new_hash = password_hash($new, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE users SET password_hash = ? WHERE id = ?");
        $stmt->execute([$new_hash, $user['id']]);

        $accound_success = 'Passwort erfolgreich geändert.';
    } catch (Exception $e) {
        $accound_error = $e->getMessage();
    }
}
?>
<div class="app-card" style="max-width:920px; margin:20px; padding:18px;">
    <h1>Account</h1>

    <?php if ($accound_success): ?>
        <div class="success-message" style="display:block; margin-top:12px; padding:10px;">
            <?php echo htmlspecialchars($accound_success); ?>
        </div>
    <?php elseif ($accound_error): ?>
        <div class="error-message" style="display:block; margin-top:12px;">
            <?php echo htmlspecialchars($accound_error); ?>
        </div>
    <?php endif; ?>

    <div class="account-container" style="display:flex; gap:24px; margin-top:18px; align-items:flex-start; flex-wrap:wrap;">
        <!-- Linke Spalte: Benutzerinfo -->
        <div style="flex:1 1 320px; min-width:260px; max-width:420px;">
            <div style="background:#f8f9fa; padding:16px; border-radius:10px;">
                <div style="display:flex; gap:12px; align-items:center;">
                    <div style="width:72px; height:72px; border-radius:50%; background:#2eb4cc; color:white; display:flex; align-items:center; justify-content:center; font-size:30px;">
                        <?php echo htmlspecialchars(strtoupper($user['username'][0] ?? 'U')); ?>
                    </div>
                    <div style="flex:1;">
                        <div style="font-weight:700; font-size:18px;"><?php echo htmlspecialchars($user['username']); ?></div>
                        <div style="color:#666; margin-top:6px;">Benutzername (nicht änderbar)</div>
                    </div>
                </div>

                <div style="margin-top:14px; font-size:14px; color:#444;">
                    <p style="margin:0 0 6px 0;"><strong>Rollen:</strong> <?php echo htmlspecialchars($user['roles'] ?? '—'); ?></p>
                    <p style="margin:0;"><strong>Kurse:</strong> <?php echo htmlspecialchars($user['courses'] ?? '—'); ?></p>
                </div>
            </div>
        </div>

        <!-- Rechte Spalte: Passwort ändern -->
        <div style="flex:1 1 360px; min-width:260px; max-width:560px;">
            <div style="background:#fff; padding:16px; border-radius:10px; border:1px solid #eef2f6;">
                <h2 style="margin-top:0; font-size:16px;">Passwort ändern</h2>
                <form method="post" id="changePasswordForm" onsubmit="return validatePasswordForm();">
                    <input type="hidden" name="change_password" value="1">
                    <div style="display:flex; flex-direction:column; gap:10px;">
                        <div>
                            <label style="display:block; font-weight:600; margin-bottom:6px;">Aktuelles Passwort</label>
                            <input name="current_password" id="current_password" type="password" class="cal-form-input" style="padding:10px;" required>
                        </div>

                        <div>
                            <label style="display:block; font-weight:600; margin-bottom:6px;">Neues Passwort</label>
                            <input name="new_password" id="new_password" type="password" class="cal-form-input" style="padding:10px;" required>
                        </div>

                        <div>
                            <label style="display:block; font-weight:600; margin-bottom:6px;">Neues Passwort bestätigen</label>
                            <input name="confirm_password" id="confirm_password" type="password" class="cal-form-input" style="padding:10px;" required>
                        </div>

                        <div style="display:flex; align-items:center; gap:10px;">
                            <label style="display:inline-flex; align-items:center; gap:8px; cursor:pointer;">
                                <input type="checkbox" id="toggleShow" style="width:18px;height:18px;">
                                <span style="font-size:14px; color:#666;">Passwörter anzeigen</span>
                            </label>
                            <div style="margin-left:auto; color:#888; font-size:13px;">Min. 6 Zeichen</div>
                        </div>

                        <div style="display:flex; gap:10px; margin-top:6px;">
                            <button type="submit" class="cal-btn cal-btn-primary" style="padding:10px 14px;">Passwort speichern</button>
                            <button type="button" class="cal-btn cal-btn-secondary" style="padding:10px 14px;" onclick="document.getElementById('changePasswordForm').reset();">Zurücksetzen</button>
                        </div>
                    </div>
                </form>
            </div>

            <div style="margin-top:12px; font-size:13px; color:#666;">
                Tipp: Wähle ein sicheres Passwort mit Groß-/Kleinbuchstaben, Zahlen und Sonderzeichen.
            </div>
        </div>
    </div>
</div>

<script>
(function(){
    const toggle = document.getElementById('toggleShow');
    const fields = ['current_password','new_password','confirm_password'].map(id => document.getElementById(id));
    if (toggle) {
        toggle.addEventListener('change', function(){
            fields.forEach(f => { if (f) f.type = this.checked ? 'text' : 'password'; });
        });
    }
})();

function validatePasswordForm() {
    const newP = document.getElementById('new_password').value || '';
    const conf = document.getElementById('confirm_password').value || '';
    if (newP.length < 6) {
        alert('Das neue Passwort muss mindestens 6 Zeichen lang sein.');
        return false;
    }
    if (newP !== conf) {
        alert('Die neuen Passwörter stimmen nicht überein.');
        return false;
    }
    return true;
}
</script>