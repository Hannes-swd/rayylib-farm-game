<?php
// Benutzer für Dropdown laden (nur Schüler für Anwesenheit)
$all_users_for_anwesenheit = [];

try {
    // Benutzer laden (nur Schüler für Anwesenheit)
    $stmt = $pdo->query("SELECT id, username FROM users WHERE roles LIKE '%schueler%' ORDER BY username");
    $all_users_for_anwesenheit = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    error_log("Error loading data for anwesenheit: " . $e->getMessage());
}
?>

<div class="app-card">
    <h1>Anwesenheit erfassen</h1>
    
    <div class="anwesenheit-container">
        <form id="anwesenheitForm" class="anwesenheit-form">
            <div class="form-group">
                <label class="form-label">Benutzer *</label>
                <select id="anwesenheitBenutzer" class="form-input" required>
                    <option value="">-- Benutzer auswählen --</option>
                    <?php foreach ($all_users_for_anwesenheit as $user_opt): ?>
                        <option value="<?php echo intval($user_opt['id']); ?>">
                            <?php echo htmlspecialchars($user_opt['username']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label class="form-label">Datum *</label>
                <input type="date" id="anwesenheitDatum" class="form-input" required>
            </div>

            <div class="form-group-row">
                <div class="form-group">
                    <label class="form-label">Startzeit</label>
                    <input type="time" id="anwesenheitStart" class="form-input">
                </div>
                <div class="form-group">
                    <label class="form-label">Endzeit</label>
                    <input type="time" id="anwesenheitEnd" class="form-input">
                </div>
            </div>

            <div class="form-group">
                <label class="form-label">Unterrichtsstoff</label>
                <textarea id="anwesenheitUnterrichtsstoff" class="form-textarea"></textarea>
            </div>

            <div class="form-group checkbox-group">
                <label class="checkbox-label">
                    <input type="checkbox" id="anwesenheitCheckbox" class="checkbox-input" checked>
                    <span>Anwesend</span>
                </label>
            </div>

            <div id="entschuldigungContainer" class="entschuldigung-container">
                <label class="form-label">Entschuldigung</label>
                <textarea id="anwesenheitEntschuldigung" class="form-textarea"></textarea>
            </div>

            <div class="button-group">
                <button type="submit" class="btn btn-primary">Speichern</button>
                <button type="reset" class="btn btn-primary" style="background: #999;">Zurücksetzen</button>
            </div>
        </form>
        
        <!-- Erfolgsmeldung -->
        <div id="anwesenheitSuccess" class="success-message"></div>
    </div>
</div>

<style>
    /* Anwesenheit Form Styles */
    .anwesenheit-container {
        background: #f8f9fa;
        padding: 20px;
        border-radius: 8px;
        margin-top: 20px;
    }

    .anwesenheit-form {
        display: flex;
        flex-direction: column;
        gap: 20px;
    }

    .form-group {
        display: flex;
        flex-direction: column;
        gap: 8px;
        width: 100%;
    }

    .form-group-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 16px;
    }

    .form-label {
        display: block;
        font-weight: 500;
        font-size: 14px;
        color: #3c4043;
    }

    .form-input,
    .form-textarea {
        width: 100%;
        padding: 12px;
        border: 1px solid #dadce0;
        border-radius: 6px;
        font-size: 14px;
        font-family: inherit;
        transition: all 0.2s;
        box-sizing: border-box;
    }

    .form-input:focus,
    .form-textarea:focus {
        outline: none;
        border-color: #1967d2;
        box-shadow: 0 0 0 3px rgba(25, 103, 210, 0.1);
    }

    .form-textarea {
        min-height: 80px;
        resize: vertical;
    }

    .checkbox-group {
        flex-direction: row;
        align-items: center;
        gap: 8px;
    }

    .checkbox-label {
        display: flex;
        align-items: center;
        gap: 8px;
        cursor: pointer;
        font-weight: 500;
        font-size: 14px;
        user-select: none;
    }

    .checkbox-input {
        width: 20px;
        height: 20px;
        cursor: pointer;
        accent-color: #1967d2;
    }

    .entschuldigung-container {
        display: none;
        padding: 16px;
        background: white;
        border-radius: 6px;
        border-left: 4px solid #ff9800;
    }

    .entschuldigung-container.visible {
        display: block;
    }

    .button-group {
        display: flex;
        gap: 12px;
        flex-wrap: wrap;
    }

    .btn {
        padding: 12px 24px;
        border: none;
        border-radius: 6px;
        font-size: 14px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.2s;
    }

    .btn-primary {
        background: #1967d2;
        color: white;
    }

    .btn-primary:hover {
        background: #1557b0;
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(25, 103, 210, 0.2);
    }

    .btn-primary:active {
        transform: translateY(0);
    }

    .success-message {
        display: none;
        padding: 16px;
        background: #e6ffe6;
        color: #155724;
        border-radius: 6px;
        border: 1px solid #c3e6cb;
        margin-top: 20px;
        font-weight: 500;
        text-align: center;
        animation: slideIn 0.3s ease;
    }

    .success-message.visible {
        display: block;
    }

    @keyframes slideIn {
        from {
            opacity: 0;
            transform: translateY(-10px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    /* Mobile Responsivität */
    @media (max-width: 768px) {
        .anwesenheit-container {
            padding: 16px;
        }

        .form-group-row {
            grid-template-columns: 1fr;
            gap: 16px;
        }

        .form-label {
            font-size: 13px;
        }

        .form-input,
        .form-textarea {
            padding: 12px;
            font-size: 16px;
        }

        .form-textarea {
            min-height: 100px;
        }

        .btn {
            padding: 14px 20px;
            font-size: 16px;
            width: 100%;
        }

        .button-group {
            flex-direction: column;
        }

        .checkbox-label {
            font-size: 15px;
        }

        .checkbox-input {
            width: 24px;
            height: 24px;
        }
    }

    @media (max-width: 480px) {
        .anwesenheit-container {
            padding: 12px;
            background: white;
            border-radius: 0;
        }

        .form-group {
            gap: 6px;
        }

        .form-label {
            font-size: 12px;
            font-weight: 600;
        }

        .form-input,
        .form-textarea {
            padding: 11px 10px;
            font-size: 16px;
            border-radius: 4px;
        }

        .btn {
            padding: 13px 16px;
            font-size: 15px;
        }

        .success-message {
            padding: 12px;
            font-size: 14px;
        }

        .entschuldigung-container {
            padding: 12px;
            border-left-width: 3px;
        }
    }
    .entschuldigt{
        margin-top: 10px;
    }
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('anwesenheitForm');
    const anwesenheitCheckbox = document.getElementById('anwesenheitCheckbox');
    const entschuldigungContainer = document.getElementById('entschuldigungContainer');
    const successMessage = document.getElementById('anwesenheitSuccess');
    
    // Heutiges Datum als Standard setzen
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('anwesenheitDatum').value = today;
    
    // WICHTIG: Checkbox ist anfangs CHECKED (anwesend), daher Entschuldigung-Feld verstecken
    entschuldigungContainer.classList.remove('visible');
    
    // Entschuldigungsfeld anzeigen/verstecken basierend auf Anwesenheit
    anwesenheitCheckbox.addEventListener('change', function() {
        if (this.checked) {
            // Anwesend = kein Entschuldigungsfeld nötig
            entschuldigungContainer.classList.remove('visible');
        } else {
            // Abwesend = Entschuldigungsfeld anzeigen
            entschuldigungContainer.classList.add('visible');
        }
    });
    
    // Formular abschicken
    form.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const userId = document.getElementById('anwesenheitBenutzer').value;
        const datum = document.getElementById('anwesenheitDatum').value;
        const uhrzeit_start = document.getElementById('anwesenheitStart').value;
        const uhrzeit_end = document.getElementById('anwesenheitEnd').value;
        const unterrichtsstoff = document.getElementById('anwesenheitUnterrichtsstoff').value;
        
        // WICHTIG: Checkbox-Status als 1 oder 0 senden
        const anwesend = anwesenheitCheckbox.checked ? 1 : 0;
        const entschuldigung = document.getElementById('anwesenheitEntschuldigung').value;

        if (!userId || !datum) {
            alert('Bitte Benutzer und Datum auswählen');
            return;
        }

        const formData = new FormData();
        formData.append('action', 'create_anwesenheit');
        formData.append('benutzer_id', userId);
        formData.append('datum', datum);
        formData.append('uhrzeit_start', uhrzeit_start || '');
        formData.append('uhrzeit_end', uhrzeit_end || '');
        formData.append('unterrichtsstoff', unterrichtsstoff);
        formData.append('anwesend', anwesend);  // 1 oder 0
        formData.append('entschuldigung', entschuldigung);

        try {
            const response = await fetch('Main.php', {
                method: 'POST',
                body: formData,
                credentials: 'same-origin'
            });

            if (!response.ok) {
                throw new Error('HTTP ' + response.status);
            }

            const data = await response.json();

            if (data.success) {
                successMessage.textContent = 'Anwesenheit erfolgreich gespeichert!';
                successMessage.classList.add('visible');
                form.reset();
                document.getElementById('anwesenheitDatum').value = today;
                entschuldigungContainer.classList.remove('visible');
                anwesenheitCheckbox.checked = true;
                
                setTimeout(() => {
                    successMessage.classList.remove('visible');
                }, 3000);
            } else {
                alert('Fehler: ' + (data.error || 'Unbekannter Fehler'));
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Fehler beim Speichern der Anwesenheit: ' + error.message);
        }
    });
});
</script>

<!-- Die Checkbox sendet anwesend = 1 (angehakt) oder 0 (nicht angehakt) an Main.php -->