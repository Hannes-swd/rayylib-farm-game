<?php
// Bearbeiten
try {
    $stmt_Lehrer = $pdo->prepare("SELECT COUNT(*) as anzahl_lehrer FROM users WHERE roles LIKE '%lehrer%'");
    $stmt_Lehrer->execute();
    $result_lehrer = $stmt_Lehrer->fetch();
    $anzahl_lehrer = $result_lehrer['anzahl_lehrer'];
    
    // Anzahl Schüler
    $stmt_schueler = $pdo->prepare("SELECT COUNT(*) as anzahl_schueler FROM users WHERE roles LIKE '%schueler%'");
    $stmt_schueler->execute();
    $result_schueler = $stmt_schueler->fetch();
    $anzahl_schueler = $result_schueler['anzahl_schueler'];
    
    // Anzahl Admins
    $stmt_admin = $pdo->prepare("SELECT COUNT(*) as anzahl_Admin FROM users WHERE roles LIKE '%admin%'");
    $stmt_admin->execute();
    $result_admin = $stmt_admin->fetch();
    $anzahl_admin = $result_admin['anzahl_Admin'];
    
    // Gesamtzahl aller Benutzer
    $stmt_gesamt = $pdo->prepare("SELECT COUNT(*) as anzahl_gesamt FROM users");
    $stmt_gesamt->execute();
    $result_gesamt = $stmt_gesamt->fetch();
    $anzahl_gesamt = $result_gesamt['anzahl_gesamt'];

    // Lade alle Kurse für das Modal (wichtig für JS-Variable allCourses)
    $stmt_all_courses = $pdo->prepare("SELECT id, name, farb_code FROM kurse ORDER BY name");
    $stmt_all_courses->execute();
    $all_courses = $stmt_all_courses->fetchAll();

    // Lade alle Visual Roles (für Modal und Badges)
    $stmt_visual = $pdo->prepare("SELECT id, name, emoji FROM visual_roles ORDER BY name");
    $stmt_visual->execute();
    $all_visual_roles = $stmt_visual->fetchAll();

} catch(PDOException $e) {
    $anzahl_Lehrer = $anzahl_schueler = $anzahl_Admin = $anzahl_gesamt = "Fehler";
    $all_courses = [];
}
?>

<div class="app-card">

        <div class="app-users-header">
            <a href="?page=NutzerHinzufügen" class="app-users-add-link">
                <p class="app-users-add-text">Nutzer Hinzufügen</p>
            </a>
            <div>
                <input type="text" id="userSearch" class="app-users-search" placeholder="Suchen...">
            </div>
        </div>

        <!-- RESTAURIERT: Header mit Spalten-Beschriftungen + eingebetteten Resizern -->
        <div class="app-users-row" id="usersHeader">
            <div class="app-col--checkbox" style="display:flex; align-items:center; justify-content:center;">
                <input type="checkbox" class="checkboxAdminBenutzer round-checkbox" id="selectAll">
            </div>
            <div class="app-col--name" style="display:flex; align-items:center;">
                <p>Name</p>
            </div>
            <p>Kurse</p>
            <p>Rollen</p>
            <p>Aktionen</p>

            <div class="app-resizers" aria-hidden="true"></div>
        </div>

        <!-- USERS LIST -->
        <!-- jeweils Rolle als kleines Label darüber anzeigen -->
        <details open>
            <summary>Admin (<?php echo $anzahl_admin; ?>)</summary>
            <?php
            try {
                $stmt = $pdo->prepare("SELECT * FROM users WHERE roles LIKE '%admin%' ORDER BY username");
                $stmt->execute();
                $admins = $stmt->fetchAll();
                
                foreach($admins as $admin): 
                    $rollen_array = explode(',', $admin['roles']);
                    $kurse_array = isset($admin['courses']) ? array_filter(array_map('trim', explode(',', $admin['courses']))) : [];


                    $courseBadges = [];
                    foreach ($kurse_array as $cn) {
                        $color = null;
                        foreach ($all_courses as $ac) { if ($ac['name'] === $cn) { $color = $ac['farb_code']; break; } }
                        $courseBadges[] = ['name'=>$cn,'color'=>$color];
                    }

                    $searchString = strtolower($admin['username'] . ' ' . implode(' ', $kurse_array) . ' ' . implode(' ', $rollen_array));
                ?>
                    <div class="app-users-row" data-name="<?php echo htmlspecialchars($searchString); ?>">
                        <div class="app-col--checkbox" style="display:flex; align-items:center; justify-content:center;">
                            <input type="checkbox" class="checkboxAdminBenutzer round-checkbox">
                        </div>

                        <div class="app-col--name">
                            <a href="?page=benutzerOffen&user_id=<?php echo intval($admin['id']); ?>" style="text-decoration:none; color:inherit; display:flex; align-items:center; width:100%; height:100%;">
                                <p><?php echo htmlspecialchars($admin['username']); ?></p>
                            </a>
                        </div>
                        
                        <div class="app-user-courses">
                                <?php if (empty($courseBadges)): ?>
                                    <span class="app-no-courses">-</span>
                                <?php else: foreach($courseBadges as $cb): ?>
                                    <span class="app-user-course-badge" style="<?php echo $cb['color'] ? 'border-color: '.htmlspecialchars($cb['color']).';' : ''; ?>">
                                        <?php echo htmlspecialchars($cb['name']); ?>
                                    </span>
                                <?php endforeach; endif; ?>
                        </div>

                        <p><?php echo htmlspecialchars(implode(', ', $rollen_array)); ?></p>

                        <div>
                            <button class="app-btn--edit-courses" data-userid="<?php echo intval($admin['id']); ?>" title="Kurse verwalten">
                                <img src="images/class.png" width="30" height="30">
                            </button>
                            <button class="app-btn--edit-roles" data-userid="<?php echo intval($admin['id']); ?>" title="Rollen verwalten">
                                <img src="images/rolle.png" width="30" height="30">
                            </button>
                        </div>
                    </div>
                <?php endforeach;
            } catch(PDOException $e) {
                echo "<div class='app-users-row'><p>Fehler beim Laden</p></div>";
            }
            ?>
        </details>

        <!-- Lehrer -->
        <details open>
            <summary>Lehrer (<?php echo $anzahl_lehrer; ?>)</summary>
            <?php
            try {
                $stmt = $pdo->prepare("SELECT * FROM users WHERE roles LIKE '%lehrer%' ORDER BY username");
                $stmt->execute();
                $lehrer = $stmt->fetchAll();
                
                foreach($lehrer as $lehr): 
                    $rollen_array = explode(',', $lehr['roles']);
                    $kurse_array = isset($lehr['courses']) ? array_filter(array_map('trim', explode(',', $lehr['courses']))) : [];
                    $courseBadges = [];
                    foreach ($kurse_array as $cn) {
                        $color = null;
                        foreach ($all_courses as $ac) { if ($ac['name'] === $cn) { $color = $ac['farb_code']; break; } }
                        $courseBadges[] = ['name'=>$cn,'color'=>$color];
                    }
                    $searchString = strtolower($lehr['username'] . ' ' . implode(' ', $kurse_array) . ' ' . implode(' ', $rollen_array));
                ?>
                    <div class="app-users-row" data-name="<?php echo htmlspecialchars($searchString); ?>">
                        <div class="app-col--checkbox" style="display:flex; align-items:center; justify-content:center;">
                            <input type="checkbox" class="checkboxAdminBenutzer round-checkbox">
                        </div>

                        <div class="app-col--name">
                            <a href="?page=benutzerOffen&user_id=<?php echo intval($lehr['id']); ?>" style="text-decoration:none; color:inherit; display:flex; align-items:center; width:100%; height:100%;">
                                <p><?php echo htmlspecialchars($lehr['username']); ?></p>
                            </a>
                        </div>

                        <div class="app-user-courses">
                                <?php if (empty($courseBadges)): ?>
                                    <span class="app-no-courses">-</span>
                                <?php else: foreach($courseBadges as $cb): ?>
                                    <span class="app-user-course-badge" style="<?php echo $cb['color'] ? 'border-color: '.htmlspecialchars($cb['color']).';' : ''; ?>">
                                        <?php echo htmlspecialchars($cb['name']); ?>
                                    </span>
                                <?php endforeach; endif; ?>
                        </div>
                        <p><?php echo htmlspecialchars(implode(', ', $rollen_array)); ?></p>
                        <div>
                            <button class="app-btn--edit-courses" data-userid="<?php echo intval($lehr['id']); ?>" title="Kurse verwalten">
                                <img src="images/class.png" width="30" height="30">
                            </button>
                            <button class="app-btn--edit-roles" data-userid="<?php echo intval($lehr['id']); ?>" title="Rollen verwalten">
                                <img src="images/rolle.png" width="30" height="30">
                            </button>
                        </div>
                    </div>
                <?php endforeach;
            } catch(PDOException $e) {
                echo "<div class='app-users-row'><p>Fehler beim Laden</p></div>";
            }
            ?>
        </details>


        <!-- schüler -->
        <details open>
            <summary>schüler (<?php echo $anzahl_schueler; ?>)</summary>
            <?php
            try {
                $stmt = $pdo->prepare("SELECT * FROM users WHERE roles LIKE '%schueler%' ORDER BY username");
                $stmt->execute();
                $schueler = $stmt->fetchAll();
                
                foreach($schueler as $schuel): 
                    $rollen_array = explode(',', $schuel['roles']);
                    $kurse_array = isset($schuel['courses']) ? array_filter(array_map('trim', explode(',', $schuel['courses']))) : [];
                    $courseBadges = [];
                    foreach ($kurse_array as $cn) {
                        $color = null;
                        foreach ($all_courses as $ac) { if ($ac['name'] === $cn) { $color = $ac['farb_code']; break; } }
                        $courseBadges[] = ['name'=>$cn,'color'=>$color];
                    }
                    $searchString = strtolower($schuel['username'] . ' ' . implode(' ', $kurse_array) . ' ' . implode(' ', $rollen_array));
                ?>
                    <div class="app-users-row" data-name="<?php echo htmlspecialchars($searchString); ?>">
                        <div class="app-col--checkbox" style="display:flex; align-items:center; justify-content:center;">
                            <input type="checkbox" class="checkboxAdminBenutzer round-checkbox">
                        </div>

                        <div class="app-col--name">
                            <a href="?page=benutzerOffen&user_id=<?php echo intval($schuel['id']); ?>" style="text-decoration:none; color:inherit; display:flex; align-items:center; width:100%; height:100%;">
                                <p><?php echo htmlspecialchars($schuel['username']); ?></p>
                            </a>
                        </div>

                        <div class="app-user-courses">
                                <?php if (empty($courseBadges)): ?>
                                    <span class="app-no-courses">-</span>
                                <?php else: foreach($courseBadges as $cb): ?>
                                    <span class="app-user-course-badge" style="<?php echo $cb['color'] ? 'border-color: '.htmlspecialchars($cb['color']).';' : ''; ?>">
                                        <?php echo htmlspecialchars($cb['name']); ?>
                                    </span>
                                <?php endforeach; endif; ?>
                        </div>
                        <p><?php echo htmlspecialchars(implode(', ', $rollen_array)); ?></p>
                        <div>
                            <button class="app-btn--edit-courses" data-userid="<?php echo intval($schuel['id']); ?>" title="Kurse verwalten">
                                <img src="images/class.png" width="30" height="30">
                            </button>
                            <button class="app-btn--edit-roles" data-userid="<?php echo intval($schuel['id']); ?>" title="Rollen verwalten">
                                <img src="images/rolle.png" width="30" height="30">
                            </button>
                        </div>
                    </div>
                <?php endforeach;
            } catch(PDOException $e) {
                echo "<div class='app-users-row'><p>Fehler beim Laden</p></div>";
            }
            ?>
        </details>
    

</div>


<div id="courseModal" class="cal-modal-overlay" style="display:none;" onclick="if(event.target===this) closeModal('courseModal')">
    <div class="cal-modal" role="dialog" aria-modal="true" aria-labelledby="courseModalTitle">
        <div class="cal-modal-header">
            <h3 class="cal-modal-title" id="courseModalTitle">Kurse verwalten</h3>
            <button class="cal-modal-close" aria-label="Schließen" id="courseModalCloseBtn" onclick="closeModal('courseModal')">×</button>
        </div>
        <div class="cal-modal-body">
            <div id="modalUserInfo" style="margin-bottom:8px;font-weight:600;"></div>
            <div id="modalCourseList" class="app-course-list" style="padding:8px;"></div>
            <div style="margin-top:12px; display:flex; gap:8px; align-items:center;">
                <select id="modalAddSelect" style="flex:1; padding:8px;">
                    <option value="">-- Kurs hinzufügen --</option>
                    <?php foreach($all_courses as $c): ?>
                        <option value="<?php echo intval($c['id']); ?>"><?php echo htmlspecialchars($c['name']); ?></option>
                    <?php endforeach; ?>
                </select>
                <button id="modalAddBtn" class="cal-btn cal-btn-primary">Hinzufügen</button>
                <button id="courseModalClose" class="cal-btn cal-btn-secondary">Schließen</button>
            </div>
        </div>
    </div>
</div>

<div id="rolesModal" class="cal-modal-overlay" style="display:none;" onclick="if(event.target===this) closeModal('rolesModal')">
    <div class="cal-modal" role="dialog" aria-modal="true" aria-labelledby="rolesModalTitle">
        <div class="cal-modal-header">
            <h3 class="cal-modal-title" id="rolesModalTitle">Rollen verwalten</h3>
            <button class="cal-modal-close" aria-label="Schließen" id="rolesModalCloseBtn" onclick="closeModal('rolesModal')">×</button>
        </div>
        <div class="cal-modal-body">
            <div id="rolesModalUserInfo" style="margin-bottom:8px;font-weight:600;"></div>
            <div id="rolesModalList" style="padding:8px;"></div>
            <div style="margin-top:12px; display:flex; gap:8px; align-items:center; flex-wrap:wrap;">
                <select id="rolesAddSelect" style="flex:1; padding:8px;">
                    <option value="">-- Rolle hinzufügen --</option>
                    <?php foreach (['admin','lehrer','schueler'] as $builtin): ?>
                        <option value="<?php echo htmlspecialchars($builtin); ?>"><?php echo htmlspecialchars($builtin); ?></option>
                    <?php endforeach; ?>
                    <?php foreach($all_visual_roles as $vr): ?>
                        <option value="<?php echo htmlspecialchars($vr['name']); ?>"><?php echo htmlspecialchars($vr['emoji'] . ' ' . $vr['name']); ?></option>
                    <?php endforeach; ?>
                </select>
                <button id="rolesAddBtn" class="cal-btn cal-btn-primary">Hinzufügen</button>
                <button id="createVisualRoleBtn" class="cal-btn cal-btn-primary">Neue visuelle Rolle</button>
                <button id="rolesModalClose" class="cal-btn cal-btn-secondary">Schließen</button>
            </div>

            <div id="createVisualRoleForm" style="display:none; margin-top:10px;">
                <input id="newRoleName" placeholder="Name (z. B. Mentor)" style="padding:8px; width:50%; margin-right:8px;">
                <input id="newRoleEmoji" placeholder="Emoji (z. B. ⭐)" style="padding:8px; width:20%;">
                <button id="createVisualRoleConfirm" class="cal-btn cal-btn-primary">Erstellen</button>
            </div>
        </div>
    </div>
</div>

<script>

document.getElementById('selectAll').addEventListener('change', function(e) {
        const visibleCheckboxes = document.querySelectorAll('details[open] .checkboxAdminBenutzer:not(#selectAll)');
        visibleCheckboxes.forEach(checkbox => {
            checkbox.checked = e.target.checked;
        });
    });


    document.querySelectorAll('.checkboxAdminBenutzer:not(#selectAll)').forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            updateSelectAllState();
        });
    });


    document.querySelectorAll('details').forEach(detail => {
        detail.addEventListener('toggle', function() {
            updateSelectAllState();
        });
    });


    function updateSelectAllState() {
        const visibleCheckboxes = document.querySelectorAll('details[open] .checkboxAdminBenutzer:not(#selectAll)');
        const selectAll = document.getElementById('selectAll');
        
        if (visibleCheckboxes.length === 0) {

            selectAll.checked = false;
            selectAll.indeterminate = false;
            return;
        }
        
        const allChecked = Array.from(visibleCheckboxes).every(cb => cb.checked);
        const anyChecked = Array.from(visibleCheckboxes).some(cb => cb.checked);
        
        selectAll.checked = allChecked;
        selectAll.indeterminate = anyChecked && !allChecked;
    }


    const userSearch = document.getElementById('userSearch');
    function filterUsers() {
        const term = (userSearch.value || '').trim().toLowerCase();
        document.querySelectorAll('details').forEach(detail => {
            let anyVisible = false;
            detail.querySelectorAll('.app-users-row').forEach(row => {
                const hay = (row.dataset.name || '').toLowerCase();
                if (term === '' || hay.includes(term)) {
                    row.style.display = '';
                    anyVisible = true;
                } else {
                    row.style.display = 'none';
                }
            });

            detail.open = anyVisible;
        });
        updateSelectAllState();
    }

    userSearch.addEventListener('input', filterUsers);



const allCourses = <?php echo json_encode($all_courses, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP); ?>;
const allVisualRoles = <?php echo json_encode($all_visual_roles, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP); ?>;
let modalActiveUserId = null;
let modalActiveRow = null;
let rolesModalActiveUserId = null;
let rolesModalActiveRow = null;

function openCourseModalForUser(userId, row) {
    modalActiveUserId = userId;
    modalActiveRow = row;
    document.getElementById('modalUserInfo').textContent = 'Nutzer ID: ' + userId;
    loadUserCoursesIntoModal(userId);
    document.getElementById('modalAddSelect').value = '';
    document.getElementById('courseModal').style.display = 'flex';
}

function closeCourseModal() {
    document.getElementById('courseModal').style.display = 'none';
    modalActiveUserId = null;
    modalActiveRow = null;
}

document.getElementById('courseModalClose').addEventListener('click', closeCourseModal);
document.getElementById('courseModal').addEventListener('click', function(e){
    if (e.target === this) closeCourseModal();
});

function openRolesModalForUser(userId, row) {
    rolesModalActiveUserId = userId;
    rolesModalActiveRow = row;
    document.getElementById('rolesModalUserInfo').textContent = 'Nutzer ID: ' + userId;
    loadUserRolesIntoModal(userId);
    document.getElementById('rolesAddSelect').value = '';
    document.getElementById('rolesModal').style.display = 'flex';
    document.getElementById('createVisualRoleForm').style.display = 'none';
}

function closeRolesModal() {
    document.getElementById('rolesModal').style.display = 'none';
    rolesModalActiveUserId = null;
    rolesModalActiveRow = null;
}

document.getElementById('rolesModalClose').addEventListener('click', closeRolesModal);
document.getElementById('rolesModal').addEventListener('click', function(e){
    if (e.target === this) closeRolesModal();
});


document.querySelectorAll('.app-btn--edit-courses').forEach(btn => {
    btn.addEventListener('click', function(){
        const userId = parseInt(this.dataset.userid,10);
        const row = this.closest('.app-users-row');
        openCourseModalForUser(userId, row);
    });
});

document.querySelectorAll('.app-btn--edit-roles').forEach(btn => {
    btn.addEventListener('click', function(){
        const userId = parseInt(this.dataset.userid,10);
        const row = this.closest('.app-users-row');
        openRolesModalForUser(userId, row);
    });
});

async function loadUserCoursesIntoModal(userId) {
    const fd = new FormData();
    fd.append('action','get_user_courses');
    fd.append('user_id', userId);
    const res = await fetch('Main.php', { method:'POST', body: fd, credentials:'same-origin' });
    if (!res.ok) {
        const t = await res.text();
        alert('Serverfehler: ' + t);
        return;
    }
    const data = await res.json();
    if (!data.success) {
        alert('Fehler: ' + (data.error || data.message));
        return;
    }
    const list = document.getElementById('modalCourseList');
    list.innerHTML = '';
    if (!data.courses || data.courses.length === 0) {
        list.innerHTML = '<div style="color:#666;">Keine Kurse zugewiesen.</div>';
    } else {
        data.courses.forEach(c => {
            const item = document.createElement('div');
            item.style.display = 'flex';
            item.style.alignItems = 'center';
            item.style.justifyContent = 'space-between';
            item.style.padding = '6px 4px';
            const left = document.createElement('div');
            const badge = document.createElement('span');
            badge.className = 'app-user-course-badge';
            if (c.farb_code) badge.style.borderColor = c.farb_code;
            badge.textContent = c.name;
            left.appendChild(badge);
            item.appendChild(left);

            const right = document.createElement('div');
            const removeBtn = document.createElement('button');
            removeBtn.textContent = 'Entfernen';
            removeBtn.style.padding = '6px 8px';
            removeBtn.style.borderRadius = '6px';
            removeBtn.style.border = '1px solid #ddd';
            removeBtn.style.background = '#fff';
            removeBtn.style.cursor = 'pointer';
            removeBtn.addEventListener('click', () => removeCourseFromUser(modalActiveUserId, c.id));
            right.appendChild(removeBtn);
            item.appendChild(right);
            list.appendChild(item);
        });
    }
}

async function loadUserRolesIntoModal(userId) {
    const fd = new FormData();
    fd.append('action','get_user_roles');
    fd.append('user_id', userId);
    const res = await fetch('Main.php', { method:'POST', body: fd, credentials:'same-origin' });
    if (!res.ok) { alert('Serverfehler'); return; }
    const data = await res.json();
    const list = document.getElementById('rolesModalList');
    list.innerHTML = '';
    if (!data.roles || data.roles.length === 0) {
        list.innerHTML = '<div style="color:#666;">Keine Rollen zugewiesen.</div>';
    } else {
        data.roles.forEach(r => {
            const item = document.createElement('div');
            item.style.display = 'flex';
            item.style.alignItems = 'center';
            item.style.justifyContent = 'space-between';
            item.style.padding = '6px 4px';
            const left = document.createElement('div');
            left.textContent = (r.emoji ? r.emoji + ' ' : '') + r.name;
            item.appendChild(left);

            const right = document.createElement('div');
            const removeBtn = document.createElement('button');
            removeBtn.textContent = 'Entfernen';
            removeBtn.style.padding = '6px 8px';
            removeBtn.style.borderRadius = '6px';
            removeBtn.style.border = '1px solid #ddd';
            removeBtn.style.background = '#fff';
            removeBtn.style.cursor = 'pointer';
            removeBtn.addEventListener('click', () => removeRoleFromUser(rolesModalActiveUserId, r.name));
            right.appendChild(removeBtn);
            item.appendChild(right);
            list.appendChild(item);
        });
    }
}


document.getElementById('modalAddBtn').addEventListener('click', async function(){
    const sel = document.getElementById('modalAddSelect');
    const val = parseInt(sel.value,10);
    if (!modalActiveUserId || !val) return alert('Bitte Kurs auswählen');
    const fd = new FormData();
    fd.append('action','add_course_user');
    fd.append('user_id', modalActiveUserId);
    fd.append('course_id', val);
    const res = await fetch('Main.php', { method:'POST', body: fd, credentials:'same-origin' });
    if (!res.ok) {
        const t = await res.text();
        alert('Serverfehler: ' + t);
        return;
    }
    const data = await res.json();
    if (!data.success) {
        alert('Fehler: ' + (data.error || data.message));
        return;
    }

    await loadUserCoursesIntoModal(modalActiveUserId);
    refreshRowCourseBadges(modalActiveRow, data.courses);
});


async function removeCourseFromUser(userId, courseId) {
    if (!confirm('Kurs entfernen?')) return;
    const fd = new FormData();
    fd.append('action','remove_course_user');
    fd.append('user_id', userId);
    fd.append('course_id', courseId);
    const res = await fetch('Main.php', { method:'POST', body: fd, credentials:'same-origin' });
    if (!res.ok) {
        const t = await res.text();
        alert('Serverfehler: ' + t);
        return;
    }
    const data = await res.json();
    if (!data.success) {
        alert('Fehler: ' + (data.error || data.message));
        return;
    }
    await loadUserCoursesIntoModal(userId);
    refreshRowCourseBadges(modalActiveRow, data.courses);
}


function refreshRowCourseBadges(row, courses) {
    if (!row) return;
    const container = row.querySelector('.app-user-courses');
    if (!container) return;
    container.innerHTML = '';
    if (!courses || courses.length === 0) {
        container.innerHTML = '<span class="app-no-courses">-</span>';
        return;
    }
    courses.forEach(c => {
        const span = document.createElement('span');
        span.className = 'app-user-course-badge';
        if (c.farb_code) span.style.borderColor = c.farb_code;
        span.textContent = c.name;
        container.appendChild(span);
    });
}

document.getElementById('createVisualRoleBtn').addEventListener('click', function(){
    const form = document.getElementById('createVisualRoleForm');
    form.style.display = form.style.display === 'none' ? 'flex' : 'none';
});

document.getElementById('createVisualRoleConfirm').addEventListener('click', async function(){
    const name = document.getElementById('newRoleName').value.trim();
    const emoji = document.getElementById('newRoleEmoji').value.trim();
    if (!name) return alert('Name erforderlich');
    const fd = new FormData();
    fd.append('action','create_visual_role');
    fd.append('name', name);
    fd.append('emoji', emoji);
    const res = await fetch('Main.php', { method:'POST', body: fd, credentials:'same-origin' });
    if (!res.ok) return alert('Serverfehler');
    const data = await res.json();
    if (!data.success) return alert('Fehler: ' + (data.error || data.message));

    const sel = document.getElementById('rolesAddSelect');

    sel.innerHTML = '<option value="">-- Rolle hinzufügen --</option>';
    ['admin','lehrer','schueler'].forEach(b => {
        const o = document.createElement('option'); o.value = b; o.textContent = b; sel.appendChild(o);
    });
    data.visual_roles.forEach(v => {
        const o = document.createElement('option'); o.value = v.name; o.textContent = (v.emoji ? v.emoji + ' ' : '') + v.name; sel.appendChild(o);
    });
    document.getElementById('newRoleName').value = '';
    document.getElementById('newRoleEmoji').value = '';
    alert('Visuelle Rolle erstellt');
});

document.getElementById('rolesAddBtn').addEventListener('click', async function(){
    const sel = document.getElementById('rolesAddSelect');
    const val = (sel.value || '').trim();
    if (!rolesModalActiveUserId || !val) return alert('Bitte Rolle auswählen');
    const fd = new FormData();
    fd.append('action','add_role_user');
    fd.append('user_id', rolesModalActiveUserId);
    fd.append('role_name', val);
    const res = await fetch('Main.php', { method:'POST', body: fd, credentials:'same-origin' });
    if (!res.ok) { alert('Serverfehler'); return; }
    const data = await res.json();
    if (!data.success) return alert('Fehler: ' + (data.error || data.message));
    await loadUserRolesIntoModal(rolesModalActiveUserId);
    refreshRowRoleBadges(rolesModalActiveRow, data.roles);
});

async function removeRoleFromUser(userId, roleName) {
    if (!confirm('Rolle entfernen?')) return;
    const fd = new FormData();
    fd.append('action','remove_role_user');
    fd.append('user_id', userId);
    fd.append('role_name', roleName);
    const res = await fetch('Main.php', { method:'POST', body: fd, credentials:'same-origin' });
    if (!res.ok) { alert('Serverfehler'); return; }
    const data = await res.json();
    if (!data.success) return alert('Fehler: ' + (data.error || data.message));
    await loadUserRolesIntoModal(userId);
    refreshRowRoleBadges(rolesModalActiveRow, data.roles);
}

function refreshRowRoleBadges(row, roles) {
    if (!row) return;
    const container = row.querySelector('p');
    if (!container) return;
    const txt = (roles && roles.length) ? roles.map(r => (r.emoji ? r.emoji + ' ' : '') + r.name).join(', ') : '-';
    container.textContent = txt;
}

// --- ERSETZE/AKTUALISIERE: Resizable column logic (Users list) ---
(function(){
    const container = document.querySelector('.app-card');
    const header = document.getElementById('usersHeader');
    if (!container || !header) return;

    const getCols = () => Array.from(header.children).filter(c => !c.classList.contains('app-resizers'));
    // Resizers-Container liegt wieder INSIDE header
    const resizersContainer = header.querySelector('.app-resizers');

    // minimale Breiten pro Spalte (px)
    const minWidths = [40, 120, 100, 100, 80];

    function createResizers() {
        if (!resizersContainer) return;
        resizersContainer.innerHTML = '';
        const cols = getCols();
        for (let i = 0; i < cols.length - 1; i++) {
            const r = document.createElement('div');
            r.className = 'app-col-resizer';
            r.dataset.index = i;
            resizersContainer.appendChild(r);
            r.addEventListener('mousedown', startDrag);
            r.addEventListener('touchstart', startDrag, {passive:false});
        }
    }

    // set initial widths -> in Prozent (Summe = 100%)
    function setInitialCols() {
        const cols = getCols();
        const headerW = Math.max(200, header.clientWidth || header.getBoundingClientRect().width);
        let widths = cols.map((c, idx) => Math.max(minWidths[idx] || 40, Math.round(c.getBoundingClientRect().width)));
        let sum = widths.reduce((a,b)=>a+b,0) || 1;
        const headerSum = headerW;
        const scale = headerSum / sum;
        widths = widths.map(w => Math.max(minWidths[widths.indexOf(w)] || 40, Math.round(w * scale)));
        const perc = widths.map(w => (w / headerSum * 100));
        container.style.setProperty('--user-cols', perc.map(p => p.toFixed(6) + '%').join(' '));
        updateResizerPositions();
    }

    function updateResizerPositions() {
        const headerW = Math.max(1, header.clientWidth || header.getBoundingClientRect().width);
        const colStr = getComputedStyle(container).getPropertyValue('--user-cols') || '';
        const parts = colStr.trim().split(/\s+/).map(s => parseFloat(s) || 0);
        let left = 0;
        const resizers = Array.from(resizersContainer.children);
        for (let i = 0; i < parts.length - 1; i++) {
            left += headerW * (parts[i] / 100);
            const r = resizers[i];
            if (r) r.style.left = (left - (r.offsetWidth/2)) + 'px';
        }
    }

    let dragging = null;
    function startDrag(e) {
        e.preventDefault();
        const touch = e.touches ? e.touches[0] : null;
        const startX = (touch ? touch.clientX : e.clientX);
        const idx = parseInt(this.dataset.index, 10);
        const cols = getCols();
        const headerW = Math.max(200, header.clientWidth || header.getBoundingClientRect().width);

        const colStr = getComputedStyle(container).getPropertyValue('--user-cols') || '';
        const parts = colStr.trim().split(/\s+/).map(s => parseFloat(s) || 0);
        let currentWidths = [];
        if (parts.length === cols.length) {
            currentWidths = parts.map(p => Math.round(headerW * (p / 100)));
        } else {
            currentWidths = cols.map((c,i) => Math.max(minWidths[i] || 40, Math.round(c.getBoundingClientRect().width)));
        }

        const pairSum = currentWidths[idx] + currentWidths[idx+1];
        const minLeft = minWidths[idx] || 40;
        const minRight = minWidths[idx+1] || 40;
        dragging = { idx, startX, currentWidths, pairSum, minLeft, minRight, headerW };

        function onMove(ev) {
            const t = ev.touches ? ev.touches[0] : ev;
            const dx = t.clientX - dragging.startX;
            const leftStart = dragging.currentWidths[dragging.idx];
            let newLeft = Math.round(leftStart + dx);
            newLeft = Math.max(dragging.minLeft, Math.min(newLeft, dragging.pairSum - dragging.minRight));
            const newRight = Math.max(dragging.minRight, dragging.pairSum - newLeft);

            const w = dragging.currentWidths.slice();
            w[dragging.idx] = newLeft;
            w[dragging.idx+1] = newRight;

            const headerWNow = Math.max(1, header.clientWidth || header.getBoundingClientRect().width);
            const perc = w.map(x => x / headerWNow * 100);

            const normalized = perc.map((p,i) => {
                return i === perc.length - 1 ? (100 - perc.slice(0, -1).reduce((a,b)=>a+b,0)) : p;
            });

            container.style.setProperty('--user-cols', normalized.map(p => p.toFixed(6) + '%').join(' '));
            updateResizerPositions();
        }

        function onUp() {
            document.removeEventListener('mousemove', onMove);
            document.removeEventListener('mouseup', onUp);
            document.removeEventListener('touchmove', onMove);
            document.removeEventListener('touchend', onUp);
            dragging = null;
        }

        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseup', onUp);
        document.addEventListener('touchmove', onMove, {passive:false});
        document.addEventListener('touchend', onUp);
    }

    window.addEventListener('resize', function(){
        setTimeout(function(){ setInitialCols(); }, 50);
    });

    createResizers();
    setTimeout(setInitialCols, 60);

})();
</script>