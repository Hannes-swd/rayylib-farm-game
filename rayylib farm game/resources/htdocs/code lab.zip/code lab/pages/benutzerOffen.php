<?php
try {
    $required = [
        'vorname' => "VARCHAR(100) DEFAULT NULL",
        'nachname' => "VARCHAR(100) DEFAULT NULL",
        'alter' => "INT DEFAULT NULL",
        'wohnort' => "VARCHAR(150) DEFAULT NULL",
        'geburtstag' => "DATE DEFAULT NULL",
        'email' => "VARCHAR(255) DEFAULT NULL"
    ];

    // Prüfe, welche der benötigten Spalten bereits existieren
    $cols = array_keys($required);
    $placeholders = implode(',', array_fill(0, count($cols), '?'));
    $stmt = $pdo->prepare(
        "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS 
         WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME IN ($placeholders)"
    );
    $stmt->execute($cols);
    $existing = $stmt->fetchAll(PDO::FETCH_COLUMN);
    $missing = array_values(array_diff($cols, $existing));

    if (!empty($missing)) {
        $alterParts = [];
        foreach ($missing as $col) {
            $alterParts[] = "ADD COLUMN `{$col}` " . $required[$col];
        }
        $sql = "ALTER TABLE `users` " . implode(', ', $alterParts);
        try {
            $pdo->exec($sql);
            error_log("users table: added columns -> " . implode(', ', $missing));
        } catch (PDOException $e) {
            // Protokolliere Fehler, brich die Seite nicht ab
            error_log("Fehler beim Hinzufügen von Profilspalten: " . $e->getMessage());
        }
    }
} catch (PDOException $e) {
    error_log("Fehler beim Prüfen der Profilspalten: " . $e->getMessage());
}
// ---- ENDE NEU ----

$user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;
$loaded_user = null;
$user_courses = [];
$teaching_days = [];
$user_notes = [];

// Bearbeitungsmodus für einzelne Felder
$editing_field = null;
$save_success = false;
$save_error = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_field'])) {
    try {
        $field = $_POST['field_name'];
        $value = trim($_POST['field_value'] ?? '');
        
        // Leere Werte in NULL umwandeln
        if ($value === '') {
            $value = null;
        }
        
        // Validierung für bestimmte Felder
        if ($field === 'alter' && $value !== null) {
            $value = intval($value);
        }
        
        if ($field === 'geburtstag' && $value !== null) {
            // Datum validieren
            $date = DateTime::createFromFormat('Y-m-d', $value);
            if (!$date) {
                throw new Exception("Ungültiges Datumsformat");
            }
        }

        $stmt = $pdo->prepare("UPDATE users SET `{$field}` = ? WHERE id = ?");
        $stmt->execute([$value, $user_id]);
        
        $save_success = true;
        $editing_field = null;
        
        // Benutzerdaten neu laden
        $stmt = $pdo->prepare("SELECT id, username, roles, courses, vorname, nachname, `alter`, wohnort, geburtstag, email FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $loaded_user = $stmt->fetch(PDO::FETCH_ASSOC);
        
    } catch (Exception $e) {
        error_log("Error updating user field: " . $e->getMessage());
        $save_error = true;
    }
}

// Bearbeitungsmodus starten
if (isset($_POST['edit_field'])) {
    $editing_field = $_POST['field_name'];
}

if ($user_id > 0) {
    try {
        // ALTER ist ein reserviertes Schlüsselwort, deshalb in Backticks setzen
        $stmt = $pdo->prepare("SELECT id, username, roles, courses, vorname, nachname, `alter`, wohnort, geburtstag, email FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $loaded_user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($loaded_user) {
            // Kurse des Benutzers laden
            $courses_str = $loaded_user['courses'] ?? '';
            $course_names = array_filter(array_map('trim', explode(',', $courses_str)));
            
            if (!empty($course_names)) {
                $placeholders = str_repeat('?,', count($course_names) - 1) . '?';
                $stmt = $pdo->prepare("SELECT id, name, farb_code FROM kurse WHERE name IN ($placeholders)");
                $stmt->execute($course_names);
                $user_courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                // Termine für diese Kurse laden
                $course_ids = array_column($user_courses, 'id');
                if (!empty($course_ids)) {
                    $placeholders = str_repeat('?,', count($course_ids) - 1) . '?';
                    $stmt = $pdo->prepare("
                        SELECT DISTINCT DATE(datum) as termin_datum, COUNT(*) as anzahl, 
                               SUM(CASE WHEN ist_wiederkehrend = 1 THEN 1 ELSE 0 END) as wiederkehrend_count
                        FROM termine 
                        WHERE kurs_id IN ($placeholders)
                        GROUP BY DATE(datum)
                        ORDER BY termin_datum ASC
                    ");
                    $stmt->execute($course_ids);
                    $teaching_days = $stmt->fetchAll(PDO::FETCH_ASSOC);
                }
            }

            // Noten des Benutzers laden
            $stmt = $pdo->prepare("
                SELECT n.id, n.titel, n.note, n.beschreibung, n.klasse, n.datum_erstellt,
                       k.name as kurs_name, k.farb_code,
                       u.username as erstellt_von_name
                FROM noten n
                LEFT JOIN kurse k ON n.kurs_id = k.id
                LEFT JOIN users u ON n.erstellt_von = u.id
                WHERE n.benutzer_id = ?
                ORDER BY n.datum_erstellt DESC
            ");
            $stmt->execute([$user_id]);
            $user_notes = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // --- NEU: Hausaufgaben für die Kurse des Benutzers laden ---
            $user_homeworks = [];
            try {
                if (!empty($course_ids)) {
                    $placeholders = str_repeat('?,', count($course_ids) - 1) . '?';
                    // Entferne riskante ORDER BY-Spalten (könnten in DB fehlen) – sortiere später in PHP
                    $sql = "SELECT h.*, k.name AS kurs_name, k.farb_code 
                            FROM hausaufgaben h
                            LEFT JOIN kurse k ON h.kurs_id = k.id
                            WHERE h.kurs_id IN ($placeholders)
                            LIMIT 200";
                    $stmtH = $pdo->prepare($sql);
                    $stmtH->execute($course_ids);
                    $user_homeworks = $stmtH->fetchAll(PDO::FETCH_ASSOC);

                    // Sortiere die Hausaufgaben in PHP nach dem frühesten relevanten Datum (fallback: id desc)
                    $dateKeys = ['frist','due_date','deadline','ends_at','created_at','erstellt_am'];
                    usort($user_homeworks, function($a, $b) use ($dateKeys) {
                        $getDate = function($item) use ($dateKeys) {
                            foreach ($dateKeys as $k) {
                                if (!empty($item[$k])) {
                                    $ts = strtotime($item[$k]);
                                    if ($ts !== false && $ts !== -1) return $ts;
                                }
                            }
                            return PHP_INT_MAX;
                        };
                        $ta = $getDate($a);
                        $tb = $getDate($b);
                        if ($ta === $tb) {
                            return intval($b['id'] ?? 0) <=> intval($a['id'] ?? 0); // id desc
                        }
                        return $ta <=> $tb;
                    });
                }
            } catch (PDOException $e) {
                // Tabelle/Spalte könnte fehlen oder andere DB-Fehler; nur protokollieren und leere Liste verwenden
                error_log("Error loading hausaufgaben for user $user_id: " . $e->getMessage());
                $user_homeworks = [];
            }
        }
    } catch (PDOException $e) {
        error_log("Error loading user details: " . $e->getMessage());
        echo "<div class='app-card'><h2>Fehler beim Laden der Benutzerdaten</h2><p>" . htmlspecialchars($e->getMessage()) . "</p></div>";
    }
}

// Nach dem Laden von $loaded_user ergänzen wir Anwesenheitsdaten für den angezeigten Benutzer
$user_attendance = [];
$user_att_counts = ['present'=>0,'missed'=>0,'made_up'=>0];
if ($loaded_user && intval($loaded_user['id']) > 0) {
    try {
        $stmt = $pdo->prepare("SELECT id, datum, anwesend, nachgeholt, unterrichtsstoff FROM anwesenheit WHERE benutzer_id = ? ORDER BY datum DESC LIMIT 12");
        $stmt->execute([intval($loaded_user['id'])]);
        $user_attendance = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $stmtC = $pdo->prepare("SELECT 
            SUM(CASE WHEN anwesend = 1 THEN 1 ELSE 0 END) AS present,
            SUM(CASE WHEN anwesend = 0 AND nachgeholt = 0 THEN 1 ELSE 0 END) AS missed,
            SUM(CASE WHEN nachgeholt = 1 THEN 1 ELSE 0 END) AS made_up
            FROM anwesenheit WHERE benutzer_id = ?");
        $stmtC->execute([intval($loaded_user['id'])]);
        $user_att_counts = $stmtC->fetch(PDO::FETCH_ASSOC) ?: $user_att_counts;
    } catch (PDOException $e) {
        error_log("benutzerOffen attendance: " . $e->getMessage());
    }
}

// --- NEU: Eintragungen für den Benutzer laden ---
$user_eintragungen = [];
if ($loaded_user && intval($loaded_user['id']) > 0) {
    try {
        $stmt = $pdo->prepare("
            SELECT e.id, e.kurs_id, e.text, e.datum, e.erstellt_von, 
                   k.name AS kurs_name, k.farb_code,
                   u.username AS erstellt_von_name
            FROM eintragungen e
            LEFT JOIN kurse k ON e.kurs_id = k.id
            LEFT JOIN users u ON e.erstellt_von = u.id
            WHERE e.benutzer_id = ?
            ORDER BY e.datum DESC
            LIMIT 50
        ");
        $stmt->execute([intval($loaded_user['id'])]);
        $user_eintragungen = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("benutzerOffen eintragungen: " . $e->getMessage());
        $user_eintragungen = [];
    }
}


// Berechtigungsprüfung: Nur Admin/Lehrer dürfen diese Seite sehen
if (!hasRole('admin') && !hasRole('lehrer')) {
    echo "<div class='app-card'><h2>Zugriff verweigert</h2><p>Nur Admins und Lehrer können Benutzerdetails ansehen.</p></div>";
    return;
}

if (!$loaded_user) {
    echo "<div class='app-card'><h2>Benutzer nicht gefunden</h2><p>Der Benutzer mit der ID $user_id existiert nicht oder konnte nicht geladen werden.</p></div>";
    return;
}

// Hilfsfunktion: Note in Text umwandeln
function gradeToText($grade) {
    $grades = [
        1 => 'Sehr gut',
        2 => 'Gut',
        3 => 'Befriedigend',
        4 => 'Ausreichend',
        5 => 'Mangelhaft',
        6 => 'Ungenügend'
    ];
    return $grades[$grade] ?? 'Unbekannt';
}

function getGradeColor($grade) {
    $colors = [
        1 => '#4caf50', // Grün
        2 => '#8bc34a', // Hellgrün
        3 => '#ff9800', // Orange
        4 => '#ff5722', // Orange-Rot
        5 => '#f44336', // Rot
        6 => '#c62828'  // Dunkelrot
    ];
    return $colors[$grade] ?? '#999';
}

// Funktion zum Anzeigen des Feldwerts
function displayFieldValue($value, $fieldType = 'text') {
    if ($value === null || $value === '') {
        return '<span class="empty-value">Nicht ausgefüllt</span>';
    }
    
    if ($fieldType === 'date') {
        $date = new DateTime($value);
        return $date->format('d.m.Y');
    }
    
    return htmlspecialchars($value);
}
?>

<?php if ($save_success): ?>
    <div class="success-message">
        <span>✅ Profilinformation wurde erfolgreich gespeichert!</span>
    </div>
<?php elseif ($save_error): ?>
    <div class="error-message">
        <span>❌ Fehler beim Speichern der Profilinformation!</span>
    </div>
<?php endif; ?>

<div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 24px; margin: 20px;">
    <!-- Linke Spalte: Benutzerdaten -->
    <div>
        <!-- Benutzer Info Card -->
        <div class="benutzer-info-card">
            <div class="benutzer-header">
                <div class="benutzer-avatar">
                    <?php echo htmlspecialchars($loaded_user['username'][0]); ?>
                </div>
                <div class="benutzer-details">
                    <h2 class="benutzer-name"><?php echo htmlspecialchars($loaded_user['username']); ?></h2>
                    <p class="benutzer-roles"><?php echo htmlspecialchars($loaded_user['roles'] ?: 'Benutzer'); ?></p>
                </div>
            </div>

            <!-- Profilinformationen Dropdown -->
            <div class="benutzer-section">
                <details class="profile-details" <?php echo $editing_field ? 'open' : ''; ?>>
                    <summary class="profile-summary">
                        <span>Profilinformationen</span>
                        <svg class="dropdown-arrow" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                            <path d="M6 9l6 6 6-6"/>
                        </svg>
                    </summary>
                    <div class="profile-details-content">
                        <div class="profile-info-grid">
                            <!-- Vorname -->
                            <div class="profile-info-item">
                                <div class="profile-info-label-value">
                                    <span class="profile-info-label">Vorname:</span>
                                    <?php if ($editing_field === 'vorname'): ?>
                                        <form method="POST" class="inline-edit-form">
                                            <input type="hidden" name="field_name" value="vorname">
                                            <input type="text" name="field_value" 
                                                   value="<?php echo htmlspecialchars($loaded_user['vorname'] ?? ''); ?>"
                                                   placeholder="Vorname eingeben" class="inline-input" autofocus>
                                            <div class="inline-form-actions">
                                                <button type="submit" name="save_field" class="btn-inline btn-save" title="Speichern">
                                                    <img src="images/speichern.png" width="20" height="20" alt="Speichern">
                                                </button>
                                                <button type="button" onclick="cancelEdit()" class="btn-inline btn-cancel" title="Abbrechen">
                                                    <img src="images/abbrechen.png" width="20" height="20" alt="Abbrechen">
                                                </button>
                                            </div>
                                        </form>
                                    <?php else: ?>
                                        <span class="profile-info-value">
                                            <?php echo displayFieldValue($loaded_user['vorname']); ?>
                                        </span>
                                        <form method="POST" class="inline-edit-form" style="margin-left:6px;">
                                            <input type="hidden" name="field_name" value="vorname">
                                            <button type="submit" name="edit_field" class="edit-icon" title="Bearbeiten">
                                                <img src="images/bearbeiten.png" width="20" height="20" alt="Bearbeiten">
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <!-- Nachname -->
                            <div class="profile-info-item">
                                <div class="profile-info-label-value">
                                    <span class="profile-info-label">Nachname:</span>
                                    <?php if ($editing_field === 'nachname'): ?>
                                        <form method="POST" class="inline-edit-form">
                                            <input type="hidden" name="field_name" value="nachname">
                                            <input type="text" name="field_value" 
                                                   value="<?php echo htmlspecialchars($loaded_user['nachname'] ?? ''); ?>"
                                                   placeholder="Nachname eingeben" class="inline-input" autofocus>
                                            <div class="inline-form-actions">
                                                <button type="submit" name="save_field" class="btn-inline btn-save" title="Speichern">
                                                    <img src="images/speichern.png" width="20" height="20" alt="Speichern">
                                                </button>
                                                <button type="button" onclick="cancelEdit()" class="btn-inline btn-cancel" title="Abbrechen">
                                                    <img src="images/abbrechen.png" width="20" height="20" alt="Abbrechen">
                                                </button>
                                            </form>
                                    <?php else: ?>
                                        <span class="profile-info-value">
                                            <?php echo displayFieldValue($loaded_user['nachname']); ?>
                                        </span>
                                        <form method="POST" class="inline-edit-form" style="margin-left:6px;">
                                            <input type="hidden" name="field_name" value="nachname">
                                            <button type="submit" name="edit_field" class="edit-icon" title="Bearbeiten">
                                                <img src="images/bearbeiten.png" width="20" height="20" alt="Bearbeiten">
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <!-- E-Mail -->
                            <div class="profile-info-item">
                                <div class="profile-info-label-value">
                                    <span class="profile-info-label">E-Mail:</span>
                                    <?php if ($editing_field === 'email'): ?>
                                        <form method="POST" class="inline-edit-form">
                                            <input type="hidden" name="field_name" value="email">
                                            <input type="email" name="field_value" 
                                                   value="<?php echo htmlspecialchars($loaded_user['email'] ?? ''); ?>"
                                                   placeholder="E-Mail Adresse eingeben" class="inline-input" autofocus>
                                            <div class="inline-form-actions">
                                                <button type="submit" name="save_field" class="btn-inline btn-save" title="Speichern">
                                                    <img src="images/speichern.png" width="20" height="20" alt="Speichern">
                                                </button>
                                                <button type="button" onclick="cancelEdit()" class="btn-inline btn-cancel" title="Abbrechen">
                                                    <img src="images/abbrechen.png" width="20" height="20" alt="Abbrechen">
                                                </button>
                                            </form>
                                    <?php else: ?>
                                        <span class="profile-info-value">
                                            <?php echo displayFieldValue($loaded_user['email']); ?>
                                        </span>
                                        <form method="POST" class="inline-edit-form" style="margin-left:6px;">
                                            <input type="hidden" name="field_name" value="email">
                                            <button type="submit" name="edit_field" class="edit-icon" title="Bearbeiten">
                                                <img src="images/bearbeiten.png" width="20" height="20" alt="Bearbeiten">
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <!-- Alter -->
                            <div class="profile-info-item">
                                <div class="profile-info-label-value">
                                    <span class="profile-info-label">Alter:</span>
                                    <?php if ($editing_field === 'alter'): ?>
                                        <form method="POST" class="inline-edit-form">
                                            <input type="hidden" name="field_name" value="alter">
                                            <input type="number" name="field_value" 
                                                   value="<?php echo htmlspecialchars($loaded_user['alter'] ?? ''); ?>"
                                                   placeholder="Alter eingeben" min="1" max="120" class="inline-input" autofocus>
                                            <div class="inline-form-actions">
                                                <button type="submit" name="save_field" class="btn-inline btn-save" title="Speichern">
                                                    <img src="images/speichern.png" width="20" height="20" alt="Speichern">
                                                </button>
                                                <button type="button" onclick="cancelEdit()" class="btn-inline btn-cancel" title="Abbrechen">
                                                    <img src="images/abbrechen.png" width="20" height="20" alt="Abbrechen">
                                                </button>
                                            </form>
                                    <?php else: ?>
                                        <span class="profile-info-value">
                                            <?php echo !empty($loaded_user['alter']) ? htmlspecialchars($loaded_user['alter']) . ' Jahre' : displayFieldValue($loaded_user['alter']); ?>
                                        </span>
                                        <form method="POST" class="inline-edit-form" style="margin-left:6px;">
                                            <input type="hidden" name="field_name" value="alter">
                                            <button type="submit" name="edit_field" class="edit-icon" title="Bearbeiten">
                                                <img src="images/bearbeiten.png" width="20" height="20" alt="Bearbeiten">
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <!-- Wohnort -->
                            <div class="profile-info-item">
                                <div class="profile-info-label-value">
                                    <span class="profile-info-label">Wohnort:</span>
                                    <?php if ($editing_field === 'wohnort'): ?>
                                        <form method="POST" class="inline-edit-form">
                                            <input type="hidden" name="field_name" value="wohnort">
                                            <input type="text" name="field_value" 
                                                   value="<?php echo htmlspecialchars($loaded_user['wohnort'] ?? ''); ?>"
                                                   placeholder="Wohnort eingeben" class="inline-input" autofocus>
                                            <div class="inline-form-actions">
                                                <button type="submit" name="save_field" class="btn-inline btn-save" title="Speichern">
                                                    <img src="images/speichern.png" width="20" height="20" alt="Speichern">
                                                </button>
                                                <button type="button" onclick="cancelEdit()" class="btn-inline btn-cancel" title="Abbrechen">
                                                    <img src="images/abbrechen.png" width="20" height="20" alt="Abbrechen">
                                                </button>
                                            </form>
                                    <?php else: ?>
                                        <span class="profile-info-value">
                                            <?php echo displayFieldValue($loaded_user['wohnort']); ?>
                                        </span>
                                        <form method="POST" class="inline-edit-form" style="margin-left:6px;">
                                            <input type="hidden" name="field_name" value="wohnort">
                                            <button type="submit" name="edit_field" class="edit-icon" title="Bearbeiten">
                                                <img src="images/bearbeiten.png" width="20" height="20" alt="Bearbeiten">
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <!-- Geburtstag -->
                            <div class="profile-info-item">
                                <div class="profile-info-label-value">
                                    <span class="profile-info-label">Geburtstag:</span>
                                    <?php if ($editing_field === 'geburtstag'): ?>
                                        <form method="POST" class="inline-edit-form">
                                            <input type="hidden" name="field_name" value="geburtstag">
                                            <input type="date" name="field_value" 
                                                   value="<?php echo htmlspecialchars($loaded_user['geburtstag'] ?? ''); ?>"
                                                   class="inline-input" autofocus>
                                            <div class="inline-form-actions">
                                                <button type="submit" name="save_field" class="btn-inline btn-save" title="Speichern">
                                                    <img src="images/speichern.png" width="20" height="20" alt="Speichern">
                                                </button>
                                                <button type="button" onclick="cancelEdit()" class="btn-inline btn-cancel" title="Abbrechen">
                                                    <img src="images/abbrechen.png" width="20" height="20" alt="Abbrechen">
                                                </button>
                                            </form>
                                    <?php else: ?>
                                        <span class="profile-info-value">
                                            <?php echo displayFieldValue($loaded_user['geburtstag'], 'date'); ?>
                                        </span>
                                        <form method="POST" class="inline-edit-form" style="margin-left:6px;">
                                            <input type="hidden" name="field_name" value="geburtstag">
                                            <button type="submit" name="edit_field" class="edit-icon" title="Bearbeiten">
                                                <img src="images/bearbeiten.png" width="20" height="20" alt="Bearbeiten">
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </details>
            </div>

            <!-- Kurse -->
            <div class="benutzer-section">
                <h3 class="benutzer-section-title">Kurse</h3>
                <?php if (empty($user_courses)): ?>
                    <p style="color: #999; font-size: 14px;">Keine Kurse zugewiesen</p>
                <?php else: ?>
                    <div class="benutzer-courses">
                        <?php foreach ($user_courses as $course): ?>
                            <span class="benutzer-course-badge" style="border-left: 4px solid <?php echo htmlspecialchars($course['farb_code'] ?? '#8fbced'); ?>;">
                                <?php echo htmlspecialchars($course['name']); ?>
                            </span>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Mittlere Spalte: Unterrichtstage -->
    <div>
        <div class="benutzer-info-card">
            <h3 class="benutzer-section-title">Unterrichtstage</h3>
            <?php if (empty($teaching_days)): ?>
                <p style="color: #999; font-size: 14px;">Keine Unterrichtstage vorhanden</p>
            <?php else: ?>
                <div class="benutzer-teaching-days">
                    <?php foreach ($teaching_days as $day): ?>
                        <?php
                            $date_obj = new DateTime($day['termin_datum']);
                            $day_name = ['Sonntag', 'Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag', 'Samstag'];
                            $german_day = $day_name[$date_obj->format('w')];
                            $formatted_date = $date_obj->format('d.m.Y');
                            $has_recurring = intval($day['wiederkehrend_count'] ?? 0) > 0;
                        ?>
                        <div class="teaching-day-item <?php echo $has_recurring ? 'has-recurring' : ''; ?>">
                            <div class="teaching-day-name">
                                <?php echo $german_day; ?>
                                <?php if ($has_recurring): ?>
                                    <span class="recurring-badge">
                                        <img src="images/Wiederholend.png" alt="Wiederkehrend" title="Wiederholt" width="16" height="16">
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="teaching-day-date"><?php echo $formatted_date; ?></div>
                            <div class="teaching-day-count"><?php echo intval($day['anzahl']); ?> Termin<?php echo intval($day['anzahl']) !== 1 ? 'e' : ''; ?></div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Rechte Spalte: Noten -->
    <div>
        <!-- NEU: Hausaufgaben-Panel (vor den Noten) -->
        <div class="benutzer-info-card" style="margin-bottom:16px;">
            <h3 class="benutzer-section-title">Hausaufgaben (<?php echo count($user_homeworks); ?>)</h3>
            <?php if (empty($user_homeworks)): ?>
                <p style="color: #999; font-size: 14px;">Keine Hausaufgaben vorhanden</p>
            <?php else: ?>
                <div style="display:flex; flex-direction:column; gap:10px;">
                    <?php foreach ($user_homeworks as $hw): 
                        $due = $hw['frist'] ?? null;
                        $kursName = htmlspecialchars($hw['kurs_name'] ?? 'Kurs');
                        $titel = htmlspecialchars($hw['titel'] ?? 'Hausaufgabe');
                        $beschreibung = trim($hw['beschreibung'] ?? $hw['text'] ?? '');
                        $isOverdue = $due && (new DateTime($due) < new DateTime());
                    ?>
                        <div style="padding:12px; border-radius:8px; background:<?php echo $isOverdue ? '#ffebee' : '#f8f9fa'; ?>; border-left:4px solid <?php echo htmlspecialchars($hw['farb_code'] ?? '#8fbced'); ?>;">
                            <div style="display:flex; justify-content:space-between; align-items:center; gap:12px;">
                                <!-- Linker Teil (klickbar für Details) -->
                                <div style="flex:1; cursor:pointer;" onclick="openHwDetail(<?php echo intval($hw['id']); ?>)">
                                    <div style="font-weight:700;"><?php echo $titel; ?></div>
                                    <div style="font-size:12px; color:#70757a; margin-top:4px;">
                                        <?php echo $kursName; ?> • Fällig: <?php echo $due ? (new DateTime($due))->format('d.m.Y') : 'Kein Datum'; ?>
                                    </div>
                                    <?php if ($beschreibung !== ''): ?>
                                        <div style="margin-top:8px; font-size:13px;"><?php echo nl2br(htmlspecialchars(mb_strimwidth($beschreibung, 0, 100, '…'))); ?></div>
                                    <?php endif; ?>
                                    <?php if ($hw['datei_name']): ?>
                                        <div style="margin-top:8px; font-size:12px;">
                                            <a href="Main.php?action=download_homework_file&file_id=<?php echo intval($hw['id']); ?>" 
                                            style="color:#1967d2; text-decoration:none; font-weight:700;"
                                            onclick="event.stopPropagation();">
                                                📥 <?php echo htmlspecialchars($hw['datei_name']); ?>
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                
                                <!-- Rechter Teil mit Icon und Löschen-Button -->
                                <div style="flex-shrink:0; display:flex; flex-direction:column; align-items:center; gap:6px;">
                                    <div style="font-size:24px;">
                                        <?php echo $isOverdue ? '⚠️' : '📝'; ?>
                                    </div>
                                    
                                    <?php if (hasRole('admin') || hasRole('lehrer')): ?>
                                    <button type="button" 
                                            class="btn-delete-hw" 
                                            data-hw-id="<?php echo intval($hw['id']); ?>"
                                            data-hw-title="<?php echo htmlspecialchars($titel); ?>"
                                            style="background:#f44336; color:white; border:none; border-radius:4px; padding:4px 8px; font-size:11px; cursor:pointer;"
                                            onclick="event.stopPropagation(); deleteHomework(<?php echo intval($hw['id']); ?>, '<?php echo htmlspecialchars(addslashes($titel)); ?>')">
                                        Löschen
                                    </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Modal für Hausaufgaben-Details (neu in benutzerOffen) -->
        <div id="hwDetailModal" class="cal-modal-overlay" style="display:none;" onclick="if(event.target===this) closeHwDetail()">
            <div class="cal-modal" role="dialog" aria-modal="true">
                <div class="cal-modal-header">
                    <h3 class="cal-modal-title">Hausaufgabe - Details</h3>
                    <button class="cal-modal-close" onclick="closeHwDetail()">×</button>
                </div>
                <div class="cal-modal-body" id="hwDetailBody" style="padding:14px;">
                    <!-- content wird per JS gefüllt -->
                </div>
                <div class="cal-modal-footer">
                    <button class="cal-btn cal-btn-secondary" onclick="closeHwDetail()">Schließen</button>
                </div>
            </div>
        </div>

        <script>
        function openHwDetail(hwId) {
            const modal = document.getElementById('hwDetailModal');
            const body = document.getElementById('hwDetailBody');
            body.innerHTML = '<div style="color:#666;">Lade…</div>';
            modal.style.display = 'flex';

            (async () => {
                const fd = new FormData();
                fd.append('action', 'get_homework_details');
                fd.append('homework_id', hwId);
                try {
                    const res = await fetch('Main.php', {method:'POST', body: fd, credentials:'same-origin'});
                    const json = await res.json();
                    if (!json.success) { body.innerHTML = '<div style="color:red;">Fehler</div>'; return; }
                    
                    const hw = json.homework || {};
                    const answers = json.answers || [];
                    let html = `<div style="margin-bottom:16px;">
                        <div style="font-size:16px; font-weight:700;">${(hw.titel||'').substring(0,100)}</div>
                        <div style="color:#666; font-size:13px; margin-top:4px;">
                            ${hw.kurs_name||'Kurs'} • Fällig: ${hw.frist ? new Date(hw.frist + 'T00:00:00').toLocaleDateString('de-DE') : 'Kein Datum'}
                        </div>
                    </div>
                    ${hw.beschreibung ? `<div style="padding:12px; background:#fbfdff; border-radius:8px; margin-bottom:12px; border-left:4px solid #1967d2;">${hw.beschreibung}</div>` : ''}
                    ${hw.datei_name ? `<div style="margin-bottom:12px;"><a href="Main.php?action=download_homework_file&file_id=${hw.id}" style="display:flex; align-items:center; gap:8px; color:#1967d2; text-decoration:none; font-weight:700;">📥 ${hw.datei_name}</a></div>` : ''}`;
                    
                    if (answers.length > 0) {
                        html += `<div style="margin-top:16px; padding-top:16px; border-top:1px solid #eef2f6;">
                            <div style="font-weight:700; margin-bottom:8px;">Antworten des Benutzers:</div>
                            ${answers.map(a => `
                                <div style="padding:10px; background:#e6ffe6; border-radius:8px; margin-bottom:8px;">
                                    <div style="font-size:12px; color:#666;">Hochgeladen: ${new Date(a.erstellt_am).toLocaleDateString('de-DE')}</div>
                                    ${a.text ? `<div style="margin-top:6px;">${a.text}</div>` : ''}
                                    ${a.datei_name ? `<a href="Main.php?action=download_answer_file&file_id=${a.id}" style="display:block; margin-top:8px; color:#4caf50; font-weight:700;">📎 ${a.datei_name}</a>` : ''}
                                </div>
                            `).join('')}
                        </div>`;
                    }
                    body.innerHTML = html;
                } catch (e) { console.error(e); body.innerHTML = '<div style="color:red;">Fehler beim Laden</div>'; }
            })();
        }
        // Funktion zum Löschen einer Hausaufgabe
        async function deleteHomework(hwId, hwTitle) {
            if (!confirm('Möchten Sie die Hausaufgabe "' + hwTitle + '" wirklich löschen?\n\nDiese Aktion kann nicht rückgängig gemacht werden!')) {
                return;
            }

            try {
                const fd = new FormData();
                fd.append('action', 'delete_hausaufgabe');
                fd.append('homework_id', hwId);

                const response = await fetch('Main.php', {
                    method: 'POST',
                    body: fd,
                    credentials: 'same-origin'
                });
                
                const result = await response.json();
                
                if (result.success) {
                    alert('Hausaufgabe wurde erfolgreich gelöscht!');
                    // Seite neu laden, um die Änderung anzuzeigen
                    location.reload();
                } else {
                    alert('Fehler beim Löschen: ' + (result.error || 'Unbekannter Fehler'));
                }
            } catch (error) {
                console.error('Fehler beim Löschen der Hausaufgabe:', error);
                alert('Ein Fehler ist aufgetreten. Bitte versuchen Sie es erneut.');
            }
        }
        function closeHwDetail() { document.getElementById('hwDetailModal').style.display = 'none'; }
        </script>

        <!-- Verbesserte Notenansicht mit Durchschnittswerten -->
        <div class="benutzer-info-card">
            <h3 class="benutzer-section-title">Noten (<?php echo count($user_notes); ?>)</h3>

            <?php
            // Berechne Gesamt- und Kursdurchschnitte
            $overallAvg = null;
            $notesByCourse = [];
            $courseColorMap = [];

            // 1) Initialisiere Einträge für alle Kurse, in denen der Benutzer ist
            if (!empty($user_courses)) {
                foreach ($user_courses as $c) {
                    $cname = $c['name'] ?? 'Unbekannt';
                    $notesByCourse[$cname] = [];
                    $courseColorMap[$cname] = $c['farb_code'] ?? null;
                }
            }

            // 2) Verteile vorhandene Noten auf die Kurs-Arrays (falls kurs nicht in $user_courses: hinzufügen)
            $sum = 0; $cnt = 0;
            foreach ($user_notes as $n) {
                $grade = intval($n['note']);
                $sum += $grade;
                $cnt++;
                $kname = $n['kurs_name'] ?? 'Unbekannt';
                if (!array_key_exists($kname, $notesByCourse)) {
                    // falls Note zu einem Kurs gehört, der nicht in $user_courses gelistet ist, trotzdem anzeigen
                    $notesByCourse[$kname] = [];
                }
                $notesByCourse[$kname][] = $n;
            }
            if ($cnt > 0) $overallAvg = $sum / $cnt;
             ?>

             <?php if ($overallAvg === null): ?>
                 <p style="color: #999; font-size: 14px;">Keine Noten vorhanden</p>
             <?php else: ?>
                 <div style="display:flex; gap:12px; align-items:center; margin-bottom:12px;">
                     <div style="flex:1; padding:12px; border-radius:8px; background:#f1f8ff; border-left:4px solid #1967d2;">
                         <div style="font-weight:700; font-size:16px; ">Durchschnittsnote</div>
                         <div style="font-size:22px; font-weight:800; margin-top:6px;"><?php echo number_format($overallAvg, 1, ',', '.'); ?></div>
                         <div style="color:#666; margin-top:6px;"><?php echo gradeToText((int)round($overallAvg)); ?></div>
                     </div>
                     <div style="min-width:150px; padding:12px; border-radius:8px; background:#fff8e6; border-left:4px solid #ffb300;">
                         <div style="font-weight:700;">Anzahl Noten</div>
                         <div style="font-size:20px; font-weight:700; margin-top:6px;"><?php echo count($user_notes); ?></div>
                     </div>
                 </div>

                <!-- Pro-Kurs Auflistung (alle Kurse, auch ohne Noten) -->
                <?php foreach ($notesByCourse as $courseName => $notesList):
                    $cSum = 0; $cCnt = 0;
                    foreach ($notesList as $nn) { $cSum += intval($nn['note']); $cCnt++; }
                    $cAvg = $cCnt ? ($cSum / $cCnt) : null;
                    $cColor = $courseColorMap[$courseName] ?? ($notesList[0]['farb_code'] ?? '#8fbced');
                ?>
                     <details style="margin-bottom:10px;">
                        <summary style="cursor:pointer; padding:10px; border-radius:8px; background:#fbfdff; display:flex; justify-content:space-between; align-items:center; border-left:4px solid <?php echo htmlspecialchars($cColor); ?>;">
                            <div style="font-weight:600;"><?php echo htmlspecialchars($courseName); ?></div>
                            <div style="font-size:13px; color:#555;">
                                <?php echo $cCnt; ?> Note<?php echo $cCnt !== 1 ? 'n' : ''; ?> • Durchschnitt: <?php echo $cAvg ? number_format($cAvg, 1, ',', '.') : '-'; ?>
                            </div>
                        </summary>

                         <div style="padding:12px; display:flex; flex-direction:column; gap:8px;">
                            <?php if (empty($notesList)): ?>
                                <div style="padding:12px; border-radius:8px; background:#fff7f0; color:#666;">Keine Noten in diesem Kurs.</div>
                            <?php else: foreach ($notesList as $note): ?>
                                <div style="padding:10px; border-radius:8px; background:#f8f9fa; display:flex; gap:12px; align-items:flex-start;">
                                    <div style="flex-shrink:0;">
                                        <div class="note-grade" style="background-color: <?php echo getGradeColor(intval($note['note'])); ?>; width:48px; height:48px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-weight:800; color:white; font-size:18px;">
                                            <?php echo intval($note['note']); ?>
                                        </div>
                                    </div>
                                    <div style="flex:1;">
                                        <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:8px;">
                                            <div style="font-weight:700;"><?php echo htmlspecialchars($note['titel'] ?? ''); ?></div>
                                            <div style="color:#70757a; font-size:12px;">
                                                <?php 
                                                    $dt = !empty($note['datum_erstellt']) ? (new DateTime($note['datum_erstellt']))->format('d.m.Y') : '';
                                                    echo $dt;
                                                ?>
                                            </div>
                                        </div>
                                        <?php if (!empty($note['beschreibung'])): ?>
                                            <div style="color:#444; margin-top:6px; font-size:13px;"><?php echo nl2br(htmlspecialchars($note['beschreibung'])); ?></div>
                                        <?php endif; ?>
                                        <div style="margin-top:8px; color:#3c4043; font-weight:600;"><?php echo gradeToText(intval($note['note'])); ?></div>
                                    </div>
                                </div>
                            <?php endforeach; endif; ?>
                         </div>
                     </details>
                 <?php endforeach; ?>
             <?php endif; ?>
         </div>
      </div>
  </div>
  
  <!-- Anwesenheits-Panel (kompakt) -->
  <div class="benutzer-info-card" style="margin-bottom:12px;">
    <h3 class="benutzer-section-title">Anwesenheit (<?php echo intval($user_att_counts['missed'] ?? 0); ?> Fehltage)</h3>
    <div style="display:flex; align-items:center; gap:12px; margin-bottom:8px;">
        <div style="font-size:13px; color:#666;">Anwesend: <strong><?php echo intval($user_att_counts['present'] ?? 0); ?></strong></div>
        <div style="font-size:13px; color:#666;">Nachgeholt: <strong><?php echo intval($user_att_counts['made_up'] ?? 0); ?></strong></div>
        <div style="margin-left:auto;">
            <button class="cal-btn cal-btn-secondary" onclick="openUserAttendanceModal(null, <?php echo intval($loaded_user['id']); ?>)">Alle →</button>
        </div>
    </div>

    <div style="display:flex; flex-direction:column; gap:8px;">
        <?php if (empty($user_attendance)): ?>
            <div style="color:#999;">Keine Einträge</div>
        <?php else: foreach ($user_attendance as $ar):
            $d = (new DateTime($ar['datum']))->format('d.m.Y');
            // Zeige korrekten Status: anwesend > nachgeholt > fehltag
            if ($ar['anwesend']) {
                $status = 'Anwesend';
                $color = '#4caf50';
                $showButton = false;
            } elseif ($ar['nachgeholt']) {
                $status = 'Nachgeholt';
                $color = '#ffb300';
                $showButton = false;
            } else {
                $status = 'Fehltag';
                $color = '#f44336';
                $showButton = true;
            }
        ?>
            <div class="teaching-day-item" style="display:flex; justify-content:space-between; align-items:center; padding:8px; background:#fbfdff; border-radius:8px; border-left:4px solid <?php echo $color; ?>; cursor:pointer;" onclick="<?php echo $showButton ? '' : 'openUserAttendanceModal(this, ' . intval($loaded_user['id']) . ')'; ?>">
                <div style="flex:1; min-width:0;">
                    <div style="font-weight:700;"><?php echo $d; ?></div>
                    <div style="color:#70757a; font-size:13px;"><?php echo htmlspecialchars(mb_strimwidth($ar['unterrichtsstoff'] ?? '',0,48,'…')); ?></div>
                    <?php if (!empty($ar['entschuldigung'])): ?>
                        <div style="color:#ff9800; font-size:12px; margin-top:4px;">📋 Entschuldigung vorhanden</div>
                    <?php endif; ?>
                </div>
                <div style="text-align:right; flex-shrink:0;">
                    <div style="font-size:13px; color:#555;"><?php echo $status; ?></div>
                    <?php if ($showButton): ?>
                        <button type="button" class="btn-nachgeholt" data-id="<?php echo intval($ar['id']); ?>" data-userid="<?php echo intval($loaded_user['id']); ?>" style="margin-top:6px; padding:6px 10px; background:#f44336; color:white; border:none; border-radius:4px; font-size:12px; font-weight:600; cursor:pointer; transition:all 0.2s;" onclick="markNachgeholt(event, this)">
                            Nachgeholt
                        </button>
                    <?php elseif (intval($ar['nachgeholt']) === 1): ?>
                        <div style="font-size:12px; color:#ffb300; font-weight:700; margin-top:4px;">✓ Nachgeholt</div>
                    <?php endif; ?>
                </div>
                <input type="hidden" class="att-data" value='<?php echo json_encode($ar, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT); ?>'>
            </div>
        <?php endforeach; endif; ?>
    </div>
</div>
<!-- Eintragungen Panel -->
<div class="benutzer-info-card" style="margin-bottom:12px;">
    <h3 class="benutzer-section-title">Eintragungen (<?php echo count($user_eintragungen); ?>)</h3>
    
    <?php if (empty($user_eintragungen)): ?>
        <p style="color: #999; font-size: 14px;">Keine Eintragungen vorhanden</p>
    <?php else: ?>
        <div style="display:flex; flex-direction:column; gap:8px;">
            <?php foreach ($user_eintragungen as $entry): 
                $d = (new DateTime($entry['datum']))->format('d.m.Y');
                $kursName = htmlspecialchars($entry['kurs_name'] ?? 'Kurs');
                $text = htmlspecialchars(mb_strimwidth($entry['text'] ?? '', 0, 200, '…'));
                $erstelltVon = htmlspecialchars($entry['erstellt_von_name'] ?? 'Admin');
            ?>
                <div style="padding:12px; background:#fff3cd; border-radius:8px; border-left:4px solid #ff9800;">
                    <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:12px;">
                        <div style="flex:1; min-width:0;">
                            <div style="font-weight:700; color:#333;">⚠️ Eintragung</div>
                            <div style="font-size:12px; color:#70757a; margin-top:4px;">
                                <?php echo $d; ?> • <?php echo $kursName; ?>
                            </div>
                            <div style="margin-top:8px; font-size:13px; line-height:1.4; color:#333;">
                                <?php echo $text; ?>
                            </div>
                            <div style="font-size:12px; color:#70757a; margin-top:8px;">
                                Erstellt von: <strong><?php echo $erstelltVon; ?></strong>
                            </div>
                        </div>
                        <div style="flex-shrink:0;">
                            <button type="button" 
                                    class="btn-expand-entry" 
                                    data-id="<?php echo intval($entry['id']); ?>"
                                    onclick="expandEintragEntry(this, <?php echo intval($entry['id']); ?>)"
                                    style="background:#ff9800; color:white; border:none; border-radius:4px; padding:6px 10px; font-size:12px; cursor:pointer;">
                                Details
                            </button>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<!-- Modal für Eintragungsdetails -->
<div id="eintragDetailModal" class="cal-modal-overlay" style="display:none;" onclick="if(event.target===this) closeModal('eintragDetailModal')">
    <div class="cal-modal small" role="dialog" aria-modal="true">
        <div class="cal-modal-header">
            <h3 class="cal-modal-title">Eintragung - Details</h3>
            <button class="cal-modal-close" onclick="closeModal('eintragDetailModal')">×</button>
        </div>
        <div class="cal-modal-body" id="eintragDetailBody" style="padding:14px;">
            <!-- content wird per JS gefüllt -->
        </div>
        <div class="cal-modal-footer">
            <button class="cal-btn cal-btn-secondary" onclick="closeModal('eintragDetailModal')">Schließen</button>
        </div>
    </div>
</div>

<style>
.btn-expand-entry:hover {
    background: #e68900;
    transform: translateY(-1px);
}
</style>

<script>
function expandEintragEntry(btn, entryId) {
    const modal = document.getElementById('eintragDetailModal');
    const body = document.getElementById('eintragDetailBody');
    
    // Finde die Eintragung aus dem Panel
    const allEntries = <?php echo json_encode($user_eintragungen, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT); ?>;
    const entry = allEntries.find(e => e.id == entryId);
    
    if (!entry) {
        body.innerHTML = '<div style="color:#666;">Eintragung nicht gefunden</div>';
        modal.style.display = 'flex';
        return;
    }
    
    const d = new Date(entry.datum + 'T00:00:00').toLocaleDateString('de-DE');
    const html = `
        <div style="padding:12px;">
            <div style="font-weight:700; font-size:16px; color:#333; margin-bottom:12px;">⚠️ Eintragung</div>
            
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
                <div style="font-size:13px; color:#70757a;"><strong>Datum:</strong> ${d}</div>
                <div style="padding:4px 8px; background:#ff9800; color:white; border-radius:4px; font-size:12px; font-weight:700;">Aktiv</div>
            </div>
            
            <div style="margin-bottom:12px;">
                <div style="font-size:12px; color:#70757a; margin-bottom:4px;"><strong>Kurs:</strong></div>
                <div style="font-size:14px; color:#333;">${entry.kurs_name || 'Kurs'}</div>
            </div>
            
            <div style="margin-bottom:12px;">
                <div style="font-size:12px; color:#70757a; margin-bottom:4px;"><strong>Eintragungstext:</strong></div>
                <div style="padding:10px; background:#fbfdff; border-radius:8px; border-left:4px solid #ff9800; line-height:1.5; color:#333;">
                    ${entry.text || 'Kein Text vorhanden'}
                </div>
            </div>
            
            <div style="padding-top:12px; border-top:1px solid #eef2f6;">
                <div style="font-size:12px; color:#70757a;"><strong>Erstellt von:</strong> ${entry.erstellt_von_name || 'Admin'}</div>
            </div>
        </div>
    `;
    body.innerHTML = html;
    modal.style.display = 'flex';
}

function closeModal(id) {
    const el = document.getElementById(id);
    if (el) el.style.display = 'none';
}
</script>
<!-- Modal für Benutzer-Anwesenheit (gleiche Struktur wie Dashboard, aber für target user) -->
<div id="userAttendanceModal" class="cal-modal-overlay" style="display:none;" onclick="if(event.target===this) closeUserAttendanceModal()">
    <div class="cal-modal small" role="dialog" aria-modal="true">
        <div class="cal-modal-header">
            <h3 class="cal-modal-title">Anwesenheits-Details</h3>
            <button class="cal-modal-close" onclick="closeUserAttendanceModal()">×</button>
        </div>
        <div class="cal-modal-body" id="userAttendanceBody" style="padding:12px;">
            <!-- content per JS -->
        </div>
        <div class="cal-modal-footer">
            <button class="cal-btn cal-btn-secondary" onclick="closeUserAttendanceModal()">Schließen</button>
        </div>
    </div>
</div>

<script>
async function openUserAttendanceModal(elOrNull, targetUserId) {
    const modal = document.getElementById('userAttendanceModal');
    const body = document.getElementById('userAttendanceBody');
    body.innerHTML = '<div style="padding:12px;color:#666;">Lade…</div>';
    modal.style.display = 'flex';

    if (!elOrNull) {
        // lade alle Einträge via AJAX
        const fd = new FormData();
        fd.append('action','get_user_anwesenheit');
        fd.append('user_id', targetUserId);
        const res = await fetch('Main.php',{method:'POST', body: fd, credentials: 'same-origin'});
        const json = await res.json();
        if (!json.success) { body.innerHTML = '<div class="error-message">Fehler</div>'; return; }
        const rows = json.rows || [];
        if (rows.length === 0) { body.innerHTML = '<div style="color:#666;">Keine Einträge</div>'; return; }
        body.innerHTML = rows.map(r=>{
            const dt = new Date(r.datum + 'T00:00:00').toLocaleDateString('de-DE');
            // korrekter Status: anwesend > nachgeholt > fehltag
            const status = r.anwesend==1 ? 'Anwesend' : (r.nachgeholt==1 ? 'Nachgeholt' : 'Fehltag');
            const editable = <?php echo (hasRole('admin') || hasRole('lehrer')) ? 'true' : 'false'; ?>;
            return `<div style="padding:8px;border-bottom:1px solid #f0f0f0;">
                <div style="display:flex;justify-content:space-between;align-items:center; gap:12px;">
                    <div style="flex:1;"><strong>${dt}</strong>
                        <div style="color:#666; font-size:12px;">${(r.unterrichtsstoff||'')}</div>
                        ${r.entschuldigung ? '<div style="color:#ff9800; font-size:12px; margin-top:4px;"><strong>Entschuldigung:</strong> ' + r.entschuldigung + '</div>' : ''}
                    </div>
                    <div style="text-align:right; flex-shrink:0;">
                        <div style="font-size:13px;color:#70757a;">${status}</div>
                        ${(!r.anwesend && editable ? `<label style="display:block;margin-top:6px;"><input type="checkbox" data-id="${r.id}" ${r.nachgeholt==1 ? 'checked' : ''} onchange="toggleNachgeholtUser(this, ${targetUserId})"> Nachgeholt</label>` : '')}
                    </div>
                </div>
            </div>`;
        }).join('');
    } else {
        // elOrNull ist anwesenheit-Row im DOM: lese data
        const dataInput = elOrNull.querySelector('.att-data');
        const entry = dataInput ? JSON.parse(dataInput.value) : null;
        if (!entry) { body.innerHTML = '<div style="color:#666;">Keine Daten</div>'; return; }
        const dt = new Date(entry.datum + 'T00:00:00').toLocaleDateString('de-DE');
        const status = entry.anwesend==1 ? 'Anwesend' : (entry.nachgeholt==1 ? 'Nachgeholt' : 'Fehltag');
        const editable = <?php echo (hasRole('admin') || hasRole('lehrer')) ? 'true' : 'false'; ?>;
        body.innerHTML = `<div style="padding:8px;">
            <div style="font-weight:700;font-size:16px;">${dt}</div>
            <div style="color:#666;margin-top:6px;">${entry.unterrichtsstoff ? '<strong>Unterricht:</strong> ' + entry.unterrichtsstoff : ''}</div>
            ${entry.entschuldigung ? '<div style="color:#ff9800;margin-top:6px;"><strong>Entschuldigung:</strong> ' + entry.entschuldigung + '</div>' : ''}
            <div style="margin-top:10px;">
                <div style="font-size:13px;color:#70757a;">Status: ${status}</div>
                ${!entry.anwesend && editable ? `<label style="display:block;margin-top:8px;"><input type="checkbox" data-id="${entry.id}" ${entry.nachgeholt==1 ? 'checked' : ''} onchange="toggleNachgeholtUser(this, ${targetUserId})"> Nachgeholt</label>` : ''}
            </div>
        </div>`;
    }
}

function closeUserAttendanceModal(){ document.getElementById('userAttendanceModal').style.display='none'; }

async function toggleNachgeholtUser(chk, targetUserId) {
    const id = chk.dataset.id;
    const val = chk.checked ? 1 : 0;
    const fd = new FormData();
    fd.append('action','toggle_anwesenheit');
    fd.append('id', id);
    fd.append('nachgeholt', val ? 1 : 0);
    const res = await fetch('Main.php',{method:'POST', body: fd, credentials: 'same-origin'});
    const json = await res.json();
    if (json.success) {
        // reload page fragment um UI konsistent zu halten
        location.reload();
    } else {
        alert('Fehler beim Aktualisieren');
        chk.checked = !chk.checked;
    }
}

async function markNachgeholt(event, btn) {
    event.stopPropagation();
    
    const id = btn.dataset.id;
    const userId = btn.dataset.userid;
    
    const fd = new FormData();
    fd.append('action', 'toggle_anwesenheit');
    fd.append('id', id);
    fd.append('nachgeholt', 1);
    
    try {
        const res = await fetch('Main.php', { method: 'POST', body: fd, credentials: 'same-origin' });
        const json = await res.json();
        
        if (json.success) {
            // Finde die Row und update die Farbe von rot zu orange
            const row = btn.closest('.teaching-day-item');
            if (row) {
                // Änder die Randfarbe zu orange
                row.style.borderLeftColor = '#ffb300';
                // Ersetze den Button mit dem "Nachgeholt"-Text
                const statusDiv = row.querySelector('div[style*="text-align:right"]');
                if (statusDiv) {
                    btn.remove();
                    const nachgeholText = document.createElement('div');
                    nachgeholText.style.cssText = 'font-size:12px; color:#ffb300; font-weight:700; margin-top:4px;';
                    nachgeholText.textContent = '✓ Nachgeholt';
                    statusDiv.appendChild(nachgeholText);
                }
            }
        } else {
            alert('Fehler beim Aktualisieren');
        }
    } catch (e) {
        console.error('markNachgeholt error', e);
        alert('Fehler beim Markieren als Nachgeholt');
    }
}
</script>
