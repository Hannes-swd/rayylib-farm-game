<?php
// ORDER BY h.frist ASC, h.erstellt_am DESC
// Erwartet: $pdo, $user aus Main.php

$user_id = intval($user['id'] ?? 0);

// --- Daten sammeln (sicher, mit Prepared Statements) ---
$user_courses = [];
try {
    $courses_str = $user['courses'] ?? '';
    $course_names = array_values(array_filter(array_map('trim', explode(',', $courses_str))));
    if (!empty($course_names)) {
        $ph = implode(',', array_fill(0, count($course_names), '?'));
        $stmt = $pdo->prepare("SELECT id, name, info, farb_code FROM kurse WHERE name IN ($ph) ORDER BY name");
        $stmt->execute($course_names);
        $user_courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        // Fallback: wenn Admin/Lehrer, zeige alle Kurse
        if (isset($user['roles']) && (str_contains($user['roles'],'admin') || str_contains($user['roles'],'lehrer'))) {
            $stmt = $pdo->query("SELECT id, name, info, farb_code FROM kurse ORDER BY name");
            $user_courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
    }
} catch (PDOException $e) {
    error_log("dashboard courses: " . $e->getMessage());
    $user_courses = [];
}

// Letzte Noten des Benutzers
$user_notes = [];
try {
    if ($user_id > 0) {
        $stmt = $pdo->prepare("SELECT n.id, n.titel, n.note, n.beschreibung, n.datum_erstellt, k.name AS kurs_name, k.farb_code 
                               FROM noten n LEFT JOIN kurse k ON n.kurs_id = k.id
                               WHERE n.benutzer_id = ? ORDER BY n.datum_erstellt DESC LIMIT 50");
        $stmt->execute([$user_id]);
        $user_notes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (PDOException $e) {
    error_log("dashboard notes: " . $e->getMessage());
    $user_notes = [];
}

// Kommende Termine (einfach)
$upcoming_events = [];
try {
    $today = date('Y-m-d');
    $course_ids = array_map(function($c){ return intval($c['id']); }, $user_courses);
    if (!empty($course_ids)) {
        $ph = implode(',', array_fill(0, count($course_ids), '?'));
        $params = $course_ids;
        $params[] = $today; $params[] = $today;
        $sql = "SELECT t.*, k.name AS kurs_name, k.farb_code 
                FROM termine t LEFT JOIN kurse k ON t.kurs_id = k.id
                WHERE t.kurs_id IN ($ph) AND (
                    (t.ist_wiederkehrend = 0 AND t.datum >= ?)
                    OR (t.ist_wiederkehrend = 1 AND (t.wiederholung_bis IS NULL OR t.wiederholung_bis >= ?))
                ) ORDER BY t.datum ASC, t.uhrzeit_start ASC LIMIT 10";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $upcoming_events = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (PDOException $e) {
    error_log("dashboard events: " . $e->getMessage());
    $upcoming_events = [];
}

// Anwesenheit kurz zusammenfassen (für aktuellen Benutzer)
$attendance_summary = ['present'=>0,'missed'=>0,'made_up'=>0];
$attendance_rows = [];
try {
    if ($user_id > 0) {
        $stmt = $pdo->prepare("SELECT id, datum, anwesend, nachgeholt, unterrichtsstoff FROM anwesenheit WHERE benutzer_id = ? ORDER BY datum DESC LIMIT 6");
        $stmt->execute([$user_id]);
        $attendance_rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $stmtC = $pdo->prepare("SELECT 
            SUM(CASE WHEN anwesend = 1 THEN 1 ELSE 0 END) AS present,
            SUM(CASE WHEN anwesend = 0 AND nachgeholt = 0 THEN 1 ELSE 0 END) AS missed,
            SUM(CASE WHEN nachgeholt = 1 THEN 1 ELSE 0 END) AS made_up
            FROM anwesenheit WHERE benutzer_id = ?");
        $stmtC->execute([$user_id]);
        $attendance_summary = $stmtC->fetch(PDO::FETCH_ASSOC) ?: $attendance_summary;
    }
} catch (PDOException $e) {
    error_log("dashboard attendance: " . $e->getMessage());
}

// Hausaufgaben für den Benutzer laden
// Hausaufgaben für den Benutzer laden
$user_homeworks = [];
try {
    if ($user_id > 0) {
        $courses_str = $user['courses'] ?? '';
        $course_names = array_values(array_filter(array_map('trim', explode(',', $courses_str))));
        
        if (!empty($course_names)) {
            $ph = implode(',', array_fill(0, count($course_names), '?'));
            $stmt_course_ids = $pdo->prepare("SELECT id FROM kurse WHERE name IN ($ph)");
            $stmt_course_ids->execute($course_names);
            $course_ids_array = $stmt_course_ids->fetchAll(PDO::FETCH_COLUMN);
            
            if (!empty($course_ids_array)) {
                $ph = implode(',', array_fill(0, count($course_ids_array), '?'));
                $sql = "SELECT h.*, k.name AS kurs_name, k.farb_code 
                        FROM hausaufgaben h
                        LEFT JOIN kurse k ON h.kurs_id = k.id
                        WHERE h.kurs_id IN ($ph)
                        ORDER BY COALESCE(h.frist, h.erstellt_am) ASC
                        LIMIT 50";
                $stmt_hw = $pdo->prepare($sql);
                $stmt_hw->execute($course_ids_array);
                $user_homeworks = $stmt_hw->fetchAll(PDO::FETCH_ASSOC);
            }
        }
    }
} catch (PDOException $e) {
    error_log("dashboard homeworks: " . $e->getMessage());
    $user_homeworks = [];
}

// --- Hilfsfunktionen lokal ---
function gradeToText($g) {
    $m = [1=>'Sehr gut',2=>'Gut',3=>'Befriedigend',4=>'Ausreichend',5=>'Mangelhaft',6=>'Ungenügend'];
    return $m[intval($g)] ?? 'Unbekannt';
}
function gradeColor($g) {
    $c = [1=>'#4caf50',2=>'#8bc34a',3=>'#ff9800',4=>'#ff5722',5=>'#f44336',6=>'#c62828'];
    return $c[intval($g)] ?? '#999';
}
function short($s, $n=80){ return htmlspecialchars(mb_strimwidth($s,0,$n,'…')); }
function h($s){ return htmlspecialchars($s); }

?>
<!-- Responsive Dashboard UI mit sauberem Grid-Layout -->
<style>
:root{
    --card-bg: #fff;
    --card-border: #eef2f6;
    --card-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
    --card-radius: 12px;
    --accent: #1967d2;
    --accent-light: rgba(25, 103, 210, 0.1);
    --text-primary: #1f2937;
    --text-secondary: #6b7280;
    --text-muted: #9ca3af;
    --success: #10b981;
    --warning: #f59e0b;
    --danger: #ef4444;
    --gap: 16px;
}

.dashboard-container {
    max-width: 1400px;
    margin: 20px auto;
    padding: 0 16px;
    box-sizing: border-box;
}

.dashboard-header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 24px;
    border-radius: var(--card-radius);
    margin-bottom: 24px;
    box-shadow: var(--card-shadow);
}

.dashboard-header h1 {
    margin: 0 0 8px 0;
    font-size: 28px;
    font-weight: 700;
}

.dashboard-header p {
    margin: 0;
    opacity: 0.9;
    font-size: 16px;
}

.dashboard-grid {
    display: grid;
    grid-template-columns: repeat(12, 1fr);
    gap: var(--gap);
}

/* Card Styles */
.dashboard-card {
    background: var(--card-bg);
    border: 1px solid var(--card-border);
    border-radius: var(--card-radius);
    box-shadow: var(--card-shadow);
    padding: 20px;
    transition: transform 0.2s, box-shadow 0.2s;
    height: 100%;
    display: flex;
    flex-direction: column;
}

.dashboard-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.08);
}

.card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
    padding-bottom: 12px;
    border-bottom: 1px solid #f3f4f6;
}

.card-header h2 {
    margin: 0;
    font-size: 18px;
    font-weight: 600;
    color: var(--text-primary);
}

.card-header .card-count {
    background: var(--accent-light);
    color: var(--accent);
    font-size: 14px;
    font-weight: 600;
    padding: 4px 12px;
    border-radius: 20px;
}

.card-content {
    flex: 1;
    overflow: hidden;
}

/* Course Chips */
.course-chips {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    margin-bottom: 16px;
}

.course-chip {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 8px 12px;
    background: var(--accent-light);
    color: var(--accent);
    border-radius: 20px;
    font-size: 14px;
    font-weight: 500;
    text-decoration: none;
    transition: all 0.2s;
    border: 1px solid rgba(25, 103, 210, 0.2);
}

.course-chip:hover {
    background: rgba(25, 103, 210, 0.15);
    transform: translateY(-1px);
    text-decoration: none;
}

/* Note Items */
.note-item {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 12px;
    border-radius: 8px;
    background: #f9fafb;
    margin-bottom: 8px;
    transition: background 0.2s;
}

.note-item:hover {
    background: #f3f4f6;
}

.note-info {
    flex: 1;
    min-width: 0;
    margin-right: 12px;
}

.note-title {
    font-weight: 600;
    color: var(--text-primary);
    margin-bottom: 4px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.note-meta {
    font-size: 12px;
    color: var(--text-muted);
}

.note-grade {
    display: flex;
    flex-direction: column;
    align-items: center;
    min-width: 60px;
}

.grade-badge {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 700;
    font-size: 16px;
    color: white;
    margin-bottom: 4px;
}

.grade-text {
    font-size: 11px;
    font-weight: 600;
    color: var(--text-secondary);
}

/* Event Items */
.event-item {
    display: flex;
    align-items: flex-start;
    padding: 12px;
    border-radius: 8px;
    background: #f9fafb;
    margin-bottom: 8px;
    transition: background 0.2s;
}

.event-item:hover {
    background: #f3f4f6;
}

.event-color {
    width: 4px;
    border-radius: 2px;
    margin-right: 12px;
    flex-shrink: 0;
    align-self: stretch;
}

.event-content {
    flex: 1;
    min-width: 0;
}

.event-title {
    font-weight: 600;
    color: var(--text-primary);
    margin-bottom: 4px;
}

.event-meta {
    font-size: 12px;
    color: var(--text-muted);
    margin-bottom: 6px;
}

.event-note {
    font-size: 13px;
    color: var(--text-secondary);
    line-height: 1.4;
}

/* Attendance Summary */
.attendance-summary {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 12px;
    margin-bottom: 20px;
}

.summary-item {
    text-align: center;
    padding: 12px;
    border-radius: 8px;
    background: #f9fafb;
}

.summary-value {
    font-size: 24px;
    font-weight: 700;
    margin-bottom: 4px;
}

.summary-label {
    font-size: 12px;
    color: var(--text-muted);
}

.summary-present .summary-value { color: var(--success); }
.summary-missed .summary-value { color: var(--danger); }
.summary-madeup .summary-value { color: var(--warning); }

.attendance-list {
    max-height: 240px;
    overflow-y: auto;
}

.attendance-item {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px;
    border-radius: 6px;
    background: #f9fafb;
    margin-bottom: 6px;
    cursor: pointer;
    transition: background 0.2s;
}

.attendance-item:hover {
    background: #f3f4f6;
}

.attendance-date {
    font-weight: 600;
    font-size: 14px;
    color: var(--text-primary);
}

.attendance-status {
    font-size: 12px;
    font-weight: 600;
    padding: 3px 8px;
    border-radius: 12px;
}

.status-present { background: #d1fae5; color: #065f46; }
.status-missed { background: #fee2e2; color: #991b1b; }
.status-madeup { background: #fef3c7; color: #92400e; }

/* Homework Items */
.homework-item {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 12px;
    border-radius: 8px;
    background: #f9fafb;
    margin-bottom: 8px;
    cursor: pointer;
    transition: background 0.2s;
}

.homework-item:hover {
    background: #f3f4f6;
}

.homework-info {
    flex: 1;
    min-width: 0;
    margin-right: 12px;
}

.homework-title {
    font-weight: 600;
    color: var(--text-primary);
    margin-bottom: 4px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.homework-meta {
    font-size: 12px;
    color: var(--text-muted);
    margin-bottom: 4px;
}

.homework-desc {
    font-size: 13px;
    color: var(--text-secondary);
    line-height: 1.4;
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
}

.homework-icon {
    font-size: 24px;
    flex-shrink: 0;
}

/* Empty States */
.empty-state {
    text-align: center;
    padding: 32px 16px;
    color: var(--text-muted);
}

.empty-state i {
    font-size: 48px;
    margin-bottom: 12px;
    opacity: 0.3;
}

.empty-state p {
    margin: 0;
    font-size: 14px;
}

/* View All Links */
.view-all {
    display: block;
    text-align: right;
    margin-top: 12px;
    font-size: 14px;
    font-weight: 600;
    color: var(--accent);
    text-decoration: none;
    transition: color 0.2s;
}

.view-all:hover {
    color: #1557b0;
    text-decoration: underline;
}

/* Chart Container */
.chart-container {
    height: 240px;
    width: 100%;
    position: relative;
}

/* Grid Spans */
.span-12 { grid-column: span 12; }
.span-8 { grid-column: span 8; }
.span-6 { grid-column: span 6; }
.span-4 { grid-column: span 4; }
.span-3 { grid-column: span 3; }

/* Responsive */
@media (max-width: 1200px) {
    .dashboard-grid {
        grid-template-columns: repeat(6, 1fr);
    }
    .span-8 { grid-column: span 6; }
    .span-6 { grid-column: span 6; }
    .span-4 { grid-column: span 3; }
    .span-3 { grid-column: span 3; }
}

@media (max-width: 768px) {
    .dashboard-grid {
        grid-template-columns: repeat(1, 1fr);
        gap: 12px;
    }
    .span-8, .span-6, .span-4, .span-3 { grid-column: span 1; }
    
    .attendance-summary {
        grid-template-columns: repeat(3, 1fr);
    }
    
    .dashboard-card {
        padding: 16px;
    }
    
    .dashboard-header {
        padding: 20px;
    }
    
    .dashboard-header h1 {
        font-size: 24px;
    }
}

@media (max-width: 480px) {
    .attendance-summary {
        grid-template-columns: 1fr;
        gap: 8px;
    }
    
    .dashboard-container {
        padding: 0 12px;
    }
}

/* Scrollbar Styling */
.attendance-list::-webkit-scrollbar,
.card-content::-webkit-scrollbar {
    width: 4px;
}

.attendance-list::-webkit-scrollbar-track,
.card-content::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 2px;
}

.attendance-list::-webkit-scrollbar-thumb,
.card-content::-webkit-scrollbar-thumb {
    background: #c1c1c1;
    border-radius: 2px;
}

.attendance-list::-webkit-scrollbar-thumb:hover,
.card-content::-webkit-scrollbar-thumb:hover {
    background: #a1a1a1;
}
</style>

<div class="dashboard-container">
    

    <!-- Main Grid -->
    <div class="dashboard-grid">
        <!-- Kursübersicht & Noten Chart -->
        <div class="dashboard-card span-8">
            <div class="card-header">
                <h2>Noten-Übersicht</h2>
                <div class="card-count"><?php echo count($user_courses); ?> Kurse</div>
            </div>
            <div class="card-content">
                <div class="course-chips">
                    <?php if (empty($user_courses)): ?>
                        <div class="empty-state">
                            <p>Keine Kurse zugewiesen</p>
                        </div>
                    <?php else: 
                        foreach($user_courses as $c): ?>
                            <a href="Main.php?page=KursOffen&course_id=<?php echo intval($c['id']); ?>" class="course-chip">
                                <?php echo h($c['name']); ?>
                            </a>
                        <?php endforeach; 
                    endif; ?>
                </div>
                
                <?php if (!empty($user_notes)): ?>
                    <div class="chart-container">
                        <canvas id="gradesChart"></canvas>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <p>Noch keine Noten vorhanden</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Anwesenheit Quick View -->
<div class="dashboard-card span-4">
    <div class="card-header">
        <h2>Anwesenheit</h2>
        <div class="card-count"><?php echo intval($attendance_summary['missed'] ?? 0); ?> Fehltage</div>
    </div>
    <div class="card-content">
        <div class="attendance-summary">
            <div class="summary-item summary-present">
                <div class="summary-value"><?php echo intval($attendance_summary['present'] ?? 0); ?></div>
                <div class="summary-label">Anwesend</div>
            </div>
            <div class="summary-item summary-missed">
                <div class="summary-value"><?php echo intval($attendance_summary['missed'] ?? 0); ?></div>
                <div class="summary-label">Fehltage</div>
            </div>
            <div class="summary-item summary-madeup">
                <div class="summary-value"><?php echo intval($attendance_summary['made_up'] ?? 0); ?></div>
                <div class="summary-label">Nachgeholt</div>
            </div>
        </div>
        
        <div class="attendance-list">
            <?php 
            if (empty($attendance_rows)): ?>
                <div class="empty-state">
                    <p>Keine Einträge vorhanden</p>
                </div>
            <?php else: 
                // Nur die ersten 3 Einträge zeigen
                $first_three = array_slice($attendance_rows, 0, 3);
                foreach ($first_three as $ar): 
                    $d = (new DateTime($ar['datum']))->format('d.m.Y');
                    if ($ar['anwesend']) {
                        $status = 'Anwesend';
                        $statusClass = 'status-present';
                    } elseif ($ar['nachgeholt']) {
                        $status = 'Nachgeholt';
                        $statusClass = 'status-madeup';
                    } else {
                        $status = 'Fehltag';
                        $statusClass = 'status-missed';
                    }
            ?>
                <div class="attendance-item" data-entry='<?php echo json_encode($ar, JSON_HEX_APOS|JSON_HEX_QUOT); ?>' onclick="openAttendanceModal(this)">
                    <div class="attendance-date"><?php echo $d; ?></div>
                    <div class="attendance-status <?php echo $statusClass; ?>"><?php echo $status; ?></div>
                </div>
            <?php endforeach; 
                
                // Wenn mehr als 3 Einträge vorhanden sind, Hinweis anzeigen
                if (count($attendance_rows) > 3): ?>
                    <div style="text-align: center; margin-top: 12px; padding: 8px; background: #f8fafc; border-radius: 8px; border: 1px dashed #e2e8f0;">
                        <div style="color: #64748b; font-size: 13px; font-weight: 500;">
                            <?php echo count($attendance_rows) - 3; ?> weitere Einträge
                        </div>
                        <div style="color: #94a3b8; font-size: 12px; margin-top: 2px;">
                            Klicke auf "Alle Details" unten
                        </div>
                    </div>
                <?php endif;
            endif; ?>
        </div>
        
        <a href="javascript:void(0)" onclick="openAttendanceModal(null)" class="view-all">Alle Details →</a>
    </div>
</div>

<!-- Vereinfachtes JavaScript -->
<script>
// Attendance Modal
async function openAttendanceModal(elOrNull) {
    const modal = document.getElementById('attendanceModal');
    const body = document.getElementById('attendanceModalBody');
    body.innerHTML = '<div style="padding:20px; text-align:center; color:#666;"><div class="loading-spinner" style="width:40px;height:40px;border:3px solid #f3f3f3;border-top:3px solid #3498db;border-radius:50%;margin:0 auto 16px;animation:spin 1s linear infinite;"></div><style>@keyframes spin{0%{transform:rotate(0deg);}100%{transform:rotate(360deg);}}</style>Lade Anwesenheitsdaten…</div>';
    modal.style.display = 'flex';
    
    // Wenn Klick auf einen einzelnen Eintrag
    if (elOrNull) {
        const entry = JSON.parse(elOrNull.dataset.entry);
        const dt = new Date(entry.datum + 'T00:00:00').toLocaleDateString('de-DE');
        let status = 'Fehltag';
        let statusColor = '#ef4444';
        let statusText = 'Nicht anwesend';
        
        if (entry.anwesend == 1) {
            status = 'Anwesend';
            statusColor = '#10b981';
            statusText = 'Anwesend';
        } else if (entry.nachgeholt == 1) {
            status = 'Nachgeholt';
            statusColor = '#f59e0b';
            statusText = 'Fehltag nachgeholt';
        }
        
        body.innerHTML = `
            <div style="padding:16px;">
                <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;padding-bottom:16px;border-bottom:1px solid #e5e7eb;">
                    <div>
                        <div style="font-weight:700;font-size:20px;color:#1f2937;">${dt}</div>
                        <div style="font-size:14px;color:#6b7280;margin-top:4px;">${entry.uhrzeit_start ? entry.uhrzeit_start + (entry.uhrzeit_end ? ' - ' + entry.uhrzeit_end : '') : 'Ganztägig'}</div>
                    </div>
                    <div style="padding:6px 16px;border-radius:20px;background:${statusColor}20;color:${statusColor};font-weight:600;font-size:14px;">
                        ${status}
                    </div>
                </div>
                
                ${entry.unterrichtsstoff ? `
                    <div style="margin-bottom:20px;">
                        <div style="font-weight:600;color:#374151;margin-bottom:8px;font-size:14px;">📚 Unterrichtsstoff:</div>
                        <div style="color:#4b5563;background:#f9fafb;padding:16px;border-radius:8px;border-left:4px solid #8b5cf6;line-height:1.6;">
                            ${entry.unterrichtsstoff}
                        </div>
                    </div>
                ` : ''}
                
                ${entry.entschuldigung ? `
                    <div style="margin-bottom:20px;">
                        <div style="font-weight:600;color:#374151;margin-bottom:8px;font-size:14px;">📝 Entschuldigung:</div>
                        <div style="color:#4b5563;background:#f9fafb;padding:16px;border-radius:8px;border-left:4px solid #3b82f6;line-height:1.6;">
                            ${entry.entschuldigung}
                        </div>
                    </div>
                ` : ''}
                
                <div style="margin-top:24px;padding-top:16px;border-top:1px solid #e5e7eb;">
                    <div style="display:flex;justify-content:space-between;align-items:center;">
                        <div style="font-size:14px;color:#6b7280;">Status: <strong style="color:${statusColor}">${statusText}</strong></div>
                        ${entry.nachgeholt !== undefined ? `
                            <label style="display:flex;align-items:center;gap:8px;cursor:pointer;">
                                <input type="checkbox" ${entry.nachgeholt == 1 ? 'checked' : ''} 
                                       onchange="toggleNachgeholt(this)" 
                                       data-id="${entry.id}"
                                       style="width:18px;height:18px;cursor:pointer;">
                                <span style="font-size:14px;color:#374151;">Nachgeholt</span>
                            </label>
                        ` : ''}
                    </div>
                </div>
            </div>
        `;
        return;
    }
    
    // Wenn "Alle Details" angefordert wird
    try {
        const fd = new FormData();
        fd.append('action','get_user_anwesenheit');
        fd.append('user_id', <?php echo intval($user_id); ?>);
        const res = await fetch('Main.php',{method:'POST', body: fd, credentials: 'same-origin'});
        const json = await res.json();
        
        if (!json.success) { 
            body.innerHTML = '<div class="error-message" style="padding:20px;text-align:center;color:#dc2626;background:#fee2e2;border-radius:8px;">Fehler beim Laden der Anwesenheitsdaten</div>'; 
            return; 
        }
        
        const rows = json.rows || [];
        const counts = json.counts || {};
        
        if (rows.length === 0) { 
            body.innerHTML = '<div style="color:#666;padding:40px;text-align:center;"><div style="font-size:48px;margin-bottom:16px;">📊</div><div style="font-size:16px;color:#374151;margin-bottom:8px;">Keine Anwesenheitseinträge</div><div style="font-size:14px;color:#6b7280;">Noch keine Einträge vorhanden.</div></div>'; 
            return; 
        }
        
        let html = `
            <div style="padding:8px;">
                <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:24px;">
                    <div style="background:#f0fdf4;padding:16px;border-radius:8px;text-align:center;border:1px solid #d1fae5;">
                        <div style="font-size:24px;font-weight:700;color:#059669;">${counts.present || 0}</div>
                        <div style="font-size:12px;color:#047857;font-weight:600;margin-top:4px;">Anwesend</div>
                    </div>
                    <div style="background:#fef3c7;padding:16px;border-radius:8px;text-align:center;border:1px solid #fde68a;">
                        <div style="font-size:24px;font-weight:700;color:#d97706;">${counts.made_up || 0}</div>
                        <div style="font-size:12px;color:#b45309;font-weight:600;margin-top:4px;">Nachgeholt</div>
                    </div>
                    <div style="background:#fee2e2;padding:16px;border-radius:8px;text-align:center;border:1px solid #fecaca;">
                        <div style="font-size:24px;font-weight:700;color:#dc2626;">${counts.missed || 0}</div>
                        <div style="font-size:12px;color:#b91c1c;font-weight:600;margin-top:4px;">Fehltage</div>
                    </div>
                </div>
                
                <div style="font-weight:600;color:#374151;margin-bottom:12px;font-size:15px;">Alle Anwesenheitseinträge (${rows.length})</div>
                <div style="max-height:400px;overflow-y:auto;border-radius:8px;border:1px solid #e5e7eb;">
        `;
        
        rows.forEach((r, index) => {
            const dt = new Date(r.datum + 'T00:00:00').toLocaleDateString('de-DE');
            let status = 'Fehltag';
            let statusColor = '#ef4444';
            let bgColor = '#fef2f2';
            
            if (r.anwesend == 1) {
                status = 'Anwesend';
                statusColor = '#10b981';
                bgColor = '#f0fdf4';
            } else if (r.nachgeholt == 1) {
                status = 'Nachgeholt';
                statusColor = '#f59e0b';
                bgColor = '#fffbeb';
            }
            
            const isLast = index === rows.length - 1;
            
            html += `
                <div style="padding:16px;background:${bgColor};border-bottom:${isLast ? 'none' : '1px solid #e5e7eb'};cursor:pointer;" onclick="openAttendanceModal('${JSON.stringify(r).replace(/'/g, "\\'")}')">
                    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
                        <div style="font-weight:600;color:#1f2937;">${dt}</div>
                        <div style="padding:4px 12px;border-radius:12px;background:${statusColor}20;color:${statusColor};font-weight:600;font-size:12px;">
                            ${status}
                        </div>
                    </div>
                    ${r.unterrichtsstoff ? `
                        <div style="color:#4b5563;font-size:13px;margin-bottom:4px;line-height:1.4;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;">
                            ${r.unterrichtsstoff}
                        </div>
                    ` : ''}
                    ${r.entschuldigung ? `
                        <div style="color:#6b7280;font-size:12px;margin-top:4px;padding:4px 8px;background:white;border-radius:4px;border-left:2px solid #d1d5db;">
                            <strong>Entschuldigung:</strong> ${r.entschuldigung.substring(0, 60)}${r.entschuldigung.length > 60 ? '…' : ''}
                        </div>
                    ` : ''}
                </div>
            `;
        });
        
        html += `
                </div>
                
                <div style="margin-top:20px;padding-top:16px;border-top:1px solid #e5e7eb;display:flex;justify-content:space-between;align-items:center;">
                    <div style="font-size:13px;color:#6b7280;">
                        Klicken Sie auf einen Eintrag für Details
                    </div>
                    <div style="font-size:13px;color:#374151;font-weight:600;">
                        Gesamt: ${rows.length} Einträge
                    </div>
                </div>
            </div>
        `;
        body.innerHTML = html;
    } catch (e) {
        console.error(e);
        body.innerHTML = '<div class="error-message" style="padding:20px;text-align:center;color:#dc2626;background:#fee2e2;border-radius:8px;">Fehler beim Laden der Daten</div>';
    }
}

function closeAttendanceModal(){ 
    document.getElementById('attendanceModal').style.display='none'; 
}

// Nachgeholt Status umschalten
async function toggleNachgeholt(chk) {
    const id = chk.dataset.id;
    const val = chk.checked ? 1 : 0;
    const fd = new FormData();
    fd.append('action','toggle_anwesenheit');
    fd.append('id', id);
    fd.append('nachgeholt', val);
    
    try {
        const res = await fetch('Main.php',{method:'POST', body: fd, credentials: 'same-origin'});
        const json = await res.json();
        if (json.success) {
            // Erfolgsfeedback
            chk.parentNode.innerHTML = `<span style="color:#059669;font-weight:600;">✓ ${val ? 'Nachgeholt' : 'Nicht nachgeholt'}</span>`;
            setTimeout(() => {
                closeAttendanceModal();
            }, 800);
        } else {
            alert('❌ Fehler beim Aktualisieren');
            chk.checked = !chk.checked;
        }
    } catch (e) {
        console.error(e);
        alert('❌ Fehler beim Aktualisieren');
        chk.checked = !chk.checked;
    }
}
</script>

        <!-- Aktuelle Noten -->
        <div class="dashboard-card span-6">
            <div class="card-header">
                <h2>Letzte Noten</h2>
                <div class="card-count"><?php echo count($user_notes); ?></div>
            </div>
            <div class="card-content">
                <?php if (empty($user_notes)): ?>
                    <div class="empty-state">
                        <p>Noch keine Noten vorhanden</p>
                    </div>
                <?php else: 
                    foreach ($user_notes as $n): ?>
                        <div class="note-item">
                            <div class="note-info">
                                <div class="note-title"><?php echo h($n['titel'] ?: '—'); ?></div>
                                <div class="note-meta"><?php echo h($n['kurs_name'] ?: '—'); ?> • <?php echo (!empty($n['datum_erstellt'])? (new DateTime($n['datum_erstellt']))->format('d.m.Y') : ''); ?></div>
                            </div>
                            <div class="note-grade">
                                <div class="grade-badge" style="background: <?php echo gradeColor($n['note'] ?? 0); ?>;">
                                    <?php echo intval($n['note'] ?? 0); ?>
                                </div>
                                <div class="grade-text"><?php echo gradeToText($n['note'] ?? 0); ?></div>
                            </div>
                        </div>
                    <?php endforeach; 
                endif; ?>
                
                
            </div>
        </div>

        <!-- Nächste Termine -->
        <div class="dashboard-card span-6">
            <div class="card-header">
                <h2>Nächste Termine</h2>
                <div class="card-count"><?php echo count($upcoming_events); ?></div>
            </div>
            <div class="card-content">
                <?php if (empty($upcoming_events)): ?>
                    <div class="empty-state">
                        <p>Keine anstehenden Termine</p>
                    </div>
                <?php else: 
                    foreach($upcoming_events as $ev): ?>
                        <div class="event-item">
                            <div class="event-color" style="background: <?php echo h($ev['farb_code'] ?? '#8fbced'); ?>;"></div>
                            <div class="event-content">
                                <div class="event-title"><?php echo h($ev['titel']); ?></div>
                                <div class="event-meta"><?php echo h($ev['kurs_name']); ?> • <?php echo (!empty($ev['datum'])? (new DateTime($ev['datum']))->format('d.m.Y') : ''); ?></div>
                                <?php if (!empty($ev['notiz'])): ?>
                                    <div class="event-note"><?php echo short($ev['notiz'],80); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; 
                endif; ?>
                
                <?php if (!empty($upcoming_events)): ?>
                    <a href="Main.php?page=kalender" class="view-all">Alle Termine →</a>
                <?php endif; ?>
            </div>
        </div>

        <!-- Hausaufgaben -->
        <div class="dashboard-card span-8">
            <div class="card-header">
                <h2>Hausaufgaben</h2>
                <div class="card-count"><?php echo count($user_homeworks); ?></div>
            </div>
            <div class="card-content">
                <?php if (empty($user_homeworks)): ?>
                    <div class="empty-state">
                        <p>Keine Hausaufgaben</p>
                    </div>
                <?php else: 
                    foreach ($user_homeworks as $hw): 
                        $due = $hw['frist'] ?? null;
                        $kname = h($hw['kurs_name'] ?? 'Kurs');
                        $titel = h($hw['titel'] ?? 'Hausaufgabe');
                        $hasDue = !empty($due);
                        $isOverdue = $hasDue && (new DateTime($due) < new DateTime());
                ?>
                    <div class="homework-item" onclick="openHomeworkModal(<?php echo intval($hw['id']); ?>)">
                        <div class="homework-info">
                            <div class="homework-title"><?php echo $titel; ?></div>
                            <div class="homework-meta"><?php echo $kname; ?> • <?php echo $hasDue ? (new DateTime($due))->format('d.m.Y') : 'Kein Datum'; ?></div>
                            <?php if ($hw['beschreibung'] ?? false): ?>
                                <div class="homework-desc"><?php echo htmlspecialchars(mb_strimwidth($hw['beschreibung'], 0, 120, '…')); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="homework-icon">
                            <?php echo $isOverdue ? '⚠️' : '📋'; ?>
                        </div>
                    </div>
                <?php endforeach; 
                endif; ?>
                
            </div>
        </div>

        <!-- Meine Kurse -->
        <div class="dashboard-card span-4">
            <div class="card-header">
                <h2>Meine Kurse</h2>
                <div class="card-count"><?php echo count($user_courses); ?></div>
            </div>
            <div class="card-content">
                <?php if (empty($user_courses)): ?>
                    <div class="empty-state">
                        <p>Keine Kurse zugewiesen</p>
                    </div>
                <?php else: 
                    foreach($user_courses as $c): ?>
                        <a href="Main.php?page=KursOffen&course_id=<?php echo intval($c['id']); ?>" class="course-chip" style="margin-bottom: 8px; display: block; text-align: center;">
                            <?php echo h($c['name']); ?>
                        </a>
                        <?php if (!empty($c['info'])): ?>
                            <div style="font-size: 12px; color: var(--text-muted); text-align: center; margin-top: -4px; margin-bottom: 12px;">
                                <?php echo short($c['info'], 60); ?>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; 
                endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Attendance Modal -->
<div id="attendanceModal" class="cal-modal-overlay" style="display:none;" onclick="if(event.target===this) closeAttendanceModal()">
    <div class="cal-modal small" role="dialog" aria-modal="true" aria-labelledby="attendanceModalTitle">
        <div class="cal-modal-header">
            <h3 class="cal-modal-title" id="attendanceModalTitle">Anwesenheits-Details</h3>
            <button class="cal-modal-close" onclick="closeAttendanceModal()">×</button>
        </div>
        <div class="cal-modal-body" id="attendanceModalBody" style="padding:12px;">
            <!-- content wird per JS gefüllt -->
        </div>
        <div class="cal-modal-footer">
            <button class="cal-btn cal-btn-secondary" onclick="closeAttendanceModal()">Schließen</button>
        </div>
    </div>
</div>

<!-- Homework Modal -->
<div id="homeworkModal" class="cal-modal-overlay" style="display:none;" onclick="if(event.target===this) closeHomeworkModal()">
    <div class="cal-modal" role="dialog" aria-modal="true" aria-labelledby="hwModalTitle">
        <div class="cal-modal-header">
            <h3 class="cal-modal-title" id="hwModalTitle">Hausaufgabe</h3>
            <button class="cal-modal-close" onclick="closeHomeworkModal()">×</button>
        </div>
        <div class="cal-modal-body" id="homeworkModalBody" style="padding:14px;">
            <!-- content wird per JS gefüllt -->
        </div>
        <div class="cal-modal-footer">
            <button class="cal-btn cal-btn-secondary" onclick="closeHomeworkModal()">Schließen</button>
        </div>
    </div>
</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
const courses = <?php echo json_encode($user_courses, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP); ?>;
const notes = <?php echo json_encode($user_notes, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP); ?>;

// Build per-course average
const courseMap = {};
courses.forEach(c => courseMap[c.id] = c);
const courseAverages = {};
const courseCounts = {};

// Calculate averages per course
notes.forEach(n => {
    const courseId = n.kurs_id || n.kurs_name;
    if (!courseAverages[courseId]) {
        courseAverages[courseId] = {
            sum: 0,
            count: 0,
            name: n.kurs_name || 'Unbekannt',
            color: n.farb_code || '#8fbced'
        };
    }
    courseAverages[courseId].sum += parseFloat(n.note) || 0;
    courseAverages[courseId].count += 1;
});

// Prepare chart data
const chartLabels = [];
const chartData = [];
const chartColors = [];
const chartBackgrounds = [];

Object.keys(courseAverages).forEach(courseId => {
    const course = courseAverages[courseId];
    if (course.count > 0) {
        const average = course.sum / course.count;
        chartLabels.push(course.name);
        chartData.push(average.toFixed(1));
        chartColors.push(course.color);
        
        // Create lighter background color
        const hex = course.color.replace('#', '');
        const r = parseInt(hex.substr(0, 2), 16);
        const g = parseInt(hex.substr(2, 2), 16);
        const b = parseInt(hex.substr(4, 2), 16);
        chartBackgrounds.push(`rgba(${r}, ${g}, ${b}, 0.2)`);
    }
});

// Create chart if we have data
if (chartData.length > 0) {
    const ctx = document.getElementById('gradesChart').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: chartLabels,
            datasets: [{
                label: 'Durchschnittsnote',
                data: chartData,
                backgroundColor: chartBackgrounds,
                borderColor: chartColors,
                borderWidth: 1,
                borderRadius: 6,
                barThickness: 30
            }]
        },
        options: {
            maintainAspectRatio: false,
            responsive: true,
            scales: {
                y: {
                    reverse: true,
                    beginAtZero: false,
                    min: 1,
                    max: 6,
                    ticks: {
                        stepSize: 1,
                        callback: function(value) {
                            return value;
                        }
                    },
                    grid: {
                        color: 'rgba(0, 0, 0, 0.05)'
                    }
                },
                x: {
                    grid: {
                        display: false
                    },
                    ticks: {
                        maxRotation: 45,
                        minRotation: 45
                    }
                }
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `Ø ${context.parsed.y}`;
                        }
                    }
                },
                legend: {
                    display: false
                }
            }
        }
    });
}

// Attendance Functions
async function openAttendanceModal(elOrNull) {
    const modal = document.getElementById('attendanceModal');
    const body = document.getElementById('attendanceModalBody');
    body.innerHTML = '<div style="padding:12px;color:#666;">Lade…</div>';
    modal.style.display = 'flex';
    
    if (!elOrNull) {
        try {
            const fd = new FormData();
            fd.append('action','get_user_anwesenheit');
            fd.append('user_id', <?php echo intval($user_id); ?>);
            const res = await fetch('Main.php',{method:'POST', body: fd, credentials: 'same-origin'});
            const json = await res.json();
            
            if (!json.success) { 
                body.innerHTML = '<div class="error-message">Fehler beim Laden</div>'; 
                return; 
            }
            
            const rows = json.rows || [];
            if (rows.length === 0) { 
                body.innerHTML = '<div style="color:#666;">Keine Einträge</div>'; 
                return; 
            }
            
            let html = '<div style="max-height:400px;overflow-y:auto;">';
            rows.forEach(r => {
                const dt = new Date(r.datum + 'T00:00:00').toLocaleDateString('de-DE');
                let status = 'Fehltag';
                let statusColor = '#ef4444';
                
                if (r.anwesend == 1) {
                    status = 'Anwesend';
                    statusColor = '#10b981';
                } else if (r.nachgeholt == 1) {
                    status = 'Nachgeholt';
                    statusColor = '#f59e0b';
                }
                
                html += `
                    <div style="padding:12px;border-bottom:1px solid #f3f4f6;">
                        <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:8px;">
                            <div>
                                <strong>${dt}</strong>
                                <span style="margin-left:8px;padding:2px 8px;border-radius:12px;background:${statusColor}20;color:${statusColor};font-size:12px;font-weight:600;">
                                    ${status}
                                </span>
                            </div>
                            ${r.uhrzeit_start ? `<div style="font-size:12px;color:#6b7280;">${r.uhrzeit_start}${r.uhrzeit_end ? ` - ${r.uhrzeit_end}` : ''}</div>` : ''}
                        </div>
                        ${r.unterrichtsstoff ? `<div style="color:#374151;margin-bottom:8px;">${r.unterrichtsstoff}</div>` : ''}
                        ${r.entschuldigung ? `<div style="color:#6b7280;font-size:12px;background:#f9fafb;padding:8px;border-radius:6px;border-left:3px solid #d1d5db;">
                            <strong>Entschuldigung:</strong> ${r.entschuldigung}
                        </div>` : ''}
                    </div>
                `;
            });
            html += '</div>';
            body.innerHTML = html;
        } catch (e) {
            console.error(e);
            body.innerHTML = '<div class="error-message">Fehler beim Laden der Daten</div>';
        }
    } else {
        const entry = JSON.parse(elOrNull.dataset.entry);
        const dt = new Date(entry.datum + 'T00:00:00').toLocaleDateString('de-DE');
        let status = 'Fehltag';
        let statusColor = '#ef4444';
        
        if (entry.anwesend == 1) {
            status = 'Anwesend';
            statusColor = '#10b981';
        } else if (entry.nachgeholt == 1) {
            status = 'Nachgeholt';
            statusColor = '#f59e0b';
        }
        
        body.innerHTML = `
            <div style="padding:8px;">
                <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
                    <div style="font-weight:700;font-size:18px;">${dt}</div>
                    <div style="padding:4px 12px;border-radius:12px;background:${statusColor}20;color:${statusColor};font-weight:600;">
                        ${status}
                    </div>
                </div>
                ${entry.unterrichtsstoff ? `
                    <div style="margin-bottom:16px;">
                        <div style="font-weight:600;color:#4b5563;margin-bottom:4px;">Unterrichtsstoff:</div>
                        <div style="color:#374151;background:#f9fafb;padding:12px;border-radius:8px;">${entry.unterrichtsstoff}</div>
                    </div>
                ` : ''}
                ${entry.entschuldigung ? `
                    <div style="margin-bottom:16px;">
                        <div style="font-weight:600;color:#4b5563;margin-bottom:4px;">Entschuldigung:</div>
                        <div style="color:#374151;background:#f9fafb;padding:12px;border-radius:8px;">${entry.entschuldigung}</div>
                    </div>
                ` : ''}
            </div>
        `;
    }
}

function closeAttendanceModal(){ 
    document.getElementById('attendanceModal').style.display='none'; 
}

// Homework Modal Functions
async function openHomeworkModal(hwId) {
    const modal = document.getElementById('homeworkModal');
    const body = document.getElementById('homeworkModalBody');
    body.innerHTML = '<div style="padding:12px;color:#666;">Lade Hausaufgabe…</div>';
    modal.style.display = 'flex';

    const fd = new FormData();
    fd.append('action', 'get_homework_details');
    fd.append('homework_id', hwId);

    try {
        const res = await fetch('Main.php', { method: 'POST', body: fd, credentials: 'same-origin' });
        const json = await res.json();
        
        if (!json.success) {
            body.innerHTML = '<div class="error-message">Fehler beim Laden</div>';
            return;
        }

        const hw = json.homework || {};
        const answers = json.answers || [];
        let html = `
            <div style="margin-bottom:16px;">
                <div style="font-size:18px; font-weight:700; margin-bottom:8px;">${(hw.titel||'').substring(0,100)}</div>
                <div style="display:flex; gap:12px; align-items:center; color:#6b7280; font-size:14px;">
                    <span style="display:inline-flex;align-items:center;gap:4px;">
                        📚 ${hw.kurs_name||'Kurs'}
                    </span>
                    <span>•</span>
                    <span style="display:inline-flex;align-items:center;gap:4px;">
                        📅 ${hw.frist ? new Date(hw.frist + 'T00:00:00').toLocaleDateString('de-DE') : 'Kein Datum'}
                    </span>
                </div>
            </div>

            ${hw.beschreibung ? `
                <div style="padding:16px; background:#f9fafb; border-radius:8px; margin-bottom:16px; border-left:4px solid #1967d2;">
                    <div style="font-weight:600; color:#374151; margin-bottom:8px;">Beschreibung:</div>
                    <div style="color:#4b5563; line-height:1.6;">${hw.beschreibung}</div>
                </div>
            ` : ''}

            ${hw.datei_name ? `
                <div style="padding:12px; background:#f3f4f6; border-radius:8px; margin-bottom:16px;">
                    <div style="font-weight:600; color:#374151; margin-bottom:8px;">Anhang:</div>
                    <a href="Main.php?action=download_homework_file&file_id=${hw.id}" 
                       style="display:flex; align-items:center; gap:8px; color:#1967d2; text-decoration:none; font-weight:600;">
                        📎 ${hw.datei_name} (${formatFileSize(hw.datei_groesse||0)})
                    </a>
                </div>
            ` : ''}

            <div style="margin-top:24px;">
                <div style="font-weight:700; margin-bottom:12px; color:#374151;">Deine Antwort(en)</div>
                ${answers.length === 0 ? 
                    `<div style="color:#9ca3af; padding:16px; text-align:center; background:#f9fafb; border-radius:8px; border:2px dashed #e5e7eb;">
                        Noch keine Antwort hochgeladen
                    </div>` :
                    answers.map(a => `
                        <div style="padding:16px; background:#f0fdf4; border-radius:8px; margin-bottom:12px; border-left:4px solid #10b981;">
                            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
                                <div style="font-size:12px; color:#059669; font-weight:600;">Hochgeladen: ${new Date(a.erstellt_am).toLocaleDateString('de-DE')}</div>
                                <div style="font-size:12px; color:#6b7280;">${new Date(a.erstellt_am).toLocaleTimeString('de-DE', {hour: '2-digit', minute:'2-digit'})}</div>
                            </div>
                            ${a.text ? `<div style="color:#374151; line-height:1.6; margin-top:8px;">${a.text}</div>` : ''}
                            ${a.datei_name ? `
                                <div style="margin-top:12px;">
                                    <a href="Main.php?action=download_answer_file&file_id=${a.id}" 
                                       style="display:inline-flex; align-items:center; gap:6px; color:#059669; text-decoration:none; font-weight:600; padding:8px 12px; background:#d1fae5; border-radius:6px;">
                                        📎 ${a.datei_name}
                                    </a>
                                </div>
                            ` : ''}
                        </div>
                    `).join('')
                }
            </div>

            <div style="margin-top:24px; padding-top:16px; border-top:2px solid #e5e7eb;">
                <button class="cal-btn cal-btn-primary" onclick="openAnswerForm(${hwId})" style="width:100%; justify-content:center;">
                    📤 Antwort hochladen
                </button>
            </div>
        `;
        body.innerHTML = html;
    } catch (e) {
        console.error('openHomeworkModal error', e);
        body.innerHTML = '<div class="error-message">Fehler beim Laden der Hausaufgabe</div>';
    }
}

function closeHomeworkModal() {
    document.getElementById('homeworkModal').style.display = 'none';
}

function formatFileSize(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
}

async function openAnswerForm(hwId) {
    const container = document.getElementById('homeworkModalBody');
    const form = document.createElement('form');
    form.style.cssText = 'margin-top:16px; padding-top:16px; border-top:2px solid #e5e7eb;';
    form.innerHTML = `
        <div style="margin-bottom:16px;">
            <label style="display:block; font-weight:600; color:#374151; margin-bottom:8px;">Deine Antwort</label>
            <textarea id="answerText" style="width:100%; padding:12px; border:2px solid #e5e7eb; border-radius:8px; font-size:14px; min-height:100px; resize:vertical;" 
                      placeholder="Schreibe deine Antwort hier…"></textarea>
        </div>
        <div style="margin-bottom:16px;">
            <label style="display:block; font-weight:600; color:#374151; margin-bottom:8px;">Datei hochladen</label>
            <input type="file" id="answerFile" style="display:block; margin-bottom:8px; padding:8px; border:2px dashed #d1d5db; border-radius:8px; width:100%;">
            <div style="font-size:12px; color:#6b7280;">Max. 50 MB • Unterstützte Formate: PDF, Word, Bilder, etc.</div>
        </div>
        <div style="display:flex; gap:8px;">
            <button type="button" class="cal-btn cal-btn-primary" onclick="submitAnswer(${hwId})" style="flex:1;">
                📤 Hochladen
            </button>
            <button type="button" class="cal-btn cal-btn-secondary" onclick="openHomeworkModal(${hwId})" style="flex:1;">
                Abbrechen
            </button>
        </div>
    `;
    const oldForm = container.querySelector('form');
    if (oldForm) oldForm.remove();
    container.appendChild(form);
}

async function submitAnswer(hwId) {
    const text = (document.getElementById('answerText') || {}).value || '';
    const fileInput = document.getElementById('answerFile');
    const file = fileInput && fileInput.files && fileInput.files[0] ? fileInput.files[0] : null;

    if (!text.trim() && !file) {
        alert('Bitte schreibe eine Antwort oder lade eine Datei hoch');
        return;
    }

    if (file && file.size > 50 * 1024 * 1024) {
        alert('Datei ist zu groß (max. 50 MB)');
        return;
    }

    const fd = new FormData();
    fd.append('action', 'submit_homework_answer');
    fd.append('homework_id', hwId);
    fd.append('text', text.trim());
    if (file) fd.append('datei', file, file.name);

    try {
        const res = await fetch('Main.php', { method: 'POST', body: fd, credentials: 'same-origin' });
        const json = await res.json();

        if (json.success) {
            alert('✅ Antwort erfolgreich hochgeladen!');
            await openHomeworkModal(hwId);
        } else {
            alert('❌ Fehler: ' + (json.error || 'Unbekannter Fehler'));
        }
    } catch (e) {
        console.error('submitAnswer error', e);
        alert('❌ Fehler beim Hochladen');
    }
}

// Toggle attendance nachgeholt status
async function toggleNachgeholt(chk) {
    const id = chk.dataset.id;
    const val = chk.checked ? 1 : 0;
    const fd = new FormData();
    fd.append('action','toggle_anwesenheit');
    fd.append('id', id);
    fd.append('nachgeholt', val ? 1 : 0);
    
    try {
        const res = await fetch('Main.php',{method:'POST', body: fd, credentials: 'same-origin'});
        const json = await res.json();
        if (json.success) {
            // Optional: Update UI immediately
        } else {
            alert('Fehler beim Aktualisieren');
            chk.checked = !chk.checked;
        }
    } catch (e) {
        console.error(e);
        alert('Fehler beim Aktualisieren');
        chk.checked = !chk.checked;
    }
}
</script>