<?php
// Kurse des Users laden für Dropdown

/*
calRenderDayView
*/
$user_courses_for_dropdown = [];
try {
    if (hasRole('admin')) {
        $stmt = $pdo->query("SELECT id, name, farb_code FROM kurse ORDER BY name");
        $user_courses_for_dropdown = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        $courses_str = $user['courses'] ?? '';
        $course_names = array_filter(array_map('trim', explode(',', $courses_str)));
        if (!empty($course_names)) {
            $placeholders = str_repeat('?,', count($course_names) - 1) . '?';
            $stmt = $pdo->prepare("SELECT id, name, farb_code FROM kurse WHERE name IN ($placeholders) ORDER BY name");
            $stmt->execute($course_names);
            $user_courses_for_dropdown = $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
    }
} catch (PDOException $e) {
    error_log("Error loading courses: " . $e->getMessage());
}
?>
<style>
    .cal-container {
        width: 100%;
        height: calc(100vh - 100px);
        display: flex;
        flex-direction: column;
    }

    .cal-header {
        display: flex;
        align-items: center;
        padding: 12px 20px;
        border-bottom: 1px solid #dadce0;
        gap: 20px;
        background: white;
    }

    .cal-header-left {
        display: flex;
        align-items: center;
        gap: 12px;
    }

    .cal-today-btn, .cal-add-event-btn {
        padding: 8px 16px;
        border: 1px solid #dadce0;
        border-radius: 4px;
        background: white;
        cursor: pointer;
        font-size: 14px;
        transition: background 0.2s;
    }

    .cal-add-event-btn {
        background: #1967d2;
        color: white;
        border-color: #1967d2;
    }

    .cal-add-event-btn:hover {
        background: #1557b0;
    }

    .cal-today-btn:hover {
        background: #f1f3f4;
    }

    .cal-nav-arrows {
        display: flex;
        gap: 4px;
    }

    .cal-nav-arrow {
        width: 36px;
        height: 36px;
        border: none;
        background: white;
        cursor: pointer;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: background 0.2s;
        font-size: 20px;
    }

    .cal-nav-arrow:hover {
        background: #f1f3f4;
    }

    .cal-current-period {
        font-size: 22px;
        font-weight: 400;
        color: #3c4043;
        min-width: 200px;
    }

    .cal-view-switcher {
        margin-left: auto;
        display: flex;
        border: 1px solid #dadce0;
        border-radius: 4px;
        overflow: hidden;
    }

    .cal-view-btn {
        padding: 8px 16px;
        border: none;
        background: white;
        cursor: pointer;
        font-size: 14px;
        border-right: 1px solid #dadce0;
        transition: background 0.2s;
    }

    .cal-view-btn:last-child {
        border-right: none;
    }

    .cal-view-btn:hover {
        background: #f1f3f4;
    }

    .cal-view-btn.active {
        background: #e8f0fe;
        color: #1967d2;
        font-weight: 500;
    }

    .cal-main-container {
        display: flex;
        flex: 1;
        overflow: hidden;
    }

    .cal-sidebar {
        width: 280px;
        border-right: 1px solid #dadce0;
        padding: 20px 12px;
        overflow-y: auto;
        background: white;
    }

    .cal-mini-calendar {
        background: white;
        border-radius: 8px;
        padding: 12px;
        margin-bottom: 24px;
        border: 1px solid #dadce0;
    }

    .cal-mini-calendar-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 12px;
    }

    .cal-mini-calendar-month {
        font-size: 14px;
        font-weight: 500;
    }

    .cal-mini-nav {
        display: flex;
        gap: 4px;
    }

    .cal-mini-nav-btn {
        width: 24px;
        height: 24px;
        border: none;
        background: none;
        cursor: pointer;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 16px;
    }

    .cal-mini-nav-btn:hover {
        background: #f1f3f4;
    }

    .cal-mini-calendar-grid {
        display: grid;
        grid-template-columns: repeat(7, 1fr);
        gap: 4px;
    }

    .cal-mini-day-label {
        text-align: center;
        font-size: 11px;
        color: #70757a;
        padding: 4px 0;
    }

    .cal-mini-day {
        aspect-ratio: 1;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 12px;
        border-radius: 50%;
        cursor: pointer;
        position: relative;
    }

    .cal-mini-day:hover {
        background: #f1f3f4;
    }

    .cal-mini-day.other-month {
        color: #dadce0;
    }

    .cal-mini-day.today {
        background: #1967d2;
        color: white;
        font-weight: 500;
    }

    .cal-mini-day.has-events::after {
        content: '';
        position: absolute;
        bottom: 2px;
        width: 4px;
        height: 4px;
        border-radius: 50%;
        background: #1967d2;
    }

    .cal-mini-day.today.has-events::after {
        background: white;
    }

    .cal-today-events {
        background: white;
        border-radius: 8px;
        padding: 16px;
        border: 1px solid #dadce0;
        max-height: 400px;
        overflow-y: auto;
    }

    .cal-today-events-title {
        font-size: 14px;
        font-weight: 500;
        margin-bottom: 12px;
        color: #3c4043;
    }

    .cal-event-item {
        padding: 8px;
        margin-bottom: 8px;
        border-radius: 6px;
        border-left: 4px solid;
        background: #f8f9fa;
        cursor: pointer;
        transition: background 0.2s;
    }

    .cal-event-item:hover {
        background: #e8eaed;
    }

    .cal-event-title {
        font-size: 13px;
        font-weight: 500;
        margin-bottom: 2px;
    }

    .cal-event-time {
        font-size: 12px;
        color: #70757a;
    }

    .cal-calendar-main {
        flex: 1;
        overflow: auto;
        padding: 20px;
        background: #f5f7fa;
    }

    /* Month View */
    .cal-month-view {
        display: grid;
        grid-template-columns: repeat(7, 1fr);
        gap: 1px;
        background: #dadce0;
        border: 1px solid #dadce0;
        height: calc(100vh - 200px);
    }

    .cal-day-header {
        background: #f8f9fa;
        padding: 12px;
        text-align: center;
        font-size: 12px;
        font-weight: 500;
        color: #70757a;
    }

    .cal-day-cell {
        background: white;
        padding: 8px;
        min-height: 100px;
        position: relative;
        cursor: pointer;
        overflow: hidden;
    }

    .cal-day-cell:hover {
        background: #f8f9fa;
    }

    .cal-day-cell.other-month {
        background: #fafafa;
    }

    .cal-day-cell.today {
        background: #e8f0fe;
    }

    .cal-day-number {
        font-size: 14px;
        color: #3c4043;
        margin-bottom: 4px;
    }

    .cal-day-cell.today .cal-day-number {
        background: #1967d2;
        color: white;
        width: 26px;
        height: 26px;
        border-radius: 50%;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-weight: 500;
        font-size: 13px;
    }

    .cal-event-dot {
        width: 100%;
        padding: 2px 4px;
        margin-bottom: 2px;
        border-radius: 3px;
        font-size: 11px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        border-left: 3px solid;
        background: rgba(255, 255, 255, 0.9);
    }

    /* Event Modal */
    .cal-modal-overlay {
        position: fixed;
        inset: 0;
        background: rgba(0, 0, 0, 0.5);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 10000;
        padding: 20px;
    }

    .cal-modal {
        background: white;
        border-radius: 12px;
        max-width: 500px;
        width: 100%;
        max-height: 90vh;
        overflow-y: auto;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
    }

    .cal-modal-header {
        padding: 20px 24px;
        border-bottom: 1px solid #dadce0;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .cal-modal-title {
        font-size: 20px;
        font-weight: 500;
        color: #3c4043;
    }

    .cal-modal-close {
        width: 32px;
        height: 32px;
        border: none;
        background: none;
        cursor: pointer;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 24px;
        color: #70757a;
    }

    .cal-modal-close:hover {
        background: #f1f3f4;
    }

    .cal-modal-body {
        padding: 24px;
    }

    .cal-form-group {
        margin-bottom: 20px;
    }

    .cal-form-label {
        display: block;
        font-size: 14px;
        font-weight: 500;
        color: #3c4043;
        margin-bottom: 8px;
    }

    .cal-form-input, .cal-form-select, .cal-form-textarea {
        width: 100%;
        padding: 10px 12px;
        border: 1px solid #dadce0;
        border-radius: 6px;
        font-size: 14px;
        font-family: inherit;
        transition: border-color 0.2s;
    }

    .cal-form-input:focus, .cal-form-select:focus, .cal-form-textarea:focus {
        outline: none;
        border-color: #1967d2;
        box-shadow: 0 0 0 3px rgba(25, 103, 210, 0.1);
    }

    .cal-form-textarea {
        resize: vertical;
        min-height: 80px;
    }

    .cal-form-checkbox {
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .cal-form-checkbox input {
        width: 18px;
        height: 18px;
        cursor: pointer;
    }

    .cal-weekday-selector {
        display: grid;
        grid-template-columns: repeat(7, 1fr);
        gap: 8px;
        margin-top: 8px;
    }

    .cal-weekday-btn {
        padding: 8px;
        border: 1px solid #dadce0;
        border-radius: 6px;
        background: white;
        cursor: pointer;
        font-size: 12px;
        text-align: center;
        transition: all 0.2s;
    }

    .cal-weekday-btn:hover {
        background: #f1f3f4;
    }

    .cal-weekday-btn.active {
        background: #1967d2;
        color: white;
        border-color: #1967d2;
    }

    .cal-recurring-options {
        padding: 16px;
        background: #f8f9fa;
        border-radius: 8px;
        margin-top: 12px;
    }

    .cal-modal-footer {
        padding: 16px 24px;
        border-top: 1px solid #dadce0;
        display: flex;
        justify-content: flex-end;
        gap: 12px;
    }

    .cal-btn {
        padding: 10px 20px;
        border: none;
        border-radius: 6px;
        font-size: 14px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.2s;
    }

    .cal-btn-primary {
        background: #1967d2;
        color: white;
    }

    .cal-btn-primary:hover {
        background: #1557b0;
    }

    .cal-btn-secondary {
        background: white;
        color: #3c4043;
        border: 1px solid #dadce0;
    }

    .cal-btn-secondary:hover {
        background: #f1f3f4;
    }

    .cal-btn-danger {
        background: #d93025;
        color: white;
    }

    .cal-btn-danger:hover {
        background: #b31412;
    }

    .cal-event-details {
        padding: 24px;
    }

    .cal-event-detail-row {
        display: flex;
        align-items: flex-start;
        gap: 12px;
        margin-bottom: 16px;
    }

    .cal-event-detail-icon {
        width: 24px;
        height: 24px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #70757a;
    }

    .cal-event-detail-content {
        flex: 1;
    }

    .cal-event-detail-label {
        font-size: 12px;
        color: #70757a;
        margin-bottom: 4px;
    }

    .cal-event-detail-value {
        font-size: 14px;
        color: #3c4043;
    }

    @media (max-width: 768px) {
        .cal-sidebar {
            display: none;
        }

        .cal-header {
            flex-wrap: wrap;
        }

        .cal-view-switcher {
            order: 3;
            width: 100%;
            margin-top: 12px;
        }

        .cal-view-btn {
            flex: 1;
        }

        .cal-modal {
            max-width: 100%;
            border-radius: 0;
        }
    }
</style>

<div class="cal-container">
    <div class="cal-header">
        <div class="cal-header-left">
            <button class="cal-today-btn" onclick="calGoToToday()">Heute</button>
            <button class="cal-add-event-btn" onclick="calOpenEventModal()">Termin</button>
            <div class="cal-nav-arrows">
                <button class="cal-nav-arrow" onclick="calNavigatePrev()">‹</button>
                <button class="cal-nav-arrow" onclick="calNavigateNext()">›</button>
            </div>
            <div class="cal-current-period" id="calCurrentPeriod"></div>
        </div>
        <div class="cal-view-switcher">
            <button class="cal-view-btn active" onclick="calSwitchView('month', this)">Monat</button>
            <button class="cal-view-btn" onclick="calSwitchView('week', this)">Woche</button>
            <button class="cal-view-btn" onclick="calSwitchView('day', this)">Tag</button>
            <button class="cal-view-btn" onclick="calSwitchView('year', this)">Jahr</button>
        </div>
    </div>

    <div class="cal-main-container">
        <div class="cal-sidebar">
            <div class="cal-mini-calendar">
                <div class="cal-mini-calendar-header">
                    <span class="cal-mini-calendar-month" id="calMiniCalendarMonth"></span>
                    <div class="cal-mini-nav">
                        <button class="cal-mini-nav-btn" onclick="calMiniCalendarPrev()">‹</button>
                        <button class="cal-mini-nav-btn" onclick="calMiniCalendarNext()">›</button>
                    </div>
                </div>
                <div class="cal-mini-calendar-grid" id="calMiniCalendarGrid"></div>
            </div>
            <div class="cal-today-events">
                <div class="cal-today-events-title">Heutige Termine</div>
                <div id="calTodayEventsList"></div>
            </div>
        </div>

        <div class="cal-calendar-main" id="calCalendarMain"></div>
    </div>
</div>

<!-- Event Modal -->
<div id="calEventModal" class="cal-modal-overlay" style="display: none;">
    <div class="cal-modal">
        <div class="cal-modal-header">
            <h2 class="cal-modal-title" id="calModalTitle">Neuer Termin</h2>
            <button class="cal-modal-close" onclick="calCloseEventModal()">×</button>
        </div>
        <div class="cal-modal-body">
            <form id="calEventForm">
                <div class="cal-form-group">
                    <label class="cal-form-label">Titel *</label>
                    <input type="text" class="cal-form-input" id="calEventTitle" required>
                </div>

                <div class="cal-form-group">
                    <label class="cal-form-label">Kurs *</label>
                    <select class="cal-form-select" id="calEventCourse" required>
                        <option value="">-- Kurs auswählen --</option>
                        <?php foreach ($user_courses_for_dropdown as $course): ?>
                            <option value="<?php echo intval($course['id']); ?>" 
                                    data-color="<?php echo htmlspecialchars($course['farb_code'] ?? '#8fbced'); ?>">
                                <?php echo htmlspecialchars($course['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="cal-form-group">
                    <label class="cal-form-label">Datum *</label>
                    <input type="date" class="cal-form-input" id="calEventDate" required>
                </div>

                <div class="cal-form-group">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                        <div>
                            <label class="cal-form-label">Startzeit</label>
                            <input type="time" class="cal-form-input" id="calEventStartTime">
                        </div>
                        <div>
                            <label class="cal-form-label">Endzeit</label>
                            <input type="time" class="cal-form-input" id="calEventEndTime">
                        </div>
                    </div>
                </div>

                <div class="cal-form-group">
                    <label class="cal-form-checkbox">
                        <input type="checkbox" id="calEventRecurring" onchange="calToggleRecurring()">
                        <span>Wiederkehrender Termin</span>
                    </label>
                </div>

                <div id="calRecurringOptions" class="cal-recurring-options" style="display: none;">
                    <div class="cal-form-group">
                        <label class="cal-form-label">Wiederholung</label>
                        <select class="cal-form-select" id="calRecurringType" onchange="calUpdateRecurringUI()">
                            <option value="taeglich">Täglich</option>
                            <option value="woechentlich">Wöchentlich</option>
                            <option value="monatlich">Monatlich</option>
                        </select>
                    </div>

                    <div class="cal-form-group" id="calWeekdaySelector" style="display: none;">
                        <label class="cal-form-label">Wochentage</label>
                        <div class="cal-weekday-selector">
                            <button type="button" class="cal-weekday-btn" data-day="1" onclick="calToggleWeekday(1)">Mo</button>
                            <button type="button" class="cal-weekday-btn" data-day="2" onclick="calToggleWeekday(2)">Di</button>
                            <button type="button" class="cal-weekday-btn" data-day="3" onclick="calToggleWeekday(3)">Mi</button>
                            <button type="button" class="cal-weekday-btn" data-day="4" onclick="calToggleWeekday(4)">Do</button>
                            <button type="button" class="cal-weekday-btn" data-day="5" onclick="calToggleWeekday(5)">Fr</button>
                            <button type="button" class="cal-weekday-btn" data-day="6" onclick="calToggleWeekday(6)">Sa</button>
                            <button type="button" class="cal-weekday-btn" data-day="7" onclick="calToggleWeekday(7)">So</button>
                        </div>
                    </div>

                    <div class="cal-form-group">
                        <label class="cal-form-label">Endet am</label>
                        <input type="date" class="cal-form-input" id="calRecurringUntil">
                    </div>
                </div>

                <div class="cal-form-group">
                    <label class="cal-form-label">Notiz</label>
                    <textarea class="cal-form-textarea" id="calEventNote"></textarea>
                </div>
            </form>
        </div>
        <div class="cal-modal-footer">
            <button class="cal-btn cal-btn-secondary" onclick="calCloseEventModal()">Abbrechen</button>
            <button class="cal-btn cal-btn-primary" onclick="calSaveEvent()">Speichern</button>
        </div>
    </div>
</div>

<!-- Event Details Modal -->
<div id="calEventDetailsModal" class="cal-modal-overlay" style="display: none;">
    <div class="cal-modal">
        <div class="cal-modal-header">
            <h2 class="cal-modal-title" id="calDetailsTitle">Termindetails</h2>
            <button class="cal-modal-close" onclick="calCloseDetailsModal()">×</button>
        </div>
        <div class="cal-event-details">
            <div class="cal-event-detail-row">
                <div class="cal-event-detail-icon">📅</div>
                <div class="cal-event-detail-content">
                    <div class="cal-event-detail-label">Datum</div>
                    <div class="cal-event-detail-value" id="calDetailsDate"></div>
                </div>
            </div>
            <div class="cal-event-detail-row" id="calDetailsTimeRow" style="display: none;">
                <div class="cal-event-detail-icon">🕐</div>
                <div class="cal-event-detail-content">
                    <div class="cal-event-detail-label">Uhrzeit</div>
                    <div class="cal-event-detail-value" id="calDetailsTime"></div>
                </div>
            </div>
            <div class="cal-event-detail-row">
                <div class="cal-event-detail-icon">📚</div>
                <div class="cal-event-detail-content">
                    <div class="cal-event-detail-label">Kurs</div>
                    <div class="cal-event-detail-value" id="calDetailsCourse"></div>
                </div>
            </div>
            <div class="cal-event-detail-row" id="calDetailsNoteRow" style="display: none;">
                <div class="cal-event-detail-icon">📝</div>
                <div class="cal-event-detail-content">
                    <div class="cal-event-detail-label">Notiz</div>
                    <div class="cal-event-detail-value" id="calDetailsNote"></div>
                </div>
            </div>
            <div class="cal-event-detail-row" id="calDetailsRecurringRow" style="display: none;">
                <div class="cal-event-detail-icon">🔄</div>
                <div class="cal-event-detail-content">
                    <div class="cal-event-detail-label">Wiederholung</div>
                    <div class="cal-event-detail-value" id="calDetailsRecurring"></div>
                </div>
            </div>
        </div>
        <div class="cal-modal-footer">
            <button class="cal-btn cal-btn-danger" onclick="calDeleteEvent()" id="calDeleteBtn">Löschen</button>
            <button class="cal-btn cal-btn-secondary" onclick="calCloseDetailsModal()">Schließen</button>
        </div>
    </div>
</div>

<script>
    let calCurrentDate = new Date();
    let calCurrentView = 'month';
    let calMiniCalendarDate = new Date();
    let calAllEvents = [];
    let calSelectedWeekdays = [];
    let calCurrentEventId = null;

    const calMonthNames = ['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 
                       'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'];
    const calDayNames = ['So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa'];

    function calSwitchView(view) {
        // optional second param: element (this) — fallback: try to find button by text
        let el = arguments[1] || null;
        calCurrentView = view;
        document.querySelectorAll('.cal-view-btn').forEach(btn => btn.classList.remove('active'));
        if (el) el.classList.add('active'); else {
            document.querySelectorAll('.cal-view-btn').forEach(btn => {
                if (btn.textContent.trim().toLowerCase() === view) btn.classList.add('active');
            });
        }
        // Lade Events passend zur neuen Ansicht (calLoadEvents rendert die Ansicht nach dem Laden)
        calLoadEvents();
    }
    
    function calGoToToday() {
        calCurrentDate = new Date();
        calMiniCalendarDate = new Date();
        calRenderCalendar();
        calRenderMiniCalendar();
        calLoadEvents();
    }

    function calNavigatePrev() {
        if (calCurrentView === 'week') {
            calCurrentDate.setDate(calCurrentDate.getDate() - 7);
        } else if (calCurrentView === 'day') {
            calCurrentDate.setDate(calCurrentDate.getDate() - 1);
        } else if (calCurrentView === 'year') {
            calCurrentDate.setFullYear(calCurrentDate.getFullYear() - 1);
        } else { // month
            calCurrentDate.setMonth(calCurrentDate.getMonth() - 1);
        }
        calLoadEvents();
    }

    function calNavigateNext() {
        if (calCurrentView === 'week') {
            calCurrentDate.setDate(calCurrentDate.getDate() + 7);
        } else if (calCurrentView === 'day') {
            calCurrentDate.setDate(calCurrentDate.getDate() + 1);
        } else if (calCurrentView === 'year') {
            calCurrentDate.setFullYear(calCurrentDate.getFullYear() + 1);
        } else { // month
            calCurrentDate.setMonth(calCurrentDate.getMonth() + 1);
        }
        calLoadEvents();
    }

    function calMiniCalendarPrev() {
        calMiniCalendarDate.setMonth(calMiniCalendarDate.getMonth() - 1);
        calRenderMiniCalendar();
    }

    function calMiniCalendarNext() {
        calMiniCalendarDate.setMonth(calMiniCalendarDate.getMonth() + 1);
        calRenderMiniCalendar();
    }

    async function calOpenEventModal(date = null) {
        document.getElementById('calEventModal').style.display = 'flex';
        document.getElementById('calEventForm').reset();
        calSelectedWeekdays = [];
        document.querySelectorAll('.cal-weekday-btn').forEach(btn => btn.classList.remove('active'));
        
        if (date) {
            document.getElementById('calEventDate').value = date;
        } else {
            document.getElementById('calEventDate').value = calCurrentDate.toISOString().split('T')[0];
        }
        
        document.getElementById('calRecurringOptions').style.display = 'none';
        document.getElementById('calEventRecurring').checked = false;
    }

    function calCloseEventModal() {
        document.getElementById('calEventModal').style.display = 'none';
    }

    function calToggleRecurring() {
        const isRecurring = document.getElementById('calEventRecurring').checked;
        document.getElementById('calRecurringOptions').style.display = isRecurring ? 'block' : 'none';
        if (isRecurring) {
            calUpdateRecurringUI();
        }
    }

    function calUpdateRecurringUI() {
        const type = document.getElementById('calRecurringType').value;
        document.getElementById('calWeekdaySelector').style.display = 
            type === 'woechentlich' ? 'block' : 'none';
    }

    function calToggleWeekday(day) {
        const btn = document.querySelector(`.cal-weekday-btn[data-day="${day}"]`);
        const index = calSelectedWeekdays.indexOf(day);
        
        if (index > -1) {
            calSelectedWeekdays.splice(index, 1);
            btn.classList.remove('active');
        } else {
            calSelectedWeekdays.push(day);
            btn.classList.add('active');
        }
    }

    async function calSaveEvent() {
        const title = document.getElementById('calEventTitle').value.trim();
        const courseId = document.getElementById('calEventCourse').value;
        const date = document.getElementById('calEventDate').value;
        const startTime = document.getElementById('calEventStartTime').value;
        const endTime = document.getElementById('calEventEndTime').value;
        const note = document.getElementById('calEventNote').value.trim();
        const isRecurring = document.getElementById('calEventRecurring').checked;
        
        if (!title || !courseId || !date) {
            alert('Bitte füllen Sie alle Pflichtfelder aus');
            return;
        }

        const formData = new FormData();
        formData.append('action', 'create_termin');
        formData.append('kurs_id', courseId);
        formData.append('titel', title);
        formData.append('notiz', note);
        formData.append('datum', date);
        formData.append('uhrzeit_start', startTime);
        formData.append('uhrzeit_end', endTime);
        
        if (isRecurring) {
            formData.append('ist_wiederkehrend', '1');
            const recurringType = document.getElementById('calRecurringType').value;
            formData.append('wiederholung_typ', recurringType);
            
            if (recurringType === 'woechentlich') {
                if (calSelectedWeekdays.length === 0) {
                    alert('Bitte wählen Sie mindestens einen Wochentag aus');
                    return;
                }
                formData.append('wiederholung_tage', calSelectedWeekdays.join(','));
            }
            
            const recurringUntil = document.getElementById('calRecurringUntil').value;
            if (recurringUntil) {
                formData.append('wiederholung_bis', recurringUntil);
            }
        }

        try {
            const response = await fetch('Main.php', {
                method: 'POST',
                body: formData,
                credentials: 'same-origin'
            });

            const data = await response.json();
            
            if (data.success) {
                calCloseEventModal();
                await calLoadEvents();
                calRenderCalendar();
            } else {
                alert('Fehler: ' + (data.error || 'Unbekannter Fehler'));
            }
        } catch (error) {
            console.error('Error saving event:', error);
            alert('Fehler beim Speichern des Termins');
        }
    }

        async function calLoadEvents() {
        try {
            let startDate, endDate;
            
            // Lade immer Events für mindestens den gesamten aktuellen Monat,
            // damit die Mini-Kalender-Punkte und alle Ansichten korrekt sind
            const year = calCurrentDate.getFullYear();
            const month = calCurrentDate.getMonth();
            const monthStart = new Date(year, month, 1).toISOString().split('T')[0];
            const monthEnd = new Date(year, month + 1, 0).toISOString().split('T')[0];
            
            if (calCurrentView === 'week') {
                const cur = new Date(calCurrentDate);
                const day = cur.getDay() || 7;
                const monday = new Date(cur);
                monday.setDate(cur.getDate() - (day - 1));
                const sunday = new Date(monday);
                sunday.setDate(monday.getDate() + 6);
                startDate = monday.toISOString().split('T')[0];
                endDate = sunday.toISOString().split('T')[0];
            } else if (calCurrentView === 'day') {
                startDate = new Date(calCurrentDate).toISOString().split('T')[0];
                endDate = startDate;
            } else if (calCurrentView === 'year') {
                const y = calCurrentDate.getFullYear();
                startDate = new Date(y, 0, 1).toISOString().split('T')[0];
                endDate = new Date(y, 11, 31).toISOString().split('T')[0];
            } else {
                // Monatsansicht: lade nur diesen Monat
                startDate = monthStart;
                endDate = monthEnd;
            }
            
            // Für bessere Performance: lade immer den ganzen Monat,
            // aber für Jahr-Ansicht lade das ganze Jahr
            let fetchStartDate = startDate;
            let fetchEndDate = endDate;
            
            if (calCurrentView !== 'year') {
                // Für alle anderen Ansichten: lade den ganzen Monat
                fetchStartDate = monthStart;
                fetchEndDate = monthEnd;
            }

            const formData = new FormData();
            formData.append('action', 'get_termine');
            formData.append('start_date', fetchStartDate);
            formData.append('end_date', fetchEndDate);

            const response = await fetch('Main.php', {
                method: 'POST',
                body: formData,
                credentials: 'same-origin'
            });

            if (!response.ok) {
                throw new Error('Server returned ' + response.status);
            }

            const data = await response.json();
            
            if (data.success) {
                calAllEvents = data.termine || [];
                calRenderCalendar();
                calRenderMiniCalendar();
                calRenderTodayEvents();
            } else {
                console.error('Failed to load events:', data.error);
                alert('Fehler beim Laden der Termine: ' + (data.error || 'Unbekannter Fehler'));
            }
        } catch (error) {
            console.error('Error loading events:', error);
            alert('Fehler beim Laden der Termine. Bitte Seite neu laden.');
        }
    }

    function calRenderTodayEvents() {
        const today = new Date().toISOString().split('T')[0];
        const todayEvents = calAllEvents.filter(e => e.datum === today);
        const container = document.getElementById('calTodayEventsList');

        if (todayEvents.length === 0) {
            container.innerHTML = '<div style="color: #70757a; font-size: 14px;">Keine Termine für heute</div>';
            return;
        }

        container.innerHTML = todayEvents.map(event => {
            const time = event.uhrzeit_start ? 
                event.uhrzeit_start.substring(0, 5) + (event.uhrzeit_end ? ' - ' + event.uhrzeit_end.substring(0, 5) : '') : 
                'Ganztägig';
            
            return `
                <div class="cal-event-item" style="border-left-color: ${event.farb_code || '#8fbced'}" 
                     onclick="calShowEventDetails(${event.id})">
                    <div class="cal-event-title">${calEscapeHtml(event.titel)}</div>
                    <div class="cal-event-time">${time} • ${calEscapeHtml(event.kurs_name)}</div>
                </div>
            `;
        }).join('');
    }

    function calShowEventDetails(eventId) {
        const event = calAllEvents.find(e => e.id == eventId);
        if (!event) return;

        calCurrentEventId = eventId;
        
        document.getElementById('calDetailsTitle').textContent = event.titel;
        document.getElementById('calDetailsDate').textContent = calFormatDate(event.datum);
        document.getElementById('calDetailsCourse').textContent = event.kurs_name;
        
        if (event.uhrzeit_start) {
            document.getElementById('calDetailsTimeRow').style.display = 'flex';
            const timeText = event.uhrzeit_start.substring(0, 5) + 
                (event.uhrzeit_end ? ' - ' + event.uhrzeit_end.substring(0, 5) : '');
            document.getElementById('calDetailsTime').textContent = timeText;
        } else {
            document.getElementById('calDetailsTimeRow').style.display = 'none';
        }

        if (event.notiz) {
            document.getElementById('calDetailsNoteRow').style.display = 'flex';
            document.getElementById('calDetailsNote').textContent = event.notiz;
        } else {
            document.getElementById('calDetailsNoteRow').style.display = 'none';
        }

        if (event.ist_wiederkehrend == 1) {
            document.getElementById('calDetailsRecurringRow').style.display = 'flex';
            let recurText = '';
            if (event.wiederholung_typ === 'taeglich') recurText = 'Täglich';
            else if (event.wiederholung_typ === 'woechentlich') {
                const days = event.wiederholung_tage ? event.wiederholung_tage.split(',').map(d => calDayNames[d % 7]).join(', ') : 'Wöchentlich';
                recurText = 'Wöchentlich: ' + days;
            }
            else if (event.wiederholung_typ === 'monatlich') recurText = 'Monatlich';
            
            if (event.wiederholung_bis) {
                recurText += ' bis ' + calFormatDate(event.wiederholung_bis);
            }
            document.getElementById('calDetailsRecurring').textContent = recurText;
        } else {
            document.getElementById('calDetailsRecurringRow').style.display = 'none';
        }

        document.getElementById('calEventDetailsModal').style.display = 'flex';
    }

    function calCloseDetailsModal() {
        document.getElementById('calEventDetailsModal').style.display = 'none';
        calCurrentEventId = null;
    }

    async function calDeleteEvent() {
        if (!calCurrentEventId) return;
        
        if (!confirm('Möchten Sie diesen Termin wirklich löschen?')) return;

        const formData = new FormData();
        formData.append('action', 'delete_termin');
        formData.append('termin_id', calCurrentEventId);

        try {
            const response = await fetch('Main.php', {
                method: 'POST',
                body: formData,
                credentials: 'same-origin'
            });

            const data = await response.json();
            
            if (data.success) {
                calCloseDetailsModal();
                await calLoadEvents();
                calRenderCalendar();
            } else {
                alert('Fehler: ' + (data.error || 'Unbekannter Fehler'));
            }
        } catch (error) {
            console.error('Error deleting event:', error);
            alert('Fehler beim Löschen des Termins');
        }
    }

    function calFormatDate(dateStr) {
        const date = new Date(dateStr + 'T00:00:00');
        const day = date.getDate();
        const month = calMonthNames[date.getMonth()];
        const year = date.getFullYear();
        return `${day}. ${month} ${year}`;
    }

    function calEscapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    async function calRenderMiniCalendar() {
        // Berechne Monat-Range für mini calendar und lade Events für diesen Monat (damit Punkte korrekt sind)
        const month = calMiniCalendarDate.getMonth();
        const year = calMiniCalendarDate.getFullYear();
        const startDate = new Date(year, month, 1).toISOString().split('T')[0];
        const endDate = new Date(year, month + 1, 0).toISOString().split('T')[0];

        // Anfrage an Server (get_termine) nur für Mini-Monat
        try {
            const fd = new FormData();
            fd.append('action', 'get_termine');
            fd.append('start_date', startDate);
            fd.append('end_date', endDate);
            const resp = await fetch('Main.php', { method:'POST', body: fd, credentials: 'same-origin' });
            const json = await resp.json();
            var miniEvents = (json && json.success && json.termine) ? json.termine : [];
        } catch (e) {
            console.error('mini calendar load error', e);
            var miniEvents = [];
        }

        document.getElementById('calMiniCalendarMonth').textContent = 
            `${calMonthNames[month]} ${year}`;

        const firstDay = new Date(year, month, 1).getDay();
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        const daysInPrevMonth = new Date(year, month, 0).getDate();

        let html = '';
        calDayNames.forEach(day => {
            html += `<div class="cal-mini-day-label">${day}</div>`;
        });

        const today = new Date();
        const isCurrentMonth = today.getMonth() === month && today.getFullYear() === year;

        const startDay = firstDay === 0 ? 6 : firstDay - 1;
        for (let i = startDay - 1; i >= 0; i--) {
            html += `<div class="cal-mini-day other-month">${daysInPrevMonth - i}</div>`;
        }

        for (let day = 1; day <= daysInMonth; day++) {
            const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
            const hasEvents = miniEvents.some(e => e.datum === dateStr);
            const isToday = isCurrentMonth && day === today.getDate();
            
            html += `<div class="cal-mini-day ${isToday ? 'today' : ''} ${hasEvents ? 'has-events' : ''}" onclick="calOpenDay('${dateStr}')">${day}</div>`;
        }

        const totalCells = startDay + daysInMonth;
        const remainingCells = totalCells % 7 === 0 ? 0 : 7 - (totalCells % 7);
        for (let day = 1; day <= remainingCells; day++) {
            html += `<div class="cal-mini-day other-month">${day}</div>`;
        }

        document.getElementById('calMiniCalendarGrid').innerHTML = html;
    }

    function calRenderCalendar() {
        const main = document.getElementById('calCalendarMain');
        if (calCurrentView === 'week') calRenderWeekView(main);
        else if (calCurrentView === 'day') calRenderDayView(main);
        else if (calCurrentView === 'year') calRenderYearView(main);
        else calRenderMonthView(main);
    }
 
    function calRenderMonthView(container) {
        const month = calCurrentDate.getMonth();
        const year = calCurrentDate.getFullYear();
        
        document.getElementById('calCurrentPeriod').textContent = 
            `${calMonthNames[month]} ${year}`;

        const firstDay = new Date(year, month, 1).getDay();
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        const daysInPrevMonth = new Date(year, month, 0).getDate();

        let html = '<div class="cal-month-view">';
        
        calDayNames.forEach(day => {
            html += `<div class="cal-day-header">${day}</div>`;
        });

        const today = new Date();
        const isCurrentMonth = today.getMonth() === month && today.getFullYear() === year;

        const startDay = firstDay === 0 ? 6 : firstDay - 1;
        
        // Previous month days
        for (let i = startDay - 1; i >= 0; i--) {
            const day = daysInPrevMonth - i;
            const prevMonth = month === 0 ? 11 : month - 1;
            const prevYear = month === 0 ? year - 1 : year;
            const dateStr = `${prevYear}-${String(prevMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
            
            // öffne immer die Tagesansicht (einheitlich)
            html += `<div class="cal-day-cell other-month" onclick="calOpenDay('${dateStr}')">
                 <div class="cal-day-number">${day}</div>
             </div>`;
        }

        // Current month days
        for (let day = 1; day <= daysInMonth; day++) {
            const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
            const dayEvents = calAllEvents.filter(e => e.datum === dateStr);
            const isToday = isCurrentMonth && day === today.getDate();
            
            // clicking the day should open the day view
            html += `<div class="cal-day-cell ${isToday ? 'today' : ''}" onclick="calOpenDay('${dateStr}')">
                <div class="cal-day-number">${day}</div>`;
            
            dayEvents.slice(0, 3).forEach(event => {
                const time = event.uhrzeit_start ? event.uhrzeit_start.substring(0, 5) + ' ' : '';
                html += `<div class="cal-event-dot" style="border-left-color: ${event.farb_code || '#8fbced'}" onclick="event.stopPropagation(); calShowEventDetails(${event.id})">
                    ${time}${calEscapeHtml(event.titel)}
                </div>`;
            });
            
            if (dayEvents.length > 3) {
                html += `<div style="font-size: 11px; color: #70757a; padding: 2px 4px;">
                    +${dayEvents.length - 3} weitere
                </div>`;
            }
            
            html += '</div>';
        }

        // Next month days
        const totalCells = startDay + daysInMonth;
        const remainingCells = totalCells % 7 === 0 ? 0 : 7 - (totalCells % 7);
        for (let day = 1; day <= remainingCells; day++) {
            const nextMonth = month === 11 ? 0 : month + 1;
            const nextYear = month === 11 ? year + 1 : year;
            const dateStr = `${nextYear}-${String(nextMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
            
            html += `<div class="cal-day-cell other-month" onclick="calOpenDay('${dateStr}')">
                 <div class="cal-day-number">${day}</div>
             </div>`;
        }

        html += '</div>';
        container.innerHTML = html;
    }
    
    // Öffne Tages-Ansicht für gegebenes Datum (yyyy-mm-dd)
    async function calOpenDay(dateStr) {
        calCurrentDate = new Date(dateStr + 'T00:00:00');
        calCurrentView = 'day';
        document.querySelectorAll('.cal-view-btn').forEach(btn => btn.classList.remove('active'));
        document.querySelectorAll('.cal-view-btn').forEach(btn => { 
            if (btn.textContent.trim().toLowerCase() === 'tag') {
                btn.classList.add('active'); 
            }
        });
        
        // Mini-Kalender auf denselben Monat setzen
        calMiniCalendarDate = new Date(calCurrentDate);
        
        // Events für den Monat laden (damit alle Datenpunkte korrekt sind)
        await calLoadEvents();
        
        // Tagesansicht rendern
        calRenderCalendar();
    }

    function calRenderDayView(container) {
        const year = calCurrentDate.getFullYear();
        const month = calCurrentDate.getMonth();
        const day = calCurrentDate.getDate();
        const dateStr = `${year}-${String(month + 1).padStart(2,'0')}-${String(day).padStart(2,'0')}`;
        
        document.getElementById('calCurrentPeriod').textContent = `${day}. ${calMonthNames[month]} ${year}`;

        // Filtere Events für diesen spezifischen Tag
        const dayEvents = calAllEvents.filter(e => {
            return e.datum === dateStr || e.instance_date === dateStr;
        }).sort((a,b)=> (a.uhrzeit_start||'') > (b.uhrzeit_start||'') ? 1:-1);
        
        let html = `<div style="display:flex; gap:20px; flex-direction:column;">`;
        html += `<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
                    <div style="font-weight:600;">${calFormatDate(dateStr)}</div>
                    <div><button class="cal-btn cal-btn-secondary" onclick="calOpenEventModal('${dateStr}')">+ Termin</button></div>
                </div>`;
        if (dayEvents.length === 0) {
            html += `<div style="padding:20px; background:white; border-radius:8px;">Keine Termine an diesem Tag.</div>`;
        } else {
            html += `<div style="display:flex; flex-direction:column; gap:8px;">`;
            dayEvents.forEach(ev=>{
                const time = ev.uhrzeit_start ? ev.uhrzeit_start.substring(0,5) + (ev.uhrzeit_end ? ' - ' + ev.uhrzeit_end.substring(0,5) : '') : 'Ganztägig';
                html += `<div class="cal-event-item" style="border-left-color:${ev.farb_code||'#8fbced'}" onclick="calShowEventDetails(${ev.id})">
                            <div class="cal-event-title">${calEscapeHtml(ev.titel)}</div>
                            <div class="cal-event-time">${time} • ${calEscapeHtml(ev.kurs_name)}</div>
                        </div>`;
            });
            html += `</div>`;
        }
        html += `</div>`;
        container.innerHTML = html;
    }

    function calRenderWeekView(container) {
        const cur = new Date(calCurrentDate);
        const day = cur.getDay() || 7;
        const monday = new Date(cur); monday.setDate(cur.getDate() - (day - 1));
        const days = [];
        for (let i=0;i<7;i++){ const d = new Date(monday); d.setDate(monday.getDate()+i); days.push(d); }

        document.getElementById('calCurrentPeriod').textContent = `${calFormatDate(days[0].toISOString().split('T')[0])} — ${calFormatDate(days[6].toISOString().split('T')[0])}`;

        let html = `<div style="display:grid; grid-template-columns: repeat(7,1fr); gap:6px; align-items:start;">`;
        days.forEach(d=>{
            const dateStr = d.toISOString().split('T')[0];
            const dayEvents = calAllEvents.filter(e=>e.datum===dateStr);
            html += `<div class="cal-day-cell ${ (d.toDateString()=== (new Date()).toDateString()) ? 'today' : '' }" style="min-height:220px;" onclick="calOpenDay('${dateStr}')">
                        <div class="cal-day-number">${d.getDate()} <span style="font-size:11px;color:#70757a;">${calDayNames[d.getDay()]}</span></div>`;
            dayEvents.slice(0,6).forEach(ev=>{
                const time = ev.uhrzeit_start ? ev.uhrzeit_start.substring(0,5) + ' ' : '';
                html += `<div class="cal-event-dot" style="border-left-color: ${ev.farb_code || '#8fbced'}" onclick="event.stopPropagation(); calShowEventDetails(${ev.id})">
                            ${time}${calEscapeHtml(ev.titel)}
                         </div>`;
            });
            if (dayEvents.length>6) html += `<div style="font-size:11px;color:#70757a;padding:4px;">+${dayEvents.length-6} weitere</div>`;
            html += `</div>`;
        });
        html += `</div>`;
        container.innerHTML = html;
    }

    function calRenderYearView(container) {
        const year = calCurrentDate.getFullYear();
        document.getElementById('calCurrentPeriod').textContent = `${year}`;
        let html = `<div style="display:grid; grid-template-columns: repeat(4,1fr); gap:12px;">`;
        for (let m=0;m<12;m++){
            const first = new Date(year,m,1);
            const daysInMonth = new Date(year,m+1,0).getDate();
            let count = 0;
            for (let d=1; d<=daysInMonth; d++){
                const dateStr = `${year}-${String(m+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
                if (calAllEvents.some(e=>e.datum===dateStr)) count++;
            }
            html += `<div class="cal-mini-calendar" style="cursor:pointer;" onclick="(function(){ calCurrentDate=new Date(${year},${m},1); calCurrentView='month'; document.querySelectorAll('.cal-view-btn').forEach(b=>b.classList.remove('active')); document.querySelectorAll('.cal-view-btn').forEach(b=>{ if (b.textContent.trim().toLowerCase()==='monat') b.classList.add('active'); }); calLoadEvents(); calRenderCalendar(); })()">
                        <div style="font-weight:600; margin-bottom:6px;">${calMonthNames[m]}</div>
                        <div style="color:#70757a;">${count} Termine</div>
                     </div>`;
        }
        html += `</div>`;
        container.innerHTML = html;
    }

    // Initial render
    document.addEventListener('DOMContentLoaded', function() {
        // Erst UI rendern, dann Events laden (calLoadEvents rendert die richtige Ansicht nach dem Laden)
        calRenderCalendar();
        calRenderMiniCalendar(); // async - lädt mini-month events intern
        calLoadEvents();
    });
</script>