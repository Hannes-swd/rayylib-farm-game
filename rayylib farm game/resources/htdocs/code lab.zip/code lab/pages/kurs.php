<div class="app-card">
    <div class="app-users-header">
    <?php if (hasRole('admin')): ?>
        <a href="?page=KursErstellen" class="app-users-add-link">
            <p class="app-users-add-text">Kurs Erstellen</p>
        </a>
    <?php else: ?>
        <p> </p>
    <?php endif; ?>
    <div>
        <form class="search-form" onsubmit="event.preventDefault(); filterCourses();">
            <input type="text" id="courseSearch" class="app-users-search" placeholder="Kursname oder Beschreibung suchen...">
        </form>
    </div>
    
</div>

<?php
try {
    // Nur alle Kurse laden, wenn Admin – sonst nur Kurse, die dem aktuellen Nutzer zugewiesen sind
    if (hasRole('admin')) {
        $stmt = $pdo->prepare("SELECT id, name, info, farb_code FROM kurse ORDER BY name");
        $stmt->execute();
        $courses = $stmt->fetchAll();
    } else {
        $courses = [];
        $courses_str = $user['courses'] ?? '';
        $course_names = array_values(array_filter(array_map('trim', explode(',', $courses_str))));
        if (!empty($course_names)) {
            // sichere Platzhalter für Prepared Statement
            $placeholders = implode(',', array_fill(0, count($course_names), '?'));
            $stmt = $pdo->prepare("SELECT id, name, info, farb_code FROM kurse WHERE name IN ($placeholders) ORDER BY name");
            $stmt->execute($course_names);
            $courses = $stmt->fetchAll();
        }
    }
} catch (PDOException $e) {
    $courses = [];
}
?>

<div class="app-courses">
    <?php if (empty($courses)): ?>
        <p style="margin-top:12px;color:#666;">Keine Kurse vorhanden.</p>
    <?php else: ?>
    <div style="margin-bottom:8px;color:#444;font-weight:600;">
        Gefundene Kurse: <?php echo count($courses); ?>
    </div>
    <div class="app-courses-grid" id="coursesGrid">
        <?php foreach ($courses as $course):
            $name = htmlspecialchars($course['name']);
            $desc = htmlspecialchars($course['info'] ?? '-');
            $color = !empty($course['farb_code']) ? htmlspecialchars($course['farb_code']) : '#8fbced';
        ?>
            <div class="app-course" style="--card-color: <?php echo $color; ?>;"
                 data-id="<?php echo intval($course['id']); ?>" data-name="<?php echo strtolower($name . ' ' . $desc); ?>" data-color="<?php echo $color; ?>">
                <div style="display:flex; flex-direction:column; align-items:flex-start;">
                    <div class="app-course__badge" aria-hidden="true"></div>
                </div>
                <div class="app-course__info">
                    <h3><?php echo $name; ?></h3>
                    <p class="app-course__desc"><?php echo $desc; ?></p>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>

<script>
    function initCourseCards() {
        document.querySelectorAll('.app-course').forEach(card => {
            const col = card.dataset.color || '#8fbced';
            const rgba = colorToRgba(col, 0.06);
            card.style.background = `linear-gradient(90deg, ${rgba}, rgba(255,255,255,0.95))`;

            // Klick öffnet Kurs-Seite
            card.addEventListener('click', function() {
                const id = this.dataset.id;
                if (id) {
                    // navigiere zur Kurs-Detailseite
                    window.location.href = 'Main.php?page=KursOffen&course_id=' + encodeURIComponent(id);
                    return;
                }
                // fallback (falls keine id vorhanden): nur selektieren (optional)
                document.querySelectorAll('.app-course').forEach(c => {
                    c.classList.remove('selected');
                    const ccol = c.dataset.color || '#8fbced';
                    c.style.background = `linear-gradient(90deg, ${colorToRgba(ccol,0.06)}, rgba(255,255,255,0.95))`;
                });
                this.classList.add('selected');
                this.style.background = `linear-gradient(90deg, ${colorToRgba(this.dataset.color||'#8fbced',0.12)}, rgba(255,255,255,0.98))`;
            });
        });
    }

    function filterCourses() {
        const term = (document.getElementById('courseSearch').value || '').trim().toLowerCase();
        document.querySelectorAll('#coursesGrid .app-course').forEach(card => {
            const hay = card.dataset.name || '';
            card.style.display = hay.includes(term) ? '' : 'none';
        });
    }

    document.getElementById('courseSearch').addEventListener('input', filterCourses);

    function colorToRgba(color, alpha) {
        if (!color) return 'rgba(143,188,237,'+alpha+')';
        color = color.trim();
        if (color.startsWith('#')) {
            const hex = color.substring(1);
            if (hex.length === 3) {
                const r = parseInt(hex[0]+hex[0],16);
                const g = parseInt(hex[1]+hex[1],16);
                const b = parseInt(hex[2]+hex[2],16);
                return 'rgba('+r+','+g+','+b+','+alpha+')';
            } else if (hex.length === 6) {
                const r = parseInt(hex.substring(0,2),16);
                const g = parseInt(hex.substring(2,4),16);
                const b = parseInt(hex.substring(4,6),16);
                return 'rgba('+r+','+g+','+b+','+alpha+')';
            }
        } else if (color.startsWith('rgb')) {
            if (color.startsWith('rgba')) return color;
            return color.replace('rgb(', 'rgba(').replace(')', ','+alpha+')');
        }
        return 'rgba(143,188,237,'+alpha+')';
    }

    document.addEventListener('DOMContentLoaded', initCourseCards);
</script>