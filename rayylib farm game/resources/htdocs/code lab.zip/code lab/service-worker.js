const CACHE_NAME = 'code-lab-v1';
const urlsToCache = [
  '/',
  '/index.php',
  '/Main.php',
  '/style.css'
];

// Install Event
self.addEventListener('install', (event) => {
  console.log('Service Worker installing...');
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log('Cache geöffnet');
      return cache.addAll(urlsToCache);
    }).catch((err) => {
      console.error('Cache error:', err);
    })
  );
  self.skipWaiting(); // Sofort aktivieren
});

// Activate Event
self.addEventListener('activate', (event) => {
  console.log('Service Worker activating...');
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) {
            console.log('Alte Cache gelöscht:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
  self.clients.claim(); // Sofort Kontrolle übernehmen
});

// Fetch Event
self.addEventListener('fetch', (event) => {
  // Nur GET-Requests cachen
  if (event.request.method !== 'GET') {
    return;
  }

  event.respondWith(
    fetch(event.request)
      .then((response) => {
        // Erfolgreiche Response: in Cache speichern und zurückgeben
        if (!response || response.status !== 200 || response.type !== 'basic') {
          return response;
        }
        const responseToCache = response.clone();
        caches.open(CACHE_NAME).then((cache) => {
          cache.put(event.request, responseToCache);
        });
        return response;
      })
      .catch(() => {
        // Offline: aus Cache laden
        return caches.match(event.request);
      })
  );
});